/*
 *     file: Inference.java
 *  package: oreilly.hcj.tiger
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */
package oreilly.hcj.tiger;

import java.util.*;
import java.lang.reflect.*;

/** 
 * Implements a manager of lists that stores the lists by
 * key.
 */
public class ErasureDemo {
	//public static <Type extends Comparable> Type someOtherMethod(final Type obj) { return null;  }
	//public static Comparable someOtherMethod(final Comparable obj) { return null; }

	//public <Type extends List<Integer>> void someMethod(final Type list) {}
	//public <Type extends List<String>> void someMethod(final Type list) {}

	private static List<Integer> someList;
	
	public static void someMethod(final List<Integer> list) {
		for (Integer element : list) {
			element.intValue();
		}
	}

	public static void main(final String[] args) {
			someList = new ArrayList<Integer>();
			someList.add(new Integer(123));
			someList.add(new Integer(456));
			someList.add(new Integer(789));
			
		try {
			List list = (List)ErasureDemo.class.getDeclaredField("someList").get(null);
			list.add(new String("Hello"));
			for (Object element : list) {
				((Integer)element).intValue();
			}
	
		} catch (final Exception ex) {
			System.out.println();
			ex.printStackTrace();
		}

		try {
			List list2 = new ArrayList(); 
			list2.add(new Integer(3));
			list2.add(new String("Hello"));
	
			Class[] paramTypes = new Class[] {List.class};
			Object[] methargs = new Object[] {list2};
			Method meth = ErasureDemo.class.getDeclaredMethod("someMethod", paramTypes);
			meth.invoke(null, methargs);
		} catch (final Exception ex) {
			System.out.println();
			ex.printStackTrace();
		}
	}
}

/* ########## End of File ########## */

