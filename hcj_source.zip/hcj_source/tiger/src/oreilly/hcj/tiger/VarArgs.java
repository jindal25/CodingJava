/*
 *     file: VarArgs.java
 *  package: <default> 
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */
package oreilly.hcj.tiger;

/**
 * Demonstration of the Variable Arguments facility of Tiger, JDK 1.5.
 */
public class VarArgs {
 

}

/* ########## End of File ########## */
