/*
 *     file: StatusColor.java
 *  package: <default> 
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */
package oreilly.hcj.tiger;

import java.awt.Color;

/**
 * A static class used to demo static imports.
 */
public class StatusColors {
	/** Color used for normal status. */
	public static final Color DEFAULT = Color.green;

	/** Color used for normal status. */
	public static final Color WARNING = Color.yellow;

	/** Color used for normal status. */
	public static final Color ERROR = Color.red;
}

/* ########## End of File ########## */
