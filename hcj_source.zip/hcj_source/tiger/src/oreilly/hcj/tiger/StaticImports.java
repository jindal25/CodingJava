/*
 *     file: StaticImports.java
 *  package: oreilly.hcj.tiger
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */
package oreilly.hcj.tiger;

import static oreilly.hcj.tiger.StatusColors.*;
import static java.lang.Math.*;
import java.awt.Graphics;

/**
 * Demonstration of thestatic import facility of Tiger, JDK 1.5.
 */
public class StaticImports {
	public void firstMethod(final Graphics g, final int errCode) {
		if (errCode >= 3) {
			g.setColor(StatusColors.ERROR);
		} else if (errCode == 2) {
			g.setColor(StatusColors.WARNING);
		} else if (errCode == 1) {
			g.setColor(StatusColors.DEFAULT);
		} else {
			assert (false);
		}
	}

	public void secondMethod(final Graphics g, final int errCode) {
		if (errCode >= 3) {
			g.setColor(ERROR);
		} else if (errCode == 2) {
			g.setColor(WARNING);
		} else if (errCode == 1) {
			g.setColor(DEFAULT);
		} else {
			assert (false);
		}
	}

	public void mathMethod(final int x, final int y) {
		int z = max(x, y); 
		double sqrt = sqrt(z^5);
	}
}

/* ########## End of File ########## */
