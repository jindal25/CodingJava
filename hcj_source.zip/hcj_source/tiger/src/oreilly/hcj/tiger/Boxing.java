/*
 *     file: Boxing.java
 *  package: <default> 
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */
package oreilly.hcj.tiger;

/**
 * Demonstration of the Boxing and Unboxing facility of Tiger, JDK 1.5.
 */
public class Boxing {
	public static void someMethod(final Float x) {
		System.out.println("Float");
	}

	public static void someMethod(final Integer x) {
		System.out.println("Integer");
	}

	public final static void main(final String[] args) {
	 	someMethod((Integer)5);
	 	//someMethod((int)5);
	}

	public void someOtherMethod() {
		Integer[] values = new Integer[1];
		Number[] nums = values; // <== legal
		// String[] strs = values; <== illegal
	}
}

/* ########## End of File ########## */

