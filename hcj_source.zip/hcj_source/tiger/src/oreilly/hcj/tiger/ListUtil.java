/*
 *     file: ListManager.java
 *  package: oreilly.hcj.tiger
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */
package oreilly.hcj.tiger;

import java.util.*;

/** 
 * Implements a manager of lists that stores the lists by
 * key.
 */
public final class ListUtil {
	public void dumpList(final List<? extends Number> list) {
		int idx = 0;
		for (Object obj : list) {
			System.out.println("[" + idx + "] " + obj.toString());
			idx++;
		}
	}

	public <Type extends Number> void dumpList2(final List<Type> list) {
		int idx = 0;
		for (Number num : list) {
			System.out.println("[" + idx + "] " + num.intValue());
			idx++;
		}
	}
}

/* ########## End of File ########## */

