/*
 *     file: Inference.java
 *  package: oreilly.hcj.tiger
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */
package oreilly.hcj.tiger;

import java.util.*;
import java.io.Serializable;

/** 
 * Implements a manager of lists that stores the lists by
 * key.
 */
public class Inference {
	static int callCount = 0;

	public static <Type> Type someMethod(final Type obj) {
		System.out.print(" First==> ");
		System.out.println(obj.getClass());
		return obj;
	}

	public static <Type extends Number> Type someMethod(final Type num) {
		System.out.print(" Second==> ");
		System.out.println(num.getClass());
		return num;
	}

	public static <Type> Type someMethod(final Type obj, List<Type> list) {
		System.out.print(" Third==> ");
		System.out.println(obj.getClass());
		for (Type element : list) {
		}
		return obj;
	}

	public static <Type> List<Type> nothing() {
		List<Type> result = new ArrayList<Type>();
		System.out.print(" Fourth==> ");
		System.out.println(result.getClass().getComponentType());
		return result;
	}

	public static void someMethod(final Object obj) {
		System.out.print(" Fifth==> ");
		System.out.println(obj.getClass());
	}

	public static void someMethod(final String str) {
		System.out.print(" Sixth==> ");
		System.out.println(str.getClass());
	}

	public final static void main(final String[] args) {
		// introductory 
		System.out.print("1)");
		someMethod("Hello");

		//System.out.print("2)");
		//someMethod(new C());

		// Simple
		//System.out.print("3)");
		//someMethod("hello").getClass();

		//System.out.print("4)");
		//someMethod(new Object()).getClass();

		System.out.print("5)");
		someMethod(new Integer(5)).getClass();

		System.out.print("6)");
		someMethod(5).getClass();

		//System.out.print("7)");
		//someMethod().getClass();

		// Less Than Simple
		List<A> first = new ArrayList<A>();
		first.add(new A());

		List<B> second = new ArrayList<B>();
		second.add(new B());
		
		try {
			System.out.print("8)");
			someMethod(new A(), new ArrayList<B>()).getClass();
		} catch (final ClassCastException ex) { ex.printStackTrace(); }

		try {
			System.out.print("9)");
			someMethod(new B(), new ArrayList<A>()).getClass();
		} catch (final NullPointerException ex) { ex.printStackTrace(); }

		//System.out.print("1)");
		Inference.<A>someMethod(new B(), new ArrayList<A>()).getClass();

		System.out.print("10)");
		someMethod(5, new ArrayList<Object>()).getClass();

		System.out.print("11)");
		someMethod(5, null).getClass();

		// Significantly Less than Simple
	}

	private static class A {
	}

	private static class B extends A {
	}

	private static class C extends B {
	}
}

/* ########## End of File ########## */

