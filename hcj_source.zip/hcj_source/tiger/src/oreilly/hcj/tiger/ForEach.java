/*
 *     file: ForEach.java
 *  package: <default> 
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */
package oreilly.hcj.tiger;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Demonstration of the foreach facility of Tiger, JDK 1.5.
 */
public class ForEach {
	public final static String[] importantPeople = new String[] {
							"Robert", "Jim", "Sacir", "Aida", "Alma",
							"Amila", "Selma", "Nefisa", "Mustafa",
							"Paul", "Debbie", "Marco", "Bettina", "Ana",
							"Maria" };

	/**
	 * Array usage prior to Tiger.
	 *
	 * @param prefix The prefix of the names to print.
	 */
	public static void someMethod(final String prefix) {
		for (int idx = 0; idx < importantPeople.length; idx++) {
			if (importantPeople[idx].startsWith(prefix)) {
				System.out.print(importantPeople[idx] + " ");
			}
		}
		System.out.println();
	}

	/**
	 * Array usage with Tiger.
	 *
	 * @param prefix The prefix of the names to print.
	 */
	public static void someTigerMethod(final String prefix) {
		for (String person: importantPeople) {
			if (person.startsWith(prefix)) {
				System.out.print(person + " ");
			}
		}
		System.out.println();
	}

	/**
	 * Collection usage with JDK 1.4 and below.
	 *
	 * @param prefix The prefix of the names to print.
	 */
	public static void someCollectionMethod(final String prefix) {
		List people = Arrays.asList(importantPeople);
		Iterator iter = people.iterator();
		for (String person = (String)iter.next(); iter.hasNext(); 
		     person = (String)iter.next()) {
			if (person.startsWith(prefix)) {
				System.out.print(person + " ");
			}
		}
		System.out.println();
	}

	/**
	 * Collection usage with Tiger.
	 *
	 * @param prefix The prefix of the names to print.
	 */
	public static void someTigerCollectionMethod(final String prefix) {
		List<String> people = Arrays.asList(importantPeople);
		for (String person: people) {
			if (person.startsWith(prefix)) {
				System.out.print(person + " ");
			}
		}
		System.out.println();
	}

	public static void main(final String[] args) {
		if (args.length != 1) {
			System.out.println("usage: ForEach <string>");
			System.out.println("Where <string> is the prefix of names you wish to print.");
			System.exit(0);
		}
		System.out.println("The old way: ");
		someMethod(args[0]);	
		System.out.println("The new way: ");
		someTigerMethod(args[0]);	
		System.out.println("The old collection way: ");
		someCollectionMethod(args[0]);	
		System.out.println("The new collection way: ");
		someTigerCollectionMethod(args[0]);	
	} 
}

/* ########## End of File ########## */
