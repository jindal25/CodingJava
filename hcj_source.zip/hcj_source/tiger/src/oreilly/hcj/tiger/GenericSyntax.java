/*
 *     file: GenericSyntax.java
 *  package: oreilly.hcj.tiger
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */
package oreilly.hcj.tiger;

import java.util.*;

/**
 * Demonstrates Generics Syntax.
 */
public class GenericSyntax {
	Set<Address> addresses = new HashSet<Address>();

	public void someManagerMethod() {
		ListManager<List<Integer>> integerMgr = new ListManager<List<Integer>>(new LinkedList<Integer>());
		//ListManager<List<String>> stringMgr = new ListManager<List<String>>(new LinkedList<String>());
		// ... other code.
	}

	public static void casting() {
		List<A> listOfA = new ArrayList<A>();
		List<B> listOfB = new ArrayList<B>();
		List<C> listOfC = new ArrayList<C>();
		ArrayList<A> arrayListOfA = new ArrayList<A>();
		SomeClass<A> scA = new SomeClass<A>();
		SomeClass2<A> sc2A = new SomeClass2<A>();
		SomeClass3<A> sc3A = new SomeClass3<A>();

		// casts
		Set<A> one = (Set<A>) listOfA;
		Object two = (Object) listOfA;
		// List<A> three = (List<A>) two; // Unchecked warning
		List<Integer> intlist = (List<A>)new ArrayList<Integer>();
		List<Number> numList = (List<A>) intlist;
		List four = (List) listOfB;
		List<A> five = (List<A>)arrayListOfA;
		SomeClass six = (SomeClass) sc2A;
		// SomeClass2<A> seven = (SomeClass2<A>) six; // Unchecked warning
		SomeClass3<A> eight = (SomeClass3<A>) scA;


		// List<A> z = (List<a>) obj;

		// List<A> z = (List<A>) listOfB; 
		// List<B> z = (List<B>) listOfA; 
	}

//	public GenericSyntax() {
//		addresses.add(new Integer(5));
//	}

	public static void someOtherMethod() {
		Crazy<Set<List<Integer>>> crazy;
		Crazy<Set<List<Object>>> crazy1;
		Crazy<Set<List<Number>>> crazy2;
		Crazy<HashSet<List<Integer>>> crazy3;
		Crazy<TreeSet<ArrayList<Number>>> crazy4;
		Crazy<Set<LinkedList<Object>>> crazy5;
		// ... and more ...
	}

	public static void main(final String[] args) {
		casting();
	}

	private static class A {
	}

	private static class B extends A {
	}

	private static class C extends B {
	}

	private static class SomeClass<Type> {
	}

	private static class SomeClass2<Type> extends SomeClass<Type> {
	}

	private static class SomeClass3<Type> extends SomeClass<Type> {
	}
}

/* ########## End of File ########## */
