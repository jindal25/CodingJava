/*
 *     file: DevelopmentMode.java
 *  package: oreilly.hcj._development
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj._development;

/**  
 * Development mode constants for conditional compilation.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public final class DevelopmentMode {
	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_bankdata = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_collections = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_constants = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_datamodeling = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_exceptions = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_finalstory = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_immutable = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_nested = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_proxies = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_references = true;

	/** Development mode constant for package oreilly.hcj.bankdata. */
	public static final boolean hcj_review = true;

	/** 
	 * Hidden Constructor.
	 */
	private DevelopmentMode() {
		assert false : "DevelopmentMode is a Singleton.";
	}
}

/* ########## End of File ########## */
