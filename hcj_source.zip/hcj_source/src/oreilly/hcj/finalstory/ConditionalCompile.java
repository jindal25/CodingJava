/*
 *     file: ConditionalCompile.java
 *  package: oreilly.hcj.finalstory
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.finalstory;

import oreilly.hcj._development.DevelopmentMode;
import org.apache.log4j.Logger;

/**  
 * Platform for syntax checking conditional compilation.  Note that for the user to
 * actually see the effect of conditional compilation, they  would have to look at the
 * actual class file generated for this class. I am merely using this class to check
 * syntax for the book.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class ConditionalCompile {
	/** Logger instance. */
	private static final Logger LOGGER = Logger.getLogger(ConditionalCompile.class);

	/** Logging selector. */
	private static final boolean doLogging = false;

	/** 
	 * Normal method.
	 */
	public static void someMethod() {
		// Do some set up code. 
		LOGGER.debug("Set up complete, beginning phases.");
		// do first part. 
		LOGGER.debug("phase1 complete");
		// do second part. 
		LOGGER.debug("phase2 complete");
		// do third part. 
		LOGGER.debug("phase3 complete");
		// do finalization part. 
		LOGGER.debug("phase4 complete");
		// Operation Completed
		LOGGER.debug("All phases completed successfully");
	}

	/** 
	 * Normal method.
	 */
	public static void someMethodBetter() {
		// Do some set up code. 
		if (doLogging) {
			LOGGER.debug("Set up complete, beginning phases.");
		}

		// do first part. 
		if (doLogging) {
			LOGGER.debug("phase1 complete");
		}

		// do second part. 
		if (doLogging) {
			LOGGER.debug("phase2 complete");
		}

		// do third part. 
		if (doLogging) {
			LOGGER.debug("phase3 complete");
		}

		// do finalization part. 
		if (doLogging) {
			LOGGER.debug("phase4 complete");
		}

		// Operation Completed
		if (doLogging) {
			LOGGER.debug("All phases completed successfully");
		}
	}

	/** 
	 * __UNDOCUMENTED__
	 */
	public void projectVariables() {
		if (DevelopmentMode.hcj_finalstory) {
			// ... do conditional code.
		}
	}
}

/* ########## End of File ########## */
