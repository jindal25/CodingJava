/*
 *     file: FinalConstants.java
 *  package: oreilly.hcj.finalstory
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.finalstory;

/**  
 * Demonstration of final constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class FinalConstants {
	/**  
	 * A circle class that doesnt use constants.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.3 $
	 */
	public static class CircleTools {
		/** 
		 * Calculate the area of the circle with the given radius.
		 *
		 * @param radius The radius of the circle.
		 *
		 * @return The calculated area.
		 */
		public double getCircleArea(final double radius) {
			return (Math.pow(radius, 2) * 3.141);
		}

		/** 
		 * Calculate the circumference of the circle with the given radius.
		 *
		 * @param radius The radius of the circle.
		 *
		 * @return The calculated circumference.
		 */
		public double getCircleCircumference(final double radius) {
			return ((radius * 2) * 3.141);
		}

		/** 
		 * Calculate the extruded volume of the circle with the given radius.
		 *
		 * @param radius The radius of the circle.
		 * @param height The height of the cylinder to extrude
		 *
		 * @return The calculated circumference.
		 */
		public double getCircleExtrudedVolume(final double radius, final double height) {
			return ((radius * 2 * height) * 3.141);
		}
	}

	/**  
	 * A circle class that uses constants.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.3 $
	 */
	public static class CircleToolsBetter {
		/** A value for PI. */
		public static final double PI = 3.141;

		/** 
		 * Calculate the area of the circle with the given radius.
		 *
		 * @param radius The radius of the circle.
		 *
		 * @return The calculated area.
		 */
		public double getCircleArea(final double radius) {
			return (Math.pow(radius, 2) * PI);
		}

		/** 
		 * Calculate the circumference of the circle with the given radius.
		 *
		 * @param radius The radius of the circle.
		 *
		 * @return The calculated circumference.
		 */
		public double getCircleCircumference(final double radius) {
			return ((radius * 2) * PI);
		}

		/** 
		 * Calculate the extruded volume of the circle with the given radius.
		 *
		 * @param radius The radius of the circle.
		 * @param height The height of the cylinder to extrude
		 *
		 * @return The calculated circumference.
		 */
		public double getCircleExtrudedVolume(final double radius, final double height) {
			return ((radius * 2 * height) * PI);
		}
	}

	/**  
	 * Demonstration of excessive private constant declaration.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.3 $
	 */
	public class SomeClass {
		/** Contains the constant for the first equation. */
		private static final double K1 = 3.141;

		/** Contains the offset for the first equation. */
		private static final double X1 = 15.0;

		/** Contains the constant for the second equation. */
		private static final double K2 = 1.414;

		/** Contains the offset for the second equation. */
		private static final double X2 = 45.0;

		/** Contains a constant for both equations. */
		private static final double M = 9.3;

		/** 
		 * Calculate the results of an equation.
		 *
		 * @param inputValue Input to the equation.
		 *
		 * @return result of the equation.
		 */
		public double equation1(final double inputValue) {
			return (((Math.pow(inputValue, 2.0d) / K1) + X1) / M);
		}

		/** 
		 * Calculate the results of an equation.
		 *
		 * @param inputValue Input to the equation.
		 *
		 * @return result of the equation.
		 */
		public double equation2(final double inputValue) {
			return (((Math.pow(inputValue, 3.0d) * K2) + X2) * M);
		}
	}

	/**  
	 * Demonstration of moving private constants into methods.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.3 $
	 */
	public class SomeClassBetter {
		/** Contains a constant for both equations. */
		private static final double M = 9.3;

		/** 
		 * Calculate the results of an equation.
		 *
		 * @param inputValue Input to the equation.
		 *
		 * @return result of the equation.
		 */
		public double equation1(final double inputValue) {
			final double K = 3.141;
			final double X = 15.0;

			return (((Math.pow(inputValue, 2.0d) / K) + X) / M);
		}

		/** 
		 * Calculate the results of an equation.
		 *
		 * @param inputValue Input to the equation.
		 *
		 * @return result of the equation.
		 */
		public double equation2(final double inputValue) {
			final double K = 1.414;
			final double X = 45.0;

			return (((Math.pow(inputValue, 3.0d) * K) + X) * M);
		}
	}
}

/* ########## End of File ########## */
