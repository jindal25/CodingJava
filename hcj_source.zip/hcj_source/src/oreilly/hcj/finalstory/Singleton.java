/*
 *     file: Singleton.java
 *  package: oreilly.hcj.finalstory
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.finalstory;

import java.util.Arrays;
import org.apache.log4j.Logger;

/**  
 * A demonstration of an extensible sinlgeton class.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Singleton {
	/** Holds the Logger for this class. */
	private static final Logger LOGGER = Logger.getLogger(Singleton.class);

	/** Holds the instance of the singleton. */
	public static Singleton instance = null;

	/** Holds the command line parameters. */
	private final String[] params;

	/** 
	 * Creates a new Singleton object.
	 *
	 * @param params The command line parameters.
	 */
	protected Singleton(final String[] params) {
		this.params = params;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(Arrays.asList(this.params).toString());
		}
	}

	/** 
	 * Initialize the singleton instance.
	 *
	 * @param params parameters for initialization.
	 */
	public static void init(final String[] params) {
		instance = new Singleton(params);
	}
}

/* ########## End of File ########## */
