/*
 *     file: ChainingFinals.java
 *  package: oreilly.hcj.finalstory
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.finalstory;

/**  
 * Demonstrates a danger of chaining final initialization to watch out for.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class ChainingFinals {  
	/** A Final member */
	public final String name;

	/** Another final member */
	public final int nameLength = this.name.length();  // <== works because name has to be initalized.

	/** 
	 * A final member that wont compile.
	 *
	 * @param name __UNDOCUMENTED__
	 */

	// public final int nameLength = name.length;  // <== Wont compile;

	/** 
	 * Creates a new MixingInitialization object.
	 *
	 * @param name __UNDOCUMENTED__
	 */
	public ChainingFinals(final String name) {
		this.name = name;
	}
}

/* ########## End of File ########## */
