/*
 *     file: FinalParameters.java
 *  package: oreilly.hcj.finalstory
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.finalstory;

/**  
 * Demonstration of final constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class FinalParameters {
	/** Contains a constant for both equations. */
	private static final double M = 9.3;

	/** 
	 * Calculate the results of an equation.
	 *
	 * @param inputValue Input to the equation.
	 *
	 * @return result of the equation.
	 */
	public double equation2(double inputValue) {
		final double K = 1.414;
		final double X = 45.0;

		double result = (((Math.pow(inputValue, 3.0d) * K) + X) * M);

		double powInputValue = 0;
		if (result > 360) {
			powInputValue = X * Math.sin(result);
		} else {
			inputValue = K * Math.sin(result);
		}

		result = Math.pow(result, powInputValue);
		if (result > 360) {
			result = result / inputValue;
		}

		return result;
	}

	/** 
	 * Calculate the results of an equation.
	 *
	 * @param inputValue Input to the equation.
	 *
	 * @return result of the equation.
	 */
	public double equation2Better(final double inputValue) {
		final double K = 1.414;
		final double X = 45.0;

		double result = (((Math.pow(inputValue, 3.0d) * K) + X) * M);

		double powInputValue = 0;
		if (result > 360) {
			powInputValue = X * Math.sin(result);
		} else {
			// inputValue = K * Math.sin(result); // <= Compiler error
		}

		result = Math.pow(result, powInputValue);
		if (result > 360) {
			result = result / inputValue;
		}

		return result;
	}
}

/* ########## End of File ########## */
