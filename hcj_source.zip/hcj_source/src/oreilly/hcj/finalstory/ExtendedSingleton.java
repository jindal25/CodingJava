/*
 *     file: ExtendedSingleton.java
 *  package: oreilly.hcj.finalstory
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.finalstory;

/**  
 * A demonstration of an extensible extention of the Singleton class.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class ExtendedSingleton extends Singleton {
	/** The default for the value property. */
	private static final int DEFAULT_VALUE = 5;

	/** some value_ */
	private final int value;

	/** 
	 * Creates a new ExtendedSingleton object.
	 *
	 * @param params parameters to the singleton.
	 * @param value value to be managed in the singleton.
	 */
	protected ExtendedSingleton(final String[] params, final int value) {
		super(params);
		this.value = value;
	}

	/** 
	 * An initializer for our demo singleton that uses the default value.
	 *
	 * @param params Parameters to the singleton.
	 */
	public static void init(final String[] params) {
		instance = new ExtendedSingleton(params, DEFAULT_VALUE);
	}

	/** 
	 * An initializer for our demo singleton that uses the custom value.
	 *
	 * @param params Parameters to the singleton.
	 * @param value A value for the singleton.
	 */
	public static void init(final String[] params, final int value) {
		instance = new ExtendedSingleton(params, value);
	}

	/** 
	 * Used just to supress eclipse warnings of unused local variables; irrelevant to the
	 * example.
	 */
	protected void supress() {
		new Integer(this.value);
	}
}

/* ########## End of File ########## */
