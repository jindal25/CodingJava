/*
 *     file: FinalMethod.java
 *  package: oreilly.hcj.finalstory
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.finalstory;

/**  
 * Base class for demonstation of final methods.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class FinalMethod {
	/** A demo property. */
	private final String name;

	/** 
	 * Creates a new FinalMethodBase object.
	 *
	 * @param name The name to use.
	 */
	protected FinalMethod(final String name) {
		this.name = name;
	}

	/** 
	 * Gets the value of the property name.
	 *
	 * @return The current name.
	 */
	public final String getName() {
		return this.name;
	}

	/** 
	 * A demo method.
	 */
	public final void someMethod() {
	}
}

/* ########## End of File ########## */
