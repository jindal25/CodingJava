/*
 *     file: FinalReplacement.java
 *  package: oreilly.hcj.finalstory
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.finalstory;

import java.awt.Color;

/**  
 * Demonstrates how final variables are replaced at compilation time.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class FinalReplacement {
	/** A string constant */
	public static final String A_STRING = "Java Hardcore";

	/** An int constant. */
	public static final int AN_INT = 5;

	/** A double constant. */
	public static final double A_DOUBLE = 102.55d;

	/** An array constant. */
	public static final int[] AN_ARRAY = new int[] { 1, 2, 3, 6, 9, 18, 36 };

	/** A color constant. */
	public static final Color A_COLOR = new Color(45, 0, 155);

	/** 
	 * A demonstration method.
	 */
	public void someMethod() {
		System.out.println(A_STRING);
		System.out.println(AN_INT);
		System.out.println(A_DOUBLE);
		System.out.println(AN_ARRAY);
		System.out.println(A_COLOR);
	}
}

/* ########## End of File ########## */
