/*
 *     file: InstanceOfDemo.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import javax.swing.JPanel;

/**  
 * Demonstrates the use of instance comparisons.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class InstanceOfDemo {
	/** A set of demon objects. */
	public static final Set OBJECT_SET;

	static {
		Set objectSet = new HashSet();
		objectSet.add(new Integer(5));
		objectSet.add(new String("Hardcore Java"));
		objectSet.add(new Float(22.5f));
		objectSet.add(new JPanel());
		objectSet.add(new Character('x'));
		objectSet.add(new ArrayList());
		objectSet.add(new Double(354.5676));
		objectSet.add(null);
		OBJECT_SET = Collections.unmodifiableSet(objectSet);
	}

	/** 
	 * Demo method.
	 *
	 * @param args Command Line arguments.
	 */
	public static void main(final String[] args) {
		final Iterator iter = OBJECT_SET.iterator();
		Object obj = null;

		while (iter.hasNext()) {
			obj = iter.next();
			if (obj instanceof Number) {
				System.out.println(obj);
			}
		}
	}
}

/* ########## End of File ########## */
