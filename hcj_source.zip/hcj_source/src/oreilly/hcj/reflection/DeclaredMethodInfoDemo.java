/*
 *     file: DeclaredMethodInfoDemo.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

import java.lang.reflect.Method;

/**  
 * Prints out the declared methods on <tt>java.lang.Number</tt>.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class DeclaredMethodInfoDemo {
	/** 
	 * Demon method.
	 *
	 * @param args Command line arguments.
	 */
	public static void main(final String[] args) {
		final Method[] methods = Number.class.getDeclaredMethods();
		for (int idx = 0; idx < methods.length; idx++) {
			System.out.println(methods[idx]);
		}
	}
}

/* ########## End of File ########## */
