/*
 *     file: SomeClass.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

/**  
 * A demo bean class.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class SomeClass {
	/** The holder for the values property. */
	private String[] values = new String[0];

	/** 
	 * Setter for values.
	 *
	 * @param values The values to set.
	 */
	public void setValues(String[] values) {
		this.values = values;
	}

	/** 
	 * Setter for values.
	 *
	 * @param value The values to set.
	 * @param index The index to set.
	 */
	public void setValues(final String value, final int index) {
		this.values[index] = value;
	}

	/** 
	 * Getter for values.
	 *
	 * @return Returns the values.
	 */
	public String[] getValues() {
		return values;
	}

	/** 
	 * Getter for values.
	 *
	 * @param index The index to get.
	 *
	 * @return Returns the values.
	 */
	public String getValues(final int index) {
		return values[index];
	}
}

/* ########## End of File ########## */
