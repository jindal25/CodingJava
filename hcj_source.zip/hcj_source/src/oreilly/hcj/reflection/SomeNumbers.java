/*
 *     file: SomeNumbers.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

/**  
 * A class for demonstrating public field access.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class SomeNumbers {
	/** A demo double. */
	public double a = 21.25d;

	/** A demo float. */
	public float b = 54.5f;

	/** A Demo int */
	public int c = 5665;

	/** Another demo int. */
	public int d = 2043;

	/** Another demo int. */
	protected int e = 3121;

	/** Another demo int. */
	private int f = 1019;

	/** 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return new String("[a=" + a + ", b=" + b + ", c=" + c + ", d=" + d + ", e=" + e
		                  + ", f=" + f + "]");
	}
}

/* ########## End of File ########## */
