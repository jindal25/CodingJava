/*
 *     file: DemoToStringUsage.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

import java.util.HashSet;
import java.util.Set;
import oreilly.hcj.bankdata.*;
import oreilly.hcj.bankdata.Gender;

/**  
 * __UNDOCUMENTED__
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class DemoToStringUsage {
	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param args __UNDOCUMENTED__
	 */
	public static void main(String[] args) {
		// Create some objects.
		Person p = new Person();
		p.setFirstName("Robert");
		p.setLastName("Simmons");
		p.setGender(Gender.MALE);
		p.setTaxID("123abc456");

		Customer c = new Customer();
		c.setPerson(p);
		c.setCustomerID(new Integer(414122));
		c.setEmail("foo@bar.com");

		SavingsAccount a = new SavingsAccount();
		a.setCustomer(c);
		a.setBalance(new Float(2212.5f));
		a.setID(new Integer(412413789));
		a.setInterestRate(new Float(0.062f));

		Set accounts = new HashSet();
		accounts.add(a);
		c.setAccounts(accounts);

		// Now print them.
		System.out.println(p);
		System.out.println(c);
		System.out.println(a);
	}
}

/* ########## End of File ########## */
