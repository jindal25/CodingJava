/*
 *     file: ConstraintMapDemo.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

import java.util.Iterator;
import java.util.Map;
import oreilly.hcj.bankdata.Customer;
import oreilly.hcj.bankdata.SavingsAccount;
import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.datamodeling.constraints.NumericConstraint;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;

/**  
 * Demonstrate the constraint map functionality.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class ConstraintMapDemo {
	/** 
	 * Main demo method.
	 *
	 * @param args the command line arguments
	 */
	public static final void main(final String[] args) {
		Map constraints = MutableObject.getConstraintMap(Customer.class);
		Iterator iter = constraints.values()
			                       .iterator();
		ObjectConstraint constraint = null;
		while (iter.hasNext()) {
			constraint = (ObjectConstraint)iter.next();
			System.out.println("Property=" + constraint.getName() + " Type="
			                   + constraint.getClass().getName());
		}

		constraint = MutableObject.getConstraint(SavingsAccount.class, "interestRate");
		System.out.println("\nSavingsAccount interestRate property");
		System.out.println("dataType = "
		                   + ((NumericConstraint)constraint).getDataType().getName());
		System.out.println("minValue = " + ((NumericConstraint)constraint).getMinValue());
		System.out.println("maxValue = " + ((NumericConstraint)constraint).getMaxValue());
	}
}

/* ########## End of File ########## */
