/*
 *     file: NestedInfoDemo.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

import java.util.Arrays;
import oreilly.hcj.bankdata.Account;
import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.nested.AnonymousDemo;
import oreilly.hcj.nested.BasicMonitorScreen;
import oreilly.hcj.nested.DoubleNestedClass;
import oreilly.hcj.nested.MethodInnerClassDemo;

/**  
 * Demonstrates fetching nested class info from a Class object.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class NestedInfoDemo {
	/** 
	 * Demo method.
	 *
	 * @param args Command line arguments.
	 */
	public static void main(final String[] args) {
		printMemberClasses(BasicMonitorScreen.class);
		printMemberClasses(DoubleNestedClass.class);
		printMemberClasses(DoubleNestedClass.SomeClass.class);
		printMemberClasses(AnonymousDemo.class);
		printMemberClasses(Account.class);
		printMemberClasses(MethodInnerClassDemo.class);
		printMemberClasses(MutableObject.class);
	}

	/** 
	 * Printo out member information for a class.
	 *
	 * @param dataType The class to work with.
	 */
	public static void printMemberClasses(final Class dataType) {
		final Class[] nestedClasses = dataType.getClasses();
		final Class[] declaredNestedClasses = dataType.getDeclaredClasses();
		final Class[] nestedInterfaces = dataType.getInterfaces();
		final Class declaringClass = dataType.getDeclaringClass();

		// --
		System.out.println("Member Class infor for: " + dataType.getName());
		System.out.println("Nested Classes: " + Arrays.asList(nestedClasses));
		System.out.println("Declared Nested Classes: "
		                   + Arrays.asList(declaredNestedClasses));
		System.out.println("Interfaces: " + Arrays.asList(nestedInterfaces));
		System.out.println("Declaring Class: " + declaringClass);
		System.out.println();
	}
}

/* ########## End of File ########## */
