/*
 *     file: VariousMethodDemos.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

import java.lang.reflect.Method;

/**  
 * Demonstration of various method invocation issues.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision$
 */
public class VariousMethodDemos {
	/** 
	 * Run the demo.
	 *
	 * @param args Command line arguments (ignored).
	 */
	public static void main(final String[] args) {
		try {
			final Class[] ARG_TYPES = new Class[] { String.class };
			Object result = null;

			Method meth = Integer.class.getMethod("parseInt", ARG_TYPES);

			result = meth.invoke(null, new Object[] { new String("44") });
			System.out.println(result);

			result = meth.invoke(null, new Object[] { new String("Jonny") });
			System.out.println(result);
		} catch (final Exception ex) {
			ex.printStackTrace();
		}
	}
}

/* ########## End of File ########## */
