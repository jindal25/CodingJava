/*
 *     file: TestMutableObject.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;

/**  
 * A reflexive test case to test MutableObject descendants.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class TestMutableObject extends TestCase {
	/** The type to be tested. */
	private Class type = null;

	/** 
	 * Creates a new test on a MutableObject.
	 *
	 * @param type The type to test.
	 * @param testName The name of the text to run.
	 */
	protected TestMutableObject(final Class type, final String testName) {
		super(testName);
		assert (type != null);
		assert (MutableObject.class.isAssignableFrom(type));
		this.type = type;
	}

	/** 
	 * Gets the suite of tests for the given class.
	 *
	 * @param type The MutableObject type to test.
	 *
	 * @return The test suite.
	 *
	 * @throws NullPointerException if null is passed for the type.
	 * @throws IllegalArgumentException If a type is passed that is not a MutableObject
	 *         descendant.
	 */
	public static Test suite(final Class type) {
		if (type == null) {
			throw new NullPointerException("type");  //$NON-NLS-1$
		}
		if (!MutableObject.class.isAssignableFrom(type)) {
			throw new IllegalArgumentException("type");  //$NON-NLS-1$
		}

		TestSuite suite = new TestSuite(type.getName());
		suite.addTest(new TestMutableObject(type, "testConstraintsExist"));
		return suite;
	}

	/** 
	 * Tests that constraints exist for each of the properties in the data model.
	 *
	 * @throws RuntimeException If there is a an EntrospectionException.
	 */
	public void testConstraintsExist() {
		try {
			final PropertyDescriptor[] props =
				Introspector.getBeanInfo(type, Object.class)
				            .getPropertyDescriptors();

			for (int idx = 0; idx < props.length; idx++) {
				ObjectConstraint constraint =
					MutableObject.getConstraint(type, props[idx].getName());
				assertNotNull("Property " + props[idx].getName()
				              + " does not have a constraint.", constraint);
			}
		} catch (final IntrospectionException ex) {
			throw new RuntimeException();
		}
	}
}

/* ########## End of File ########## */
