/*
 *     file: BankDataTests.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.swingui.TestRunner;
import oreilly.hcj.bankdata.Account;
import oreilly.hcj.bankdata.AssetAccount;
import oreilly.hcj.bankdata.AutomaticPayment;
import oreilly.hcj.bankdata.BankOfficer;
import oreilly.hcj.bankdata.CreditCardAccount;
import oreilly.hcj.bankdata.Customer;
import oreilly.hcj.bankdata.Employee;
import oreilly.hcj.bankdata.ExternalTransaction;
import oreilly.hcj.bankdata.LiabilityAccount;
import oreilly.hcj.bankdata.LoanAccount;
import oreilly.hcj.bankdata.LoanApplication;
import oreilly.hcj.bankdata.OnlineCheckingAccount;
import oreilly.hcj.bankdata.Person;
import oreilly.hcj.bankdata.SavingsAccount;
import oreilly.hcj.bankdata.Transaction;

/**  
 * Test the bank data model.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class BankDataTests {
	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param args __UNDOCUMENTED__
	 */
	public static void main(final String[] args) {
		TestRunner.run(BankDataTests.class);
	}

	/** 
	 * Test the bank data model using reflexive tests.
	 *
	 * @return The test suite.
	 */
	public static Test suite() {
		TestSuite suite = new TestSuite("Online-Only Bank Datamodel Tests");
		suite.addTest(TestMutableObject.suite(Account.class));
		suite.addTest(TestMutableObject.suite(AssetAccount.class));
		suite.addTest(TestMutableObject.suite(AutomaticPayment.class));
		suite.addTest(TestMutableObject.suite(BankOfficer.class));
		suite.addTest(TestMutableObject.suite(CreditCardAccount.class));
		suite.addTest(TestMutableObject.suite(Customer.class));
		suite.addTest(TestMutableObject.suite(Employee.class));
		suite.addTest(TestMutableObject.suite(ExternalTransaction.class));
		suite.addTest(TestMutableObject.suite(LiabilityAccount.class));
		suite.addTest(TestMutableObject.suite(LoanAccount.class));
		suite.addTest(TestMutableObject.suite(LoanApplication.class));
		suite.addTest(TestMutableObject.suite(OnlineCheckingAccount.class));
		suite.addTest(TestMutableObject.suite(Person.class));
		suite.addTest(TestMutableObject.suite(SavingsAccount.class));
		suite.addTest(TestMutableObject.suite(Transaction.class));
		return suite;
	}
}

/* ########## End of File ########## */
