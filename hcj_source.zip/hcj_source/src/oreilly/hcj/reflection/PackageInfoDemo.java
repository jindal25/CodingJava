/*
 *     file: PackageInfoDemo.java
 *  package: oreilly.hcj.reflection
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.reflection;

import java.util.Collection;
import oreilly.hcj.bankdata.Account;
import oreilly.hcj.datamodeling.MutableObject;

/**  
 * Demonstrates how to get declaration information on a Class.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class PackageInfoDemo {
	/** 
	 * Demonstration Method.
	 *
	 * @param args Command line arguments.
	 */
	public static void main(final String[] args) {
		System.out.println(Object.class.getPackage());
		System.out.println(Float.class.getPackage());
		System.out.println(Collection.class.getPackage());
		System.out.println(Account.class.getPackage());
		System.out.println(MutableObject.class.getPackage());
		System.out.println(int.class.getPackage());
		System.out.println(String.class.getPackage());
	}
}

/* ########## End of File ########## */
