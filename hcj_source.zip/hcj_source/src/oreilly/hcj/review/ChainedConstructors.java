/*
 *     file: ChainedConstructors.java
 *  package: oreilly.hcj.review
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.review;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.util.Calendar;
import javax.swing.JButton;

/**  
 * Demonstration of chained constructors.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.5 $
 */
public class ChainedConstructors extends JButton implements ActionListener {
	/** 
	 * An illegal chained constructor showing attempt to use instance method.
	 *
	 * @param dataType the dataType of the class.
	 */
	public ChainedConstructors(final Class dataType) {
		// this(buildClassText(dataType), dataType.getName(), this);
		// supress eclipse warnings.
		dataType.getClass();
	}

	/** 
	 * A chained construtor showing use of embedded code.
	 *
	 * @param text Display text for the button.
	 */
	public ChainedConstructors(final String text) {
		this(text, new String("A button to show " + text), null);
	}

	/** 
	 * A chained constructor showing usage of an instance method.
	 *
	 * @param color The default color to show.
	 */
	public ChainedConstructors(final Color color) {
		this(color.toString(), "", null);
	}

	/** 
	 * A chained constructor showing usage of a static method.
	 *
	 * @param text Display text for the button.
	 * @param showDate Whether to show the creation date in the button's tooltip.
	 */
	public ChainedConstructors(final String text, final boolean showDate) {
		this(text, buildDateToolTip(text, showDate), null);
	}

	/** 
	 * A chained consturctor showign a simple call.
	 *
	 * @param text Display text for the button.
	 * @param tooltip Tool Tip for the Button.
	 */
	public ChainedConstructors(final String text, final String tooltip) {
		this(text, tooltip, null);
	}

	/** 
	 * The Primary constructor.
	 *
	 * @param text Display text for the button.
	 * @param tooltip Tool Tip for the Button.
	 * @param listener Listener to the Button.
	 */
	public ChainedConstructors(final String text, final String tooltip,
	                           final ActionListener listener) {
		setText(text);
		setToolTipText(tooltip);
		if (listener != null) {
			addActionListener(listener);
		}
	}

	/** 
	 * {@inheritDoc}
	 */
	public void actionPerformed(final ActionEvent event) {
		// just for demo reasons.
	}

	/** 
	 * Extract a short class name from the full name.
	 *
	 * @param dataType The class to operate on.
	 *
	 * @return the tool tip built.
	 */
	protected String buildClassText(final Class dataType) {
		return dataType.getName()
		               .substring(dataType.getName().lastIndexOf('.') + 1);
	}

	/** 
	 * Helper method for date based tooltip construction.
	 *
	 * @param text Display text for the button.
	 * @param showDate Whether to show the creation date in the button's tooltip.
	 *
	 * @return the constructed tooltip.
	 */
	private static String buildDateToolTip(final String text, final boolean showDate) {
		final StringBuffer buf = new StringBuffer(250);
		buf.append("A Button to show ");
		buf.append(text);
		if (showDate) {
			buf.append(" created on ");
			DateFormat df = DateFormat.getInstance();
			buf.append(df.format(Calendar.getInstance().getTime()));
		}
		return buf.toString();
	}
}

/* ########## End of File ########## */
