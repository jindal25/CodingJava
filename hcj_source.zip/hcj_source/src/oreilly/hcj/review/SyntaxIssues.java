/*
 *     file: SyntaxIssues.java
 *  package: oreilly.hcj.review
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.review;

import java.awt.Point;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**  
 * A class used to check code on the sytax issues section of the java review.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class SyntaxIssues {
	/** 
	 * Demo of unnecessary if evaluation.
	 *
	 * @param list __UNDOCUMENTED__
	 * @param target __UNDOCUMENTED__
	 */
	public static void containsNested(final List list, final Object target) {
		Iterator iter = list.iterator();
		for (Set inner = null; iter.hasNext(); inner = (Set)iter.next()) {
			if (inner != null) {
				if (inner.contains(target)) {
					// do code.
				}
			}
		}
	}

	/** 
	 * Demo of abbreviated if evaluation.
	 *
	 * @param list __UNDOCUMENTED__
	 * @param target __UNDOCUMENTED__
	 */
	public static void containsNested2(final List list, final Object target) {
		Iterator iter = list.iterator();
		for (Set inner = null; iter.hasNext(); inner = (Set)iter.next()) {
			if ((inner != null) && (inner.contains(target))) {
				// do code.
			}
		}
	}

	/** 
	 * Demo of abbreviated if evaluation.
	 *
	 * @param list __UNDOCUMENTED__
	 * @param target __UNDOCUMENTED__
	 */
	public static void containsNested3(final List list, final Object target) {
		boolean flag = false;
		Iterator iter = list.iterator();
		for (Set inner = null; iter.hasNext(); inner = (Set)iter.next()) {
			if ((inner != null) && (flag = iter.hasNext())) {
				// do code.
				target.hashCode();  // used just to supress warnings.
				if (flag) {
					// do some extra code.
				}
			}
		}
	}

	/** 
	 * __UNDOCUMENTED__
	 */
	public static void continueFunc() {
		for (int idx = 0; idx < 1000; idx++) {
			// ... do some complex code. 
			if (idx == 555) {
				break;
			}

			// ... processing code
		}

		for (int idx = 0; idx < 1000; idx++) {
			// ... do some complex code. 
			if (idx == 555) {
				continue;
			}

			// ... processing code
		}
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param input __UNDOCUMENTED__
	 *
	 * @return __UNDOCUMENTED__
	 */
	public static String decode(final int input) {
		String decoded = null;
		switch (input) {
			case 1:
				decoded = "Option 2";
				break;
			case 2:
			case 3:
				decoded = "Option 2";
				break;
			case 4:
				decoded = "Option 2";
				break;
			default:
				return "Option 3";
		}
		return decoded;
	}

	/** 
	 * Main method.
	 *
	 * @param args Arguments.
	 */
	public static final void main(final String[] args) {
		// -- Test the extract points methods.
		List points = new LinkedList();
		points.add(new Point(22, 1));
		points.add(new Point(38, 34));
		points.add(new Point(27, 22));
		points.add(new Point(12, 103));
		points.add(new Point(9, 5));

		int[] intPts = extractXCoords(points);
		for (int idx = 0; idx < intPts.length; idx++) {
			System.out.print(intPts[idx] + ", ");
		}

		System.out.println();

		int[] intPts2 = extractXCoords2(points);
		for (int idx = 0; idx < intPts2.length; idx++) {
			System.out.print(intPts2[idx] + ", ");
		}

		System.out.println();

		// -- Test ternary
		System.out.println(someMethod(new Point(5, 9)));
		System.out.println(someElegantMethod(new Point(5, 9)));
	}

	/** 
	 * Extract x coordinates from a list of <code>Point</code>s.
	 *
	 * @param points The list of points.
	 *
	 * @return The extracted coordinates
	 */
	public static int[] extractXCoords(final List points) {
		int[] results = new int[points.size()];
		Point element = null;
		int idx = 0;
		Iterator iter = points.iterator();
		while (iter.hasNext()) {
			element = (Point)iter.next();
			results[idx] = element.x;
			idx++;
		}
		return results;
	}

	/** 
	 * Extract x coordinates from a list of <code>Point</code>s.
	 *
	 * @param points The list of points.
	 *
	 * @return The extracted coordinates
	 */
	public static int[] extractXCoords2(final List points) {
		int[] results = new int[points.size()];
		Point element = null;
		Iterator iter = points.iterator();
		for (int idx = 0; iter.hasNext(); idx++) {
			element = (Point)iter.next();
			results[idx] = element.x;
		}
		return results;
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param values __UNDOCUMENTED__
	 */
	public static void matrixMeth(final Point[][] values) {
		for (int x = 0; x < values[0].length; x++) {
			for (int y = 0; y < values.length; y++) {
				if ((values[x][y].x < 0) || (values[x][y].y < 0)) {
					break;  // exit to error logging line.
				}

				// do something with the value
			}
		}
		System.err.println("Invalid Point in Matrix");
		// continue processing
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param values __UNDOCUMENTED__
	 */
	public static void matrixMeth2(final Point[][] values) {
		RESTART:  {
			for (int x = 0; x < values[0].length; x++) {
				for (int y = 0; y < values.length; y++) {
					if ((values[x][y].x < 0) || (values[x][y].y < 0)) {
						values[x][y].x = Math.max(values[x][y].x, 0);
						values[x][y].y = Math.max(values[x][y].y, 0);
						break RESTART;  // Try to process again!
					}

					// do something with the value
				}
			}
		}

		// continue processing
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param values __UNDOCUMENTED__
	 */
	public static void matrixMeth3(final Point[][] values) {
		LINE: 
		for (int x = 0; x < values[0].length; x++) {
			COLUMN: 
			for (int y = 0; y < values.length; y++) {
				if ((values[x][y].x < 0) || (values[x][y].y < 0)) {
					continue LINE;  // skip the rest of the line;
				}

				// do something with the value
			}
		}
		LOGLINE: 
		System.err.println("Invalid Point in Matrix");

		// continue processing
		PASS_TWO: 
		for (int x = 0; x < values[0].length; x++) {
			// do some code.
		}
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param p __UNDOCUMENTED__
	 *
	 * @return __UNDOCUMENTED__
	 */
	public static int someElegantMethod(final Point p) {
		return (p == null) ? 0 : (p.x + p.y);
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param p __UNDOCUMENTED__
	 *
	 * @return __UNDOCUMENTED__
	 */
	public static int someMethod(final Point p) {
		if (p == null) {
			return 0;
		} else {
			return p.x + p.y;
		}
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @return __UNDOCUMENTED__
	 */
	protected Object someHelperMethod() {
		Object result = null;

		// ... do some code that sets result.
		assert (result != null);  // check post condition.
		return result;
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param set __UNDOCUMENTED__
	 */
	protected void someLoop(final Set set) {
		Iterator iter = set.iterator();
		while (iter.hasNext()) {
			String element = (String)iter.next();
			System.out.println(element.length());
		}
	}
}

/* ########## End of File ########## */
