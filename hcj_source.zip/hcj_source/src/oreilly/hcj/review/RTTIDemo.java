/*
 *     file: RTTIDemo.java
 *  package: oreilly.hcj.review
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.review;

/**  
 * A demonstration of Run Time Type Identifictation, RTTI, in Java.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.5 $
 */
public class RTTIDemo {
	/** 
	 * Demonstrates basic RTTI functionality.
	 */
	public static final void basicRTTIDemo() {
		Float y = new Float(15.0);
		String name = "Fred";
		System.out.println(y.getClass());
		System.out.println(name.getClass());
	}

	/** 
	 * Demonstrates how RTTI enforces type safety.
	 */
	public static final void castingWithRTTI() {
		A a = null;
		A a1 = new A();
		B b = new B();
		C c = new C();

		a = (A)b;  // no problem
		b = (B)a;  // still no problem, casting back to what it was created as. 
		a = a1;  // Same type so no problem
		Object d = (Object)c;  // no problem becasue of implicit inheritance
		c = (C)d;  // casting back
	}

	/** 
	 * Main demonstration method.
	 *
	 * @param args Command line arguments.
	 */
	public static final void main(String[] args) {
		basicRTTIDemo();
	}

	/**  
	 * A class for demonstration purposes.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.5 $
	 */
	public static class A {
	}

	/**  
	 * A class for demonstration purposes.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.5 $
	 */
	public static class B extends A {
	}

	/**  
	 * A class for demonstration purposes.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.5 $
	 */
	public static class C {
	}
}

/* ########## End of File ########## */
