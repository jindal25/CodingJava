/*
 *     file: Assertions.java
 *  package: oreilly.hcj.review
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.review;

import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**  
 * Class for checking syntax and comments for the assert section of the review chapter.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class Assertions {
	/** 
	 * Main method.
	 *
	 * @param args Command line arguments.
	 */
	public static void main(final String[] args) {
		helperParseArgs(args);
		Iterator iter = System.getProperties()
			                  .keySet()
			                  .iterator();
		for (String key = null; iter.hasNext(); key = (String)iter.next()) {
			assert (key != null);
			System.out.println(key + "=" + System.getProperty(key));
		}
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param event __UNDOCUMENTED__
	 */
	public void mouseClicked(final MouseEvent event) {
		Object source = event.getSource();
		assert (source != null);

		// ... do code using source
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param args __UNDOCUMENTED__
	 *
	 * @throws IllegalArgumentException __UNDOCUMENTED__
	 */
	protected static void helperParseArgs(final String[] args) {
		assert (args != null);
		assert (!Arrays.asList(args)
		               .contains(null));
		// --
		List arglist = Arrays.asList(args);
		Iterator iter = arglist.iterator();
		for (String argument = null; iter.hasNext(); argument = (String)iter.next()) {
			if (argument.startsWith("-D")) {
				if (argument.length() < 3) {
					int idx = arglist.indexOf(argument);
					throw new IllegalArgumentException("Argument" + idx
					                                   + " is not a legal property argument.");
				}
				int valueIdx = argument.indexOf('=');
				System.setProperty(argument.substring(2, valueIdx),
				                   argument.substring(valueIdx + 1));
				assert (System.getProperty(argument.substring(2, valueIdx)).equals(argument
				                                                                   .substring(valueIdx
				                                                                              + 1)));
			}
		}
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param args __UNDOCUMENTED__
	 *
	 * @throws IllegalArgumentException __UNDOCUMENTED__
	 */
	protected static void helperParseArgs2(final String[] args) {
		assert (args != null);
		assert (!Arrays.asList(args)
		               .contains(null));
		// --
		List arglist = Arrays.asList(args);
		Iterator iter = arglist.iterator();
		for (String argument = null; iter.hasNext(); argument = (String)iter.next()) {
			if (argument.startsWith("-D")) {
				if (argument.length() < 3) {
					int idx = arglist.indexOf(argument);
					throw new IllegalArgumentException("Argument" + idx
					                                   + " is not a legal property argument.");
				}
				int valueIdx = argument.indexOf('=');
				String key = argument.substring(2, valueIdx);
				String value = argument.substring(valueIdx + 1);
				System.setProperty(key, value);
				assert (System.getProperty(key).equals(value));
			}
		}
	}
}

/* ########## End of File ########## */
