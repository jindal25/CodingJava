/*
 *     file: FriendBean.java
 *  package: oreilly.hcj.review
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.review;

import java.util.Calendar;
import oreilly.hcj.datamodeling.MutableObject;

/**  
 * A demondstartion of a bean that uses friend access.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.5 $
 */
public class FriendBean extends MutableObject {
	/** A value property. */
	private int value;

	/** 
	 * Creates a new FriendBean object.
	 */
	public FriendBean() {
		super();
	}

	/** 
	 * Setter for the property value.
	 *
	 * @param value The new value for the prooperty.
	 *
	 * @throws IllegalArgumentException If the value is greater than 10.
	 */
	public void setValue(final int value) {
		if (value > 10) {
			throw new IllegalArgumentException();
		}
		int oldValue = this.value;
		this.value = value;
		propertyChangeSupport.firePropertyChange("value", oldValue, value);
	}

	/** 
	 * Getter for the property value.
	 *
	 * @return The current value of the property value.
	 */
	public int getValue() {
		return value;
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof FriendBean)) {
			return false;
		} else {
			return (((FriendBean)obj).getValue() == this.value);
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return new Integer(this.value).hashCode();
	}

	/** 
	 * A utility method someone might call.
	 */
	public void someBetterMethod() {
		if (Calendar.getInstance()
		            .get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY) {
			this.setValue(25);
		}
	}

	/** 
	 * A utility method someone might call.
	 */
	public void someMethod() {
		if (Calendar.getInstance()
		            .get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY) {
			this.value = 25;
		}
	}
}

/* ########## End of File ########## */
