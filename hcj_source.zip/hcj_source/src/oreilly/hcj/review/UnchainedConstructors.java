/*
 *     file: UnchainedConstructors.java
 *  package: oreilly.hcj.review
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.review;

import java.awt.event.ActionListener;
import javax.swing.JButton;

/**  
 * Demonstration of unchained constructors.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class UnchainedConstructors extends JButton {
	/** 
	 * Constructor for only the panel name.
	 *
	 * @param text Display text for the button.
	 */
	public UnchainedConstructors(final String text) {
		setText(text);
		String tooltip = new String("A button to show " + text);
		setToolTipText(tooltip);
	}

	/** 
	 * Constructor for only the tool tip and panel name.
	 *
	 * @param text Display text for the button.
	 * @param tooltip Tool Tip for the panel.
	 */
	public UnchainedConstructors(final String text, final String tooltip) {
		setText(text);
		setToolTipText(tooltip);
	}

	/** 
	 * Constructor for all parameters.
	 *
	 * @param text Display text for the button.
	 * @param tooltip Tool Tip for the panel.
	 * @param listener Listener to the panel.
	 */
	public UnchainedConstructors(final String text, final String tooltip,
	                             final ActionListener listener) {
		setText(text);
		setToolTipText(tooltip);
		addActionListener(listener);
	}
}

/* ########## End of File ########## */
