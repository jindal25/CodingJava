/*
 *     file: InterestRateDialog.java
 *  package: oreilly.hcj.datamodeling
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import oreilly.hcj.bankdata.LiabilityAccount;
import oreilly.hcj.datamodeling.constraints.ConstraintException;

/**  
 * Demonstrates using constraints in a GUI.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public class InterestRateDialog extends JDialog implements ActionListener {
	/** Holds the ok button. */
	private JButton okBtn;

	/** Holds the balance field. */
	private JTextField interestRateField;

	/** 
	 * Creates a new ConstraintGUIDemo object.
	 */
	private InterestRateDialog() {
		setModal(true);

		final Container contentPane = getContentPane();
		contentPane.setLayout(new GridLayout(3, 1));

		JLabel interestRateLabel =
			new JLabel("Enter an Interst Rate (Between "
			           + LiabilityAccount.INTEREST_RATE_CONSTRAINT.getMinValue()
			           + " and "
			           + LiabilityAccount.INTEREST_RATE_CONSTRAINT.getMaxValue() + ")");
		contentPane.add(interestRateLabel);

		interestRateField = new JTextField(15);
		contentPane.add(interestRateField);

		okBtn = new JButton("OK");
		okBtn.addActionListener(this);
		contentPane.add(okBtn);

		pack();
	}

	/** 
	 * Run the demo.
	 *
	 * @param args Command line arguments.
	 */
	public static final void main(final String[] args) {
		InterestRateDialog demo = new InterestRateDialog();
		demo.show();
		System.exit(0);
	}

	/** 
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(final ActionEvent event) {
		Object src = event.getSource();
		if (src == okBtn) {
			float value = Float.parseFloat(interestRateField.getText());
			try {
				LiabilityAccount.INTEREST_RATE_CONSTRAINT.validate(new Float(value));
				// do something with the value. 
				dispose();
			} catch (final ConstraintException ex) {
				Toolkit.getDefaultToolkit()
				       .beep();
				interestRateField.requestFocus();
				interestRateField.selectAll();
			}
		}
	}
}

/* ########## End of File ########## */
