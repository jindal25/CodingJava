/*
 *     file: Purchase.java
 *  package: oreilly.hcj.datamodeling
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling;

import oreilly.hcj.datamodeling.constraints.NumericConstraint;
import oreilly.hcj.datamodeling.constraints.StringConstraint;

/**  
 * A purchase object.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.5 $
 */
public class Purchase extends MutableObject {
	/** Constraint for the property purchaseID. */
	public static final NumericConstraint PURCHASE_ID_CONSTRAINT =
		new NumericConstraint("purchaseID", false, Integer.class, new Integer(0),
		                      new Integer(Integer.MAX_VALUE));

	/** Constraint for the property itemSKU. */
	public static final StringConstraint ITEM_SKU_CONSTRAINT =
		new StringConstraint("itemSKU", false, 30);

	/** Constraint for the property pricePaid. */
	public static final NumericConstraint PRICE_PAID_CONSTRAINT =
		new NumericConstraint("pricePaid", false, Float.class, new Float(0),
		                      new Float(Float.MAX_VALUE));

	/** Holds the value of the property lastName. */
	Float pricePaid;

	/** Holds the value of the property customerID. */
	Integer purchaseID;

	/** Holds the value of the property firstName. */
	String itemSKU;

	/** 
	 * Sets the value of the property itemSKU.
	 *
	 * @param itemSKU The new value.
	 */
	public void setFirstName(final String itemSKU) {
		ITEM_SKU_CONSTRAINT.validate(itemSKU);
		final String oldItemSKU = this.itemSKU;
		this.itemSKU = itemSKU;
		propertyChangeSupport.firePropertyChange("itemSKU", oldItemSKU, this.itemSKU);
	}

	/** 
	 * Gets the value of the property itemSKU.
	 *
	 * @return itemSKU The new value.
	 */
	public String getItemSKU() {
		return this.itemSKU;
	}

	/** 
	 * Sets the value of the property pricePaid.
	 *
	 * @param pricePaid The new value.
	 */
	public void setPricePaid(final Float pricePaid) {
		PRICE_PAID_CONSTRAINT.validate(pricePaid);
		final Float oldPricePaid = this.pricePaid;
		this.pricePaid = pricePaid;
		propertyChangeSupport.firePropertyChange("pricePaid", oldPricePaid, this.pricePaid);
	}

	/** 
	 * Gets the value of the property pricePaid.
	 *
	 * @return pricePaid The new value.
	 */
	public Float getPricePaid() {
		return this.pricePaid;
	}

	/** 
	 * Sets the value of the property purchaseID.
	 *
	 * @param purchaseID The new value.
	 */
	public void setPurchaseID(final Integer purchaseID) {
		PURCHASE_ID_CONSTRAINT.validate(purchaseID);
		final Integer oldPurchaseID = this.purchaseID;
		this.purchaseID = purchaseID;
		propertyChangeSupport.firePropertyChange("purchaseID", oldPurchaseID,
		                                         this.purchaseID);
	}

	/** 
	 * Gets the value of the property purchaseID.
	 *
	 * @return purchaseID The new value.
	 */
	public Integer getPurchaseID() {
		return this.purchaseID;
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof Purchase)) {
			return false;
		} else {
			return (((Purchase)obj).getPurchaseID().equals(this.purchaseID));
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.purchaseID.hashCode();
	}
}

/* ########## End of File ########## */
