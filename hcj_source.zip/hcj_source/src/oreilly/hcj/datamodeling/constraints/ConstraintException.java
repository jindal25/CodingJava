/*
 *     file: ConstraintException.java
 *  package: oreilly.hcj.datamodeling.constraints
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling.constraints;

/**  
 * Defines a RuntimeException for constraint violations.
 * 
 * <p>
 * Objects of this class are immutable.
 * </p>
 *
 * @author <a href="mailto:worderisor@yahoo.com">Robert Simmons jr.</a>
 * @version $Revision: 1.1 $
 */
public final class ConstraintException extends RuntimeException {
	/**
	 * Holds value of property specifier.  This property tells the user what type of
	 * exception was created.
	 */
	private ConstraintExceptionType exceptionType;

	/** 
	 * Creates a new instance of <code>ConstraintViolatedException</code>. The message is
	 * set to show whatever specifier was given.
	 *
	 * @param exceptionType DOCUMENT ME!
	 */
	public ConstraintException(final ConstraintExceptionType exceptionType) {
		super(" specifier = " + exceptionType.getName());  //$NON-NLS-1$
		this.exceptionType = exceptionType;
	}

	/** 
	 * Constructs an instance of ConstraintViolatedException with the specified  detail
	 * message.
	 *
	 * @param exceptionType DOCUMENT ME!
	 * @param msg the detail message.
	 */
	public ConstraintException(final ConstraintExceptionType exceptionType,
	                           final String msg) {
		super(msg);
		this.exceptionType = exceptionType;
	}

	/** 
	 * Getter for property specifier. The specifier indicates what kind of exception
	 * occurred.
	 *
	 * @return Value of property specifier.
	 */
	public ConstraintExceptionType getExceptionType() {
		return this.exceptionType;
	}
}

/* ########## End of File ########## */
