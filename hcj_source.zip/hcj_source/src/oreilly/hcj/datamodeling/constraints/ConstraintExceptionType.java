/*
 *     file: ConstraintExceptionType.java
 *  package: oreilly.hcj.datamodeling.constraints
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling.constraints;

import oreilly.hcj.constants.ConstantObject;

/**  
 * Defines valid types of constraint exceptions.
 *
 * @author <a href="mailto:worderisor@yahoo.com">Robert Simmons jr.</a>
 * @version $Revision: 1.1 $
 */
public class ConstraintExceptionType extends ConstantObject {
	/** Type for when a null is given but not allowed. */
	public static final ConstraintExceptionType NULL_NOT_ALLOWED =
		new ConstraintExceptionType("NULL_NOT_ALLOWED");  //$NON-NLS-1$

	/** Type for when a String is too long. */
	public static final ConstraintExceptionType STRING_TOO_LONG =
		new ConstraintExceptionType("STRING_TOO_LONG");  //$NON-NLS-1$

	/** Type for when a String is too long. */
	public static final ConstraintExceptionType ARRAY_TOO_LARGE =
		new ConstraintExceptionType("ARRAY_TOO_LARGE");  //$NON-NLS-1$

	/** Type for when a number is too large. */
	public static final ConstraintExceptionType VALUE_ABOVE_MAXIMUM =
		new ConstraintExceptionType("VALUE_ABOVE_MAXIMUM");  //$NON-NLS-1$

	/** Type for when a number is too small. */
	public static final ConstraintExceptionType VALUE_BELOW_MINIMUM =
		new ConstraintExceptionType("VALUE_BELOW_MINIMUM");  //$NON-NLS-1$

	/** Type for when an empty set is given. */
	public static final ConstraintExceptionType COLLECTION_CANNOT_BE_EMPTY =
		new ConstraintExceptionType("COLLECTION_CANNOT_BE_EMPTY");  //$NON-NLS-1$

	/** Type for when an empty map is given. */
	public static final ConstraintExceptionType MAP_CANNOT_BE_EMPTY =
		new ConstraintExceptionType("MAP_CANNOT_BE_EMPTY");  //$NON-NLS-1$

	/** Type for when a map value is null. */
	public static final ConstraintExceptionType INVALID_MAP_KEY_TYPE =
		new ConstraintExceptionType("INVALID_MAP_KEY_TYPE");  //$NON-NLS-1$

	/** Type for when a map value is null. */
	public static final ConstraintExceptionType INVALID_MAP_VALUE_TYPE =
		new ConstraintExceptionType("INVALID_MAP_VALUE_TYPE");  //$NON-NLS-1$

	/** Type for when a map value is null. */
	public static final ConstraintExceptionType MAP_CANNOT_HAVE_NULL_VALUE =
		new ConstraintExceptionType("MAP_CANNOT_HAVE_NULL_VALUE");  //$NON-NLS-1$

	/** Type for when a map value contains an invalid data type. */
	public static final ConstraintExceptionType MAP_CONTAINS_INVALID_VALUE =
		new ConstraintExceptionType("MAP_CONTAINS_INVALID_VALUE");  //$NON-NLS-1$

	/** Type for when a set contains a type not expected. */
	public static final ConstraintExceptionType INVALID_COLLECTION_MEMBER =
		new ConstraintExceptionType("INVALID_COLLECTION_MEMBER");  //$NON-NLS-1$

	/** Type for when a number is too small. */
	public static final ConstraintExceptionType INVALID_DATA_TYPE =
		new ConstraintExceptionType("INVALID_DATA_TYPE");  //$NON-NLS-1$

	/** 
	 * Creates a new instance of ConstraintExceptionType.
	 *
	 * @param name The name for the <code>ConstraintExceptionType</code>.
	 *
	 * @see mirror.utilities.ConstantObject
	 */
	private ConstraintExceptionType(final String name) {
		super(name);
	}
}

/* ########## End of File ########## */
