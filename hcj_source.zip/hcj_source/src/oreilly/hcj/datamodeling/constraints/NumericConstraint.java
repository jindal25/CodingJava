/*
 *     file: NumericConstraint.java
 *  package: oreilly.hcj.datamodeling.constraints
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling.constraints;

/**  
 * Models a constraint on a numerical entity.
 * 
 * <p>
 * Objects of this class are immutable.
 * </p>
 *
 * @author <a href="mailto:worderisor@yahoo.com">Robert Simmons jr.</a>
 * @version $Revision: 1.1 $
 */
public class NumericConstraint extends ObjectConstraint {
	/** Error message for a non number type passed. */
	private static final String ERR_NOT_NUMBER = "The dataType must be a Number";  //$NON-NLS-1$

	/** Error message for a type mismatch. */
	private static final String ERR_MISMATCH =
		"The min and max value type must match the data type.";  //$NON-NLS-1$

	/** Holds value of property maxValue. */
	private Number maxValue;

	/** Holds value of property minValue. */
	private Number minValue;

	/** 
	 * Creates a new instance of NumericConstraint. Note that since the values for min
	 * and max have to be of type Number, the numberType class must likewise be a
	 * descendant of that class otherwise the construction of the constraint wotn work.
	 *
	 * @param name Contains the name of the constraint.
	 * @param optional Indicates if the property is optional.
	 * @param dataType The type of number this class is validating.
	 * @param minValue The minimum value for the number.
	 * @param maxValue The maximum value for the number.
	 *
	 * @throws IllegalArgumentException If dataType is not a subclass of
	 *         java.lang.Number.
	 *
	 * @see java.lang.Number
	 * @see mirror.datamodel.constraints.Constraint
	 */
	public NumericConstraint(final String name, final boolean optional,
	                         final Class dataType, final Number minValue,
	                         final Number maxValue) {
		super(name, optional, dataType);
		if (!Number.class.isAssignableFrom(dataType)) {
			throw new IllegalArgumentException(ERR_NOT_NUMBER);
		}
		if (!(minValue.getClass().equals(dataType))) {
			throw new IllegalArgumentException(ERR_MISMATCH);
		}
		if (!(maxValue.getClass().equals(dataType))) {
			throw new IllegalArgumentException(ERR_MISMATCH);
		}

		// ** validation done
		this.minValue = minValue;
		this.maxValue = maxValue;
	}

	/** 
	 * Getter for property maxValue.
	 *
	 * @return Value of property maxValue.
	 */
	public Number getMaxValue() {
		return this.maxValue;
	}

	/** 
	 * Getter for property minValue.
	 *
	 * @return Value of property minValue.
	 */
	public Number getMinValue() {
		return this.minValue;
	}

	/** 
	 * Validate the given object against the constraint. Implements all the constraints
	 * of the superclass Constraint. The number is validated to make sure it is between
	 * the min and max values.
	 *
	 * @param obj The object to validate.
	 *
	 * @throws ConstraintException If the constraint is violated.
	 */
	public void validate(final Object obj) {
		super.validate(obj);
		if (obj != null) {
			if (((Comparable)obj).compareTo(minValue) < 0) {
				throw new ConstraintException(ConstraintExceptionType.VALUE_BELOW_MINIMUM);
			}
			if (((Comparable)obj).compareTo(maxValue) > 0) {
				throw new ConstraintException(ConstraintExceptionType.VALUE_ABOVE_MAXIMUM);
			}
		}
	}
}

/* ########## End of File ########## */
