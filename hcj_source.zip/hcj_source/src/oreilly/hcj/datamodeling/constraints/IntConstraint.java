/*
 *     file: IntConstraint.java
 *  package: oreilly.hcj.datamodeling.constraints
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling.constraints;

/**  
 * A constraint for properties of type int.
 *
 * @author <a href="mailto:worderisor@yahoo.com">Robert Simmons jr.</a>
 * @version $Revision: 1.1 $
 */
public class IntConstraint extends Constraint {
	/** The maximum legal value. */
	private int maxValue;

	/** The minimum legal value. */
	private int minValue;

	/** 
	 * Creates a new IntConstraint object.
	 *
	 * @param name Contains the name of the constraint
	 * @param minValue The minimum legal value.
	 * @param maxValue The maximum legal value.
	 *
	 * @see mirror.datamodel.constraints.Constraint
	 */
	public IntConstraint(final String name, final int minValue, final int maxValue) {
		super(name);
		this.minValue = minValue;
		this.maxValue = maxValue;
	}

	/** 
	 * Get the maximum legal value for the property beign constrained.
	 *
	 * @return The maximum legal value.
	 */
	public int getMaxValue() {
		return this.maxValue;
	}

	/** 
	 * Get the minimum legal value for the property beign constrained.
	 *
	 * @return The minimum legal value.
	 */
	public int getMinValue() {
		return this.minValue;
	}

	/** 
	 * Validate the given object against the constraint.
	 *
	 * @param value The value to validate.
	 *
	 * @throws ConstraintException If the constraint is violated.
	 */
	public void validate(final int value) {
		if (minValue > value) {
			throw new ConstraintException(ConstraintExceptionType.VALUE_BELOW_MINIMUM);
		}
		if (maxValue < value) {
			throw new ConstraintException(ConstraintExceptionType.VALUE_ABOVE_MAXIMUM);
		}
	}
}

/* ########## End of File ########## */
