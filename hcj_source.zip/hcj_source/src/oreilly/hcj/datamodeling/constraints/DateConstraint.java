/*
 *     file: DateConstraint.java
 *  package: oreilly.hcj.datamodeling.constraints
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling.constraints;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

/**  
 * Models a constraint on Date objects.
 * 
 * <p>
 * Objects of this class are immutable.
 * </p>
 *
 * @author <a href="mailto:worderisor@yahoo.com">Robert Simmons jr.</a>
 * @version $Revision: 1.1 $
 */
public class DateConstraint extends ObjectConstraint {
	/** Holds value of property maxSize. */
	protected Date maxDate;

	/** Holds value of property minDate. */
	private Date minDate;

	/** 
	 * Creates a new instance of DateConstraint.
	 *
	 * @param name Contains the name of the constraint.
	 * @param optional Indicates if the property is optional.
	 * @param minDate The minimum date to allow.
	 * @param maxDate The maximum date to allow.
	 *
	 * @see mirror.datamodel.constraints.Constraint
	 */
	public DateConstraint(final String name, final boolean optional, final Date minDate,
	                      final Date maxDate) {
		super(name, optional, Date.class);
		this.minDate = minDate;
		this.maxDate = maxDate;
	}

	/** 
	 * Creates a new instance of DateConstraint.
	 * 
	 * <p>
	 * Allows the min and max dates to be given as short style dates in the given locale.
	 * Note that the class uses java.text.DateFormat to parse the dates.
	 * </p>
	 *
	 * @param name Contains the name of the constraint.
	 * @param optional Indicates if the property is optional.
	 * @param minDate The minimum date to allow; Short Date style.
	 * @param maxDate The maximum date to allow; Stort Date Style.
	 * @param locale The locale to use for parsing the date.
	 *
	 * @throws NullPointerException If locale is null.
	 * @throws IllegalArgumentException If the minDate or maxDate don't parse correctly.
	 *
	 * @see java.text.DateFormat
	 * @see mirror.datamodel.constraints.Constraint
	 */
	public DateConstraint(final String name, final boolean optional,
	                      final String minDate, final String maxDate, final Locale locale) {
		super(name, optional, Date.class);

		if (locale == null) {
			throw new NullPointerException("locale can't be null.");  //$NON-NLS-1$
		}

		String parsingDate = null;

		try {
			DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, locale);
			parsingDate = "minDate";  //$NON-NLS-1$
			this.minDate = df.parse(minDate);
			parsingDate = "maxDate";  //$NON-NLS-1$
			this.maxDate = df.parse(maxDate);
		} catch (ParseException ex) {
			throw new IllegalArgumentException(parsingDate + " : " + ex.getMessage());  //$NON-NLS-1$
		}
	}

	/** 
	 * Getter for property maxSize.
	 *
	 * @return Value of property maxSize.
	 */
	public Date getMaxDate() {
		return this.maxDate;
	}

	/** 
	 * Getter for property minDate.
	 *
	 * @return Value of property minDate.
	 */
	public Date getMinDate() {
		return this.minDate;
	}

	/** 
	 * Validate the given object against the constraint.
	 * 
	 * <p>
	 * Checks to make sure the array is within the size limitation and then passes
	 * checking to the superclass.
	 * </p>
	 *
	 * @param obj The object to validate.
	 *
	 * @throws ConstraintException If the constraint is violated.
	 */
	public void validate(final Object obj) {
		super.validate(obj);

		if (obj != null) {
			Date d = (Date)obj;

			if (d.compareTo(minDate) < 0) {
				throw new ConstraintException(ConstraintExceptionType.VALUE_BELOW_MINIMUM);
			}

			if (d.compareTo(maxDate) > 0) {
				throw new ConstraintException(ConstraintExceptionType.VALUE_ABOVE_MAXIMUM);
			}
		}
	}
}

/* ########## End of File ########## */
