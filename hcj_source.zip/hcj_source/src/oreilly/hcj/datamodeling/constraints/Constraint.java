/*
 *     file: Constraint.java
 *  package: oreilly.hcj.datamodeling.constraints
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling.constraints;

/**  
 * Base class for all constraint types.
 *
 * @author <a href="mailto:worderisor@yahoo.com">Robert Simmons jr.</a>
 * @version $Revision: 1.1 $
 */
public abstract class Constraint {
	/** Holds value of property name. */
	private String name;

	/** 
	 * Creates a new Constraint object.
	 *
	 * @param name Contains the name of the constraint
	 */
	protected Constraint(final String name) {
		this.name = name;
	}

	/** 
	 * Getter for property name.
	 *
	 * @return Value of property name.
	 */
	public String getName() {
		return this.name;
	}
}

/* ########## End of File ########## */
