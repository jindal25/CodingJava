/*
 *     file: StringConstraint.java
 *  package: oreilly.hcj.datamodeling.constraints
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling.constraints;

/**  
 * Models a constraint on a String object.
 * 
 * <p>
 * Objects of this class are immutable.
 * </p>
 *
 * @author <a href="mailto:worderisor@yahoo.com">Robert Simmons jr.</a>
 * @version $Revision: 1.1 $
 */
public class StringConstraint extends ObjectConstraint {
	/** Holds value of property maxLength. */
	private int maxLength;

	/** 
	 * Creates a new instance of StringConstraint.
	 *
	 * @param name Contains the name of the constraint.
	 * @param optional Indicates if the property is optional.
	 * @param maxLength The maximum length of the String.
	 *
	 * @see mirror.datamodel.constraints.Constraint
	 */
	public StringConstraint(final String name, final boolean optional, final int maxLength) {
		super(name, optional, String.class);
		this.maxLength = maxLength;
	}

	/** 
	 * Getter for property maxLength.
	 *
	 * @return Value of property maxLength.
	 */
	public int getMaxLength() {
		return this.maxLength;
	}

	/** 
	 * Validate the given object against the constraint. Checks to make sure the string
	 * is not null if not allowed. If a non-null string is passed then the string is
	 * validated to make sure it isn't too long.
	 *
	 * @param obj The object to validate.
	 *
	 * @throws ConstraintException If the constraint is violated.
	 */
	public void validate(final Object obj) {
		super.validate(obj);

		if (obj != null) {
			String tgtString = (String)obj;

			if (tgtString.length() > maxLength) {
				throw new ConstraintException(ConstraintExceptionType.STRING_TOO_LONG);
			}
		}
	}
}

/* ########## End of File ########## */
