/*
 *     file: Customer.java
 *  package: oreilly.hcj.datamodeling
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.datamodeling;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import oreilly.hcj.datamodeling.constraints.CollectionConstraint;
import oreilly.hcj.datamodeling.constraints.NumericConstraint;
import oreilly.hcj.datamodeling.constraints.StringConstraint;

/**  
 * A customer object.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.5 $
 */
public class Customer extends MutableObject {
	/** Constraint for the property customerID. */
	public static final NumericConstraint CUSTOMER_ID_CONSTRAINT =
		new NumericConstraint("customerID", false, Integer.class, new Integer(0),
		                      new Integer(Integer.MAX_VALUE));

	/** Constraint for the property firstName. */
	public static final StringConstraint FIRST_NAME_CONSTRAINT =
		new StringConstraint("firstName", false, 30);

	/** Constraint for the property lastName. */
	public static final StringConstraint LAST_NAME_CONSTRAINT =
		new StringConstraint("lastName", false, 30);

	/** Constraint for the property phone. */
	public static final StringConstraint PHONE_CONSTRAINT =
		new StringConstraint("phone", false, 20);

	/** Constraint for the property purchases. */
	public static final CollectionConstraint PURCHASES_CONSTRAINT =
		new CollectionConstraint("purchases", false, List.class, Purchase.class);

	/** Holds the value of the property customerID. */
	Integer customerID;

	/** Holds the value of the property purchases. */
	List purchases;

	/** Holds the value of the property firstName. */
	String firstName;

	/** Holds the value of the property lastName. */
	String lastName;

	/** Holds the value of the property phone. */
	String phone;

	/** 
	 * Sets the value of the property customerID.
	 *
	 * @param customerID The new value.
	 */
	public void setCustomerID(final Integer customerID) {
		CUSTOMER_ID_CONSTRAINT.validate(customerID);
		final Integer oldCustomerID = this.customerID;
		this.customerID = customerID;
		propertyChangeSupport.firePropertyChange("customerID", oldCustomerID,
		                                         this.customerID);
	}

	/** 
	 * Gets the value of the property customerID.
	 *
	 * @return customerID The new value.
	 */
	public Integer getCustomerID() {
		return this.customerID;
	}

	/** 
	 * Sets the value of the property firstName.
	 *
	 * @param firstName The new value.
	 */
	public void setFirstName(final String firstName) {
		FIRST_NAME_CONSTRAINT.validate(firstName);
		final String oldFirstName = this.firstName;
		this.firstName = firstName;
		propertyChangeSupport.firePropertyChange("firstName", oldFirstName, this.firstName);
	}

	/** 
	 * Gets the value of the property firstName.
	 *
	 * @return firstName The new value.
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/** 
	 * Sets the value of the property lastName.
	 *
	 * @param lastName The new value.
	 */
	public void setLastName(final String lastName) {
		LAST_NAME_CONSTRAINT.validate(lastName);
		final String oldLastName = this.lastName;
		this.lastName = lastName;
		propertyChangeSupport.firePropertyChange("lastName", oldLastName, this.lastName);
	}

	/** 
	 * Gets the value of the property lastName.
	 *
	 * @return lastName The new value.
	 */
	public String getLastName() {
		return this.lastName;
	}

	/** 
	 * Sets the value of the property phone.
	 *
	 * @param phone The new value.
	 */
	public void setPhone(final String phone) {
		PHONE_CONSTRAINT.validate(phone);
		final String oldPhone = this.phone;
		this.phone = phone;
		propertyChangeSupport.firePropertyChange("phone", oldPhone, this.phone);
	}

	/** 
	 * Gets the value of the property phone.
	 *
	 * @return phone The new value.
	 */
	public String getPhone() {
		return this.phone;
	}

	/** 
	 * Sets the value of the property purchases.
	 *
	 * @param purchases The new value.
	 */
	public void setPurchases(final List purchases) {
		PURCHASES_CONSTRAINT.validate(purchases);
		final List oldPurchases = getPurchases();
		this.purchases = new ArrayList(purchases);
		propertyChangeSupport.firePropertyChange("purchases", oldPurchases, this.purchases);
	}

	/** 
	 * Gets the value of the property purchases.
	 *
	 * @return purchases The new value.
	 */
	public List getPurchases() {
		return Collections.unmodifiableList(this.purchases);
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof Customer)) {
			return false;
		} else {
			return (((Customer)obj).getCustomerID().equals(this.customerID));
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.customerID.hashCode();
	}
}

/* ########## End of File ########## */
