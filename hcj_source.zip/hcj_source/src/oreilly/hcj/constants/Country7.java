/*
 *     file: Country7.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * Holds country constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public final class Country7 extends ConstantObject {
	/** Contry constant for Canada. */
	public static final Country7 CANADA = new Country7("CANADA", "CA");

	/** Contry constant for Croatia. */
	public static final Country7 CROATIA = new Country7("CROATIA", "HR");

	/** Contry constant for Germany. */
	public static final Country7 GERMANY = new Country7("GERMANY", "DE");

	/** Contry constant for Italy. */
	public static final Country7 ITALY = new Country7("ITALY", "IT");

	/** Contry constant for Mexico. */
	public static final Country7 MEXICO = new Country7("MEXICO", "MX");

	/** Contry constant for the UK. */
	public static final Country7 UK = new Country7("UK", "UK");

	/** Contry constant for the USA. */
	public static final Country7 USA = new Country7("USA", "US");

	/** Contry constant for the Venezuela. */
	public static final Country7 VENEZUELA = new Country7("VENEZUELA", "VZ");

	/** Holds the abbreviation for the Country. */
	private final String abbreviation;

	/** 
	 * Creates a new Country7.
	 *
	 * @param name The name for the country type.
	 * @param abbreviation The abbreviation for the country.
	 */
	private Country7(final String name, final String abbreviation) {
		super(name);
		this.abbreviation = abbreviation;
	}

	/** 
	 * Gets the abbreviation.
	 *
	 * @return The country's abbreviation.
	 */
	public final String getAbbreviation() {
		return this.abbreviation;
	}
}

/* ########## End of File ########## */
