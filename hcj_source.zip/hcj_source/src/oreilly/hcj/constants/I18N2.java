/*
 *     file: I18N2.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**  
 * A class to provide internationalization strings.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public final class I18N2 {
	/** Holds the string for the key OK. */
	public static final String OK;

	/** Holds the string for the key OK. */
	public static final String CANCEL;

	/** Holds the string for the key OK. */
	public static final String REFRESH;

	static {
		final String BUNDLE_NAME = "oreilly/hcj/constants/I18N";
		final ResourceBundle BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);

		// --
		OK = getString(BUNDLE, "OK");
		CANCEL = getString(BUNDLE, "CANCEL");
		REFRESH = getString(BUNDLE, "REFRESH");
	}

	/** 
	 * Blocks creation of an I18N2 object.
	 */
	private I18N2() {
	}

	/** 
	 * Get a string from the resources.
	 *
	 * @param bundle The resource bundle to fetch from.
	 * @param key The key of the string to get.
	 *
	 * @return The value for that string; if not found returns !key!.
	 */
	private static String getString(final ResourceBundle bundle, final String key) {
		try {
			return bundle.getString(key);
		} catch (final MissingResourceException ex) {
			assert (false) : ex.getMessage();
			return '!' + key + '!';
		}
	}
}

/* ########## End of File ########## */
