/*
 *     file: Country3.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

import java.util.Hashtable;

/**  
 * Holds country constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Country3 {
	/** Holds the Index of the country objects. */
	private static final Hashtable INDEX = new Hashtable();

	/** Contry constant for Canada. */
	public static final Country3 CANADA = new Country3("CANADA");

	/** Contry constant for Croatia. */
	public static final Country3 CROATIA = new Country3("CROATIA");

	/** Contry constant for Germany. */
	public static final Country3 GERMANY = new Country3("GERMANY");

	/** Contry constant for Italy. */
	public static final Country3 ITALY = new Country3("ITALY");

	/** Contry constant for Mexico. */
	public static final Country3 MEXICO = new Country3("MEXICO");

	/** Contry constant for the UK. */
	public static final Country3 UK = new Country3("UK");

	/** Contry constant for the USA. */
	public static final Country3 USA = new Country3("USA");

	/** Contry constant for the Venezuela. */
	public static final Country3 VENEZUELA = new Country3("VENEZUELA");

	/** Holds the name of this country. */
	private final String name;

	/** 
	 * Creates a new Country3.
	 *
	 * @param name The name for the exception type.
	 */
	private Country3(final String name) {
		this.name = name;
		INDEX.put(name, this);
	}

	/** 
	 * Get the name of this country.
	 *
	 * @return The name of the country.
	 */
	public String getName() {
		return this.name;
	}

	/** 
	 * Looks up a String to find the associated Country3 object.
	 *
	 * @param name The name to lookup.
	 *
	 * @return The object or null if it does not exist.
	 */
	public static Country3 lookup(final String name) {
		return (Country3)INDEX.get(name);
	}
}

/* ########## End of File ########## */
