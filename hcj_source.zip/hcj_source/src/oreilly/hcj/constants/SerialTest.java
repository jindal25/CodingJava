/*
 *     file: SerialTest.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**  
 * Demonstration of serializing constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public class SerialTest {
	/** 
	 * Main Demo Method.
	 *
	 * @param args Command line args.
	 *
	 * @throws RuntimeException If there is a problem during the execution.
	 */
	public static final void main(final String[] args) {
		try {
			writeCountry4();
			readCountry4();
			System.out.println();
			writeCountry5();
			readCountry5();
			System.out.println();
			writeCountry6();
			readCountry6();
		} catch (final FileNotFoundException ex) {
			throw new RuntimeException(ex);
		} catch (final IOException ex) {
			throw new RuntimeException(ex);
		} catch (final ClassNotFoundException ex) {
			throw new RuntimeException(ex);
		}
	}

	/** 
	 * Gets the filename to use as a composition of user home and demo.dat.
	 *
	 * @return The constructed filename.
	 */
	public static String getFilename() {
		String filename =
			System.getProperty("user.home") + System.getProperty("file.separator")
			+ "demo.dat";
		return filename;
	}

	/** 
	 * Reads a Country4 from a file.
	 *
	 * @throws FileNotFoundException If the data file is missing.
	 * @throws IOException If there is a problem with the write.
	 * @throws ClassNotFoundException If there is a problem finding country classes used.
	 */
	public static void readCountry4()
	    throws FileNotFoundException, IOException, ClassNotFoundException {
		// --
		System.out.println("Country4 in VM");
		System.out.println("Type = " + Country4.GERMANY.getClass());
		System.out.println("Name = " + Country4.GERMANY.getName());
		System.out.println("Hashcode = " + Country4.GERMANY.hashCode());
		// --   
		FileInputStream fis = new FileInputStream(getFilename());
		ObjectInputStream ois = new ObjectInputStream(fis);
		Country4 inCountry = (Country4)ois.readObject();

		// --
		System.out.println("----------------");
		System.out.println("Country4 read in");
		System.out.println("Type = " + inCountry.getClass());
		System.out.println("Name = " + inCountry.getName());
		System.out.println("Hashcode = " + inCountry.hashCode());
		// --   
		System.out.println("----------------");
		System.out.println("Identical = " + (inCountry == Country4.GERMANY));
	}

	/** 
	 * Reads a Country5 from a file.
	 *
	 * @throws FileNotFoundException If the data file is missing.
	 * @throws IOException If there is a problem with the write.
	 * @throws ClassNotFoundException If there is a problem finding country classes used.
	 */
	public static void readCountry5()
	    throws FileNotFoundException, IOException, ClassNotFoundException {
		// --
		System.out.println("Country5 in VM");
		System.out.println("Type = " + Country5.GERMANY.getClass());
		System.out.println("Name = " + Country5.GERMANY.getName());
		System.out.println("Hashcode = " + Country5.GERMANY.hashCode());
		// --   
		FileInputStream fis = new FileInputStream(getFilename());
		ObjectInputStream ois = new ObjectInputStream(fis);
		Country5 inCountry = (Country5)ois.readObject();

		// --
		System.out.println("----------------");
		System.out.println("Country5 read in");
		System.out.println("Type = " + inCountry.getClass());
		System.out.println("Name = " + inCountry.getName());
		System.out.println("Hashcode = " + inCountry.hashCode());
		// --   
		System.out.println("----------------");
		System.out.println("Identical = " + (inCountry == Country5.GERMANY));
	}

	/** 
	 * Reads a Country6 from a file.
	 *
	 * @throws FileNotFoundException If the data file is missing.
	 * @throws IOException If there is a problem with the write.
	 * @throws ClassNotFoundException If there is a problem finding country classes used.
	 */
	public static void readCountry6()
	    throws FileNotFoundException, IOException, ClassNotFoundException {
		// --
		System.out.println("Country6 in VM");
		System.out.println("Type = " + Country6.GERMANY.getClass());
		System.out.println("Name = " + Country6.GERMANY.getName());
		System.out.println("Hashcode = " + Country6.GERMANY.hashCode());
		// --   
		FileInputStream fis = new FileInputStream(getFilename());
		ObjectInputStream ois = new ObjectInputStream(fis);
		Country6 inCountry = (Country6)ois.readObject();

		// --
		System.out.println("----------------");
		System.out.println("Country6 read in");
		System.out.println("Type = " + inCountry.getClass());
		System.out.println("Name = " + inCountry.getName());
		System.out.println("Hashcode = " + inCountry.hashCode());
		// --   
		System.out.println("----------------");
		System.out.println("Identical = " + (inCountry == Country6.GERMANY));
	}

	/** 
	 * Writes an Country4 to a file.
	 *
	 * @throws IOException If there is a problem with the write.
	 */
	public static void writeCountry4() throws IOException {
		FileOutputStream fos = new FileOutputStream(getFilename());
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(Country4.GERMANY);
	}

	/** 
	 * Writes an Country5 to a file.
	 *
	 * @throws IOException If there is a problem with the write.
	 */
	public static void writeCountry5() throws IOException {
		FileOutputStream fos = new FileOutputStream(getFilename());
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(Country5.GERMANY);
	}

	/** 
	 * Writes an Country5 to a file.
	 *
	 * @throws IOException If there is a problem with the write.
	 */
	public static void writeCountry6() throws IOException {
		FileOutputStream fos = new FileOutputStream(getFilename());
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(Country6.GERMANY);
	}
}

/* ########## End of File ########## */
