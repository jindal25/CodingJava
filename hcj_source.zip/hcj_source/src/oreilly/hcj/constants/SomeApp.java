/*
 *     file: SomeApp.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * Demonstrates the use of substitution constants to internationalize.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class SomeApp {
	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param args __UNDOCUMENTED__
	 */
	public static final void main(final String[] args) {
		System.out.println(I18N.getString("OK"));  //$NON-NLS-1$
		System.out.println(I18N.getString("CANCEL"));  //$NON-NLS-1$
		System.out.println(I18N.getString("REFRESH"));  //$NON-NLS-1$
		System.out.println(I18N.getString("SOME_STRING"));  //$NON-NLS-1$
	}
}

/* ########## End of File ########## */
