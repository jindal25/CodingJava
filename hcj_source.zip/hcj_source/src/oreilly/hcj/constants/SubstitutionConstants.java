/*
 *     file: SubstitutionConstants.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

import java.util.Calendar;
import org.apache.log4j.Logger;

/**  
 * Demonstration of the aspects of substitution constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class SubstitutionConstants {
	/** Holds the logging instance. */
	private static final Logger LOGGER = Logger.getLogger(SubstitutionConstants.class);

	/** A value for PI. */
	public static final double PI = 3.141;

	/** 
	 * Calculate the area of the circle with the given radius.
	 *
	 * @param radius The radius of the circle.
	 *
	 * @return The calculated area.
	 */
	public double getCircleArea(final double radius) {
		double area = (Math.pow(radius, 2) * PI);
		LOGGER.debug("The calculated area is " + area);
		return area;
	}

	/** 
	 * Calculate interest for one time period on the principal.
	 *
	 * @param rate The interest rate.
	 * @param principal The principal.
	 *
	 * @return The calculated interest.
	 *
	 * @throws IllegalArgumentException If the interest is less than 0.0;
	 */
	public float calculateInterest(final float rate, final float principal) {
		final String LOG_MSG1 = "Rate cannot be less than ";
		final String LOG_MSG2 = ". The rate input = ";
		final double MIN_INTEREST = 0.0;

		// -- 
		if (rate < MIN_INTEREST) {
			LOGGER.error(LOG_MSG1 + MIN_INTEREST + LOG_MSG2 + rate);
			throw new IllegalArgumentException("rate");
		}
		return principal * rate;
	}

	/** 
	 * Builds a log message from an exception.
	 *
	 * @param ex The exception to use to build the message.
	 *
	 * @return The constructed message.
	 */
	protected String buildLogMessage(final Exception ex) {
		StringBuffer buf = new StringBuffer(200);
		StackTraceElement[] elements = ex.getStackTrace();
		buf.append("The exception ");
		buf.append(ex.getClass().getName());
		buf.append(" occurred at ");
		buf.append(Calendar.getInstance().getTime().toString());
		buf.append(" on line ");
		buf.append(elements[0].getLineNumber());
		return buf.toString();
	}
}

/* ########## End of File ########## */
