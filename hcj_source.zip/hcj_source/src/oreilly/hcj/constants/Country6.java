/*
 *     file: Country6.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * Holds country constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public final class Country6 extends ConstantObject {
	/** Contry constant for Canada. */
	public static final Country6 CANADA = new Country6("CANADA");

	/** Contry constant for Croatia. */
	public static final Country6 CROATIA = new Country6("CROATIA");

	/** Contry constant for Germany. */
	public static final Country6 GERMANY = new Country6("GERMANY");

	/** Contry constant for Italy. */
	public static final Country6 ITALY = new Country6("ITALY");

	/** Contry constant for Mexico. */
	public static final Country6 MEXICO = new Country6("MEXICO");

	/** Contry constant for the UK. */
	public static final Country6 UK = new Country6("UK");

	/** Contry constant for the USA. */
	public static final Country6 USA = new Country6("USA");

	/** Contry constant for the Venezuela. */
	public static final Country6 VENEZUELA = new Country6("VENEZUELA");

	/** 
	 * Creates a new Country6.
	 *
	 * @param name The name for the country type.
	 */
	private Country6(final String name) {
		super(name);
	}
}

/* ########## End of File ########## */
