/*
 *     file: Country5.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**  
 * Holds country constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Country5 implements Serializable {
	/** Holds the Index of the country objects. */
	private static final Map INDEX = new HashMap();

	/** Contry constant for Canada. */
	public static final Country5 CANADA = new Country5("CANADA");

	/** Contry constant for Croatia. */
	public static final Country5 CROATIA = new Country5("CROATIA");

	/** Contry constant for Germany. */
	public static final Country5 GERMANY = new Country5("GERMANY");

	/** Contry constant for Italy. */
	public static final Country5 ITALY = new Country5("ITALY");

	/** Contry constant for Mexico. */
	public static final Country5 MEXICO = new Country5("MEXICO");

	/** Contry constant for the UK. */
	public static final Country5 UK = new Country5("UK");

	/** Contry constant for the USA. */
	public static final Country5 USA = new Country5("USA");

	/** Contry constant for the Venezuela. */
	public static final Country5 VENEZUELA = new Country5("VENEZUELA");

	/** Holds the name of this country. */
	private final String name;

	/** 
	 * Creates a new Country5.
	 *
	 * @param name The name for the exception type.
	 */
	private Country5(final String name) {
		this.name = name;
		INDEX.put(name, this);
	}

	/** 
	 * Get the name of this country.
	 *
	 * @return The name of the country.
	 */
	public String getName() {
		return this.name;
	}

	/** 
	 * Looks up a String to find the associated Country3 object.
	 *
	 * @param name The name to lookup.
	 *
	 * @return The object or null if it does not exist.
	 */
	public static Country5 lookup(final String name) {
		return (Country5)INDEX.get(name);
	}

	/** 
	 * Resolve a read in object.
	 *
	 * @return The resolved object read in.
	 *
	 * @throws ObjectStreamException if there is a problem reading the object.
	 * @throws RuntimeException If the read object doesnt exist.
	 */
	protected Object readResolve() throws ObjectStreamException {
		Object result = Country5.lookup(this.getName());
		if (result == null) {
			throw new RuntimeException("Constant not found for name: " + this.getName());
		}
		return result;
	}
}

/* ########## End of File ########## */
