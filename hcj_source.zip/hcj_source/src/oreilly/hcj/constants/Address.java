/*
 *     file: Address.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * Encapsulates an address to demo the use of country constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Address {
	/** Holds the value of the property country. */
	private int country;

	/** 
	 * Setter for the value of the property country.
	 *
	 * @param country The new value of the property country.
	 */
	public void setCountry(final int country) {
		this.country = country;
	}

	/** 
	 * Getter for the value of the property country.
	 *
	 * @return The current value of the property country.
	 */
	public int getCountry() {
		return this.country;
	}

	/** 
	 * Setter for the value of the property country.
	 *
	 * @param country The new value of the property country.
	 *
	 * @throws IllegalArgumentException If the country is an illegal value.
	 */
	public void setCountry2(final int country) {
		if ((country < Country.MIN_VALUE) || (country > Country.MAX_VALUE)) {
			throw new IllegalArgumentException();
		}
		this.country = country;
	}
}

/* ########## End of File ########## */
