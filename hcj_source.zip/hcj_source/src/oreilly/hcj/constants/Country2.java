/*
 *     file: Country2.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * Holds country constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Country2 {
	/** Contry constant for Canada. */
	public static final Country2 CANADA = new Country2("CANADA");

	/** Contry constant for Croatia. */
	public static final Country2 CROATIA = new Country2("CROATIA");

	/** Contry constant for Germany. */
	public static final Country2 GERMANY = new Country2("GERMANY");

	/** Contry constant for Italy. */
	public static final Country2 ITALY = new Country2("ITALY");

	/** Contry constant for Mexico. */
	public static final Country2 MEXICO = new Country2("MEXICO");

	/** Contry constant for the UK. */
	public static final Country2 UK = new Country2("UK");

	/** Contry constant for the USA. */
	public static final Country2 USA = new Country2("USA");

	/** Contry constant for the Venezuela. */
	public static final Country2 VENEZUELA = new Country2("VENEZUELA");

	/** Holds the name of this country. */
	private final String name;

	/** 
	 * Creates a new Country2.
	 *
	 * @param name The name for the exception type.
	 */
	private Country2(final String name) {
		this.name = name;
	}

	/** 
	 * Get the name of this country.
	 *
	 * @return The name of the country.
	 */
	public String getName() {
		return this.name;
	}
}

/* ########## End of File ########## */
