/*
 *     file: BitFieldDemo.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * Demonstration of aspects of bit fields.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public class BitFieldDemo {
	/** Holds the demo car. */
	private Car myCar = null;

	/** 
	 * Creates a new BitFieldDemo object.
	 */
	public BitFieldDemo() {
	}

	/** 
	 * Set the default options.
	 */
	public void setBitFields() {
		this.myCar = new Car();
		myCar.setOptions(Car.CRUISE_CONTROL | Car.STANDARD_TIRES | Car.POWER_LOCKS);
		System.out.println(myCar.getOptions());
	}

	/** 
	 * Remove the standard tires option.
	 */
	public void clearStandardTires() {
		myCar.setOptions(myCar.getOptions() ^ Car.STANDARD_TIRES);
		System.out.println(myCar.getOptions());
	}

	/** 
	 * Main Demo Method.
	 *
	 * @param args Command line arguments.
	 */
	public static final void main(String[] args) {
		BitFieldDemo demo = new BitFieldDemo();
		demo.setBitFields();
		demo.clearStandardTires();
		demo.printCarOptions();
	}

	/** 
	 * Write the car's options to the console.
	 */
	public void printCarOptions() {
		System.out.println("-- Options --");
		if ((myCar.getOptions() & Car.POWER_WINDOWS) > 0) {
			System.out.println("Power Windows");
		}
		if ((myCar.getOptions() & Car.POWER_LOCKS) > 0) {
			System.out.println("Power Locks");
		}
	}
}

/* ########## End of File ########## */
