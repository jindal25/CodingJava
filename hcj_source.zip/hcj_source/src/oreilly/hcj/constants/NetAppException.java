/*
 *     file: NetAppException.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * A demonstration of application exception type consants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class NetAppException extends Exception {
	/** An undefined network exception. */
	public static final int NETWORK_UNDEFINED = 100;

	/** A network exception caused by the server droping us. */
	public static final int NETWORK_SEVER_RESET = 101;

	/** A network exception caused by undefined host name. */
	public static final int NETWORK_INVALID_HOST_NAME = 102;

	/** A bad parameter exception. */
	public static final int LOGIC_BAD_PARAMETER = 200;

	/** An exception caused by failed authorization. */
	public static final int LOGIC_AUTHORIZATION_FAILED = 201;
}

/* ########## End of File ########## */
