/*
 *     file: NetAppException2.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * A demonstration of application exception type consants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public final class NetAppException2 extends Exception {
	/** An undefined network exception. */
	public static final NetAppException2 NETWORK_UNDEFINED =
		new NetAppException2("NETWORK_UNDEFINED");

	/** A network exception caused by the server droping us. */
	public static final NetAppException2 NETWORK_SEVER_RESET =
		new NetAppException2("NETWORK_SEVER_RESET");

	/** A network exception caused by undefined host name. */
	public static final NetAppException2 NETWORK_INVALID_HOST_NAME =
		new NetAppException2("NETWORK_INVALID_HOST_NAME");

	/** A bad parameter exception. */
	public static final NetAppException2 LOGIC_BAD_PARAMETER =
		new NetAppException2("LOGIC_BAD_PARAMETER");

	/** An exception caused by failed authorization. */
	public static final NetAppException2 LOGIC_AUTHORIZATION_FAILED =
		new NetAppException2("LOGIC_AUTHORIZATION_FAILED");

	/** Holds the name of this constant. */
	private final String name;

	/** 
	 * Creates a new ExceptionType2 object.
	 *
	 * @param name The name for the exception type.
	 */
	private NetAppException2(final String name) {
		this.name = name;
	}

	/** 
	 * Get the name of this exception type.
	 *
	 * @return The name of the exception.
	 */
	public String getName() {
		return this.name;
	}
}

/* ########## End of File ########## */
