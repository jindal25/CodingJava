/*
 *     file: I18N.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**  
 * A class to provide internationalization strings.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public final class I18N {
	/** Holds the name of the resource bundle. */
	private static final String BUNDLE_NAME = "oreilly/hcj/constants/I18N";

	/** Holds the resource bundle. */
	private static final ResourceBundle BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);

	/** 
	 * Block construction.
	 */
	private I18N() {
	}

	/** 
	 * Get a string from the resources.
	 *
	 * @param key The key of the string to get.
	 *
	 * @return The value for that string; if not found returns !key!.
	 */
	public static String getString(String key) {
		try {
			return BUNDLE.getString(key);
		} catch (final MissingResourceException ex) {
			return '!' + key + '!';
		}
	}
}

/* ########## End of File ########## */
