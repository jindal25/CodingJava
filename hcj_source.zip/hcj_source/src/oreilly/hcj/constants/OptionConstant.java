/*
 *     file: OptionConstant.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * JOptionPane's constants rendered to a constant object.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public class OptionConstant extends ConstantObject {
	/** An error message type. */
	public static final OptionConstant ERROR_MESSAGE =
		new OptionConstant("ERROR_MESSAGE");

	/** An information message type. */
	public static final OptionConstant INFORMATION_MESSAGE =
		new OptionConstant("INFORMATION_MESSAGE");

	/** An warining message type. */
	public static final OptionConstant WARNING_MESSAGE =
		new OptionConstant("WARNING_MESSAGE");

	/** An question message type. */
	public static final OptionConstant QUESTION_MESSAGE =
		new OptionConstant("QUESTION_MESSAGE");

	/** An plain message type. */
	public static final OptionConstant PLAIN_MESSAGE =
		new OptionConstant("PLAIN_MESSAGE");

	/** Use default buttons. */
	public static final OptionConstant DEFAULT_OPTION =
		new OptionConstant("DEFAULT_OPTION");

	/** Use yes/no buttons. */
	public static final OptionConstant YES_NO_OPTION =
		new OptionConstant("YES_NO_OPTION");

	/** Use yes/no/cancel buttons. */
	public static final OptionConstant YES_NO_CANCEL_OPTION =
		new OptionConstant("YES_NO_CANCEL_OPTION");

	/** Use ok/cancel buttons. */
	public static final OptionConstant OK_CANCEL_OPTION =
		new OptionConstant("OK_CANCEL_OPTION");

	/** 
	 * @see oreilly.hcj.constants.ConstantObject
	 */
	public OptionConstant(String name) {
		super(name);
	}
}

/* ########## End of File ########## */
