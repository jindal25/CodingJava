/*
 *     file: Country.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * Holds country constants.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Country {
	/** Contry constant for Canada. */
	public static final int CANADA = 0;

	/** Contry constant for Croatia. */
	public static final int CROATIA = 1;

	/** Contry constant for Germany. */
	public static final int GERMANY = 2;

	/** Contry constant for Italy. */
	public static final int ITALY = 3;

	/** Contry constant for Mexico. */
	public static final int MEXICO = 4;

	/** Contry constant for the UK. */
	public static final int UK = 5;

	/** Contry constant for the USA. */
	public static final int USA = 6;

	/** Contry constant for the Venezuela. */
	public static final int VENEZUELA = 7;

	/** Minimum Country value. */
	public static final int MIN_VALUE = 0;

	/** Maximum Country value. */
	public static final int MAX_VALUE = 6;
}

/* ########## End of File ########## */
