/*
 *     file: Car.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

/**  
 * Demonstrates aspects of bit fields.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Car {
	/** A constant to represent the option of power windows. */
	public static final int POWER_WINDOWS = 1;

	/** A constant to represent the option of power door locks. */
	public static final int POWER_LOCKS = 2;

	/** A constant to represent the option of snow tires. */
	public static final int SNOW_TIRES = 4;

	/** A constant to represent the option of standard tires. */
	public static final int STANDARD_TIRES = 8;

	/** A constant to represent the option of cruise control. */
	public static final int CRUISE_CONTROL = 16;

	/** A constant to represent the option of a CD player. */
	public static final int CD_PLAYER = 32;

	/** A constant to represent the option of air conditioning. */
	public static final int AIR_CONDITIONING = 64;

	/** Holds the options. */
	private int options;

	/** 
	 * Creates a new Car object.
	 */
	public Car() {
	}

	/** 
	 * Setter for the property options.
	 *
	 * @param options The new options.
	 */
	public void setOptions(final int options) {
		this.options = options;
	}

	/** 
	 * Setter for the property options.
	 *
	 * @return options The new options.
	 */
	public int getOptions() {
		return this.options;
	}
}

/* ########## End of File ########## */
