/*
 *     file: ConstantObject.java
 *  package: oreilly.hcj.constants
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.constants;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**  
 * Defines a class of objects that are constant and thus immutable.
 * 
 * <P>
 * Objects descending from this class cannot change unless there is a code change. That
 * makes them uneditable by the user and thus constant. Naturally the descendant classes
 * shouldn't have public constructors.
 * </p>
 *
 * @author <a href="mailto:worderisor@yahoo.com">Robert Simmons jr.</a>
 * @version $Revision: 1.13 $
 *
 * @see DataModelObjectTest
 */
public abstract class ConstantObject implements Serializable {
	/**
	 * Holds the grand constants index map.  Contains references to all constants indexes
	 * that are instantiated indexed by constant name.
	 */
	private static final Map CONSTANTS_MASTER_INDEX = new HashMap();

	/** Use serialVersionUID for interoperability. */
	private static final long serialVersionUID = -696105837069868663L;

	/**
	 * Error message when user passes a name that is already defined for <tt>this</tt>
	 * class.
	 */
	private static final String ERR_DUP_NAME =
		"ERROR: Constants of the same type have duplicate names.";  //$NON-NLS-1$

	/** Holds value of property name. */
	private final String name;

	/** 
	 * Creates a new instance of ConstantObject.
	 *
	 * @param name The name for the constant object.
	 *
	 * @throws NullPointerException If null is given for the constant name.
	 * @throws IllegalArgumentException If the user passes a null name.
	 */
	protected ConstantObject(final String name) {
		if (name == null) {
			throw new NullPointerException("The name may not be null.");  //$NON-NLS-1$
		}
		Map constMap = (Map)CONSTANTS_MASTER_INDEX.get(getClass());
		if (constMap == null) {
			constMap = new HashMap();
			CONSTANTS_MASTER_INDEX.put(getClass(), constMap);
		}
		if (constMap.containsKey(name)) {
			throw new IllegalArgumentException(ERR_DUP_NAME);
		}
		this.name = name;
		constMap.put(name, this);
	}

	/** 
	 * Get the constant for the given class and id.
	 *
	 * @param dataType The class for which to retrieve the index.
	 * @param name The name of the constant.
	 *
	 * @return The constant object for the given class and name.
	 */
	public static final ConstantObject lookup(final Class dataType, final String name) {
		return (ConstantObject)((Map)CONSTANTS_MASTER_INDEX.get(dataType)).get(name);
	}

	/** 
	 * Get the constants index for the given class.
	 *
	 * @param dataType The class for which to retrieve the index.
	 *
	 * @return An unmodifiable map of constants for the given class.
	 */
	public static final Map lookup(final Class dataType) {
		return Collections.unmodifiableMap((Map)CONSTANTS_MASTER_INDEX.get(dataType));
	}

	/** 
	 * Getter for property name.
	 *
	 * @return Value of property name.
	 */
	public final String getName() {
		return this.name;
	}

	/** 
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return this.getClass()
		           .getName() + "." + this.name;
	}

	/** 
	 * Resolve a read in object.
	 *
	 * @return The resolved object read in.
	 *
	 * @throws ObjectStreamException if there is a problem reading the object.
	 * @throws RuntimeException If the read object doesnt exist.
	 */
	protected Object readResolve() throws ObjectStreamException {
		Object result = lookup(getClass(), getName());
		if (result == null) {
			throw new RuntimeException("Constant not found for name: " + getName());  //$NON-NLS-1$
		}
		return result;
	}
}

/* ########## End of File ########## */
