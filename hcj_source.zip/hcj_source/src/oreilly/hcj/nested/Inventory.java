/*
 *     file: Inventory.java
 *  package: oreilly.hcj.nested
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.nested;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**  
 * Demonstrates nested interfaces.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Inventory {
	/** All the items in the inventory. */
	public HashSet items;

	/** 
	 * Get a copy of all of the values.
	 *
	 * @return An unmodifiable set that is a copy of all items in the inventory.
	 */
	public Set getValues() {
		return Collections.unmodifiableSet(items);
	}

	/** 
	 * Add an item.
	 *
	 * @param item The item to add.
	 */
	public void addItem(final InventoryItem item) {
		items.add(item);
	}

	/** 
	 * Get an iterator for all items.
	 *
	 * @return The iterator for the inventory.
	 */
	public Iterator iterator() {
		return items.iterator();
	}

	/** 
	 * Remove an item.
	 *
	 * @param item The item to remove.
	 */
	public void removeElement(final InventoryItem item) {
		items.remove(item);
	}

	/** 
	 * Interface for all members of the collection.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.3 $
	 */
	public static interface InventoryItem {
		/** 
		 * Return the SKU code of the item.
		 *
		 * @return The String SKU code.
		 */
		public String getSKU();
	}
}

/* ########## End of File ########## */
