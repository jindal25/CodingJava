/*
 *     file: AnonymousDemo.java
 *  package: oreilly.hcj.nested
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.nested;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.NumberFormat;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import org.apache.log4j.Logger;

/**  
 * Demonstrates anonymous classes.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.6 $
 */
public class AnonymousDemo extends JDialog {
	/** The logging object */
	private static final Logger LOGGER = Logger.getLogger(AnonymousDemo.class);

	/** Holds the logo image */
	private static final ImageIcon LOGO;

	/** Holds the location of the logo image. */
	private static final String LOGO_LOCATION = "oreilly/hcj/nested/oreilly_header3.gif";

	static {
		LOGO =
			new ImageIcon(ClassLoader.getSystemClassLoader().getResource(LOGO_LOCATION));
	}

	/** Holds a reference to the content pane. */
	private final Container contentPane;

	/** holds a demo variable. */
	private String demo = "Calculating Display String.";

	/** 
	 * Creates a new AnonymousDemo object.
	 */
	public AnonymousDemo() {
		super();
		setTitle("Anonymous Demo");
		setModal(true);
		contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		JLabel logoLabel = new JLabel(LOGO);
		contentPane.add(BorderLayout.NORTH, logoLabel);

		JButton btn = new JButton("Beep");
		btn.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent event) {
					Toolkit.getDefaultToolkit()
					       .beep();
				}
			});
		contentPane.add(BorderLayout.SOUTH, btn);
		pack();
	}

	/** 
	 * Creates a new AnonymousDemo object.
	 *
	 * @param exitDelay The delay before exiting.
	 *
	 * @throws RuntimeException If there is a runtime problem.
	 */
	public AnonymousDemo(final int exitDelay) {
		super();
		setTitle("Anonymous Demo");
		setModal(true);
		contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		final String delayDisplay =
			new Object() {
					public String toString() {
						System.out.println(demo);
						if ((exitDelay) > 1000) {
							// Show in seconds. 
							NumberFormat formatter = NumberFormat.getNumberInstance();
							formatter.setMinimumFractionDigits(2);
							double time = exitDelay / 1000.0;
							return (new String(formatter.format(time) + " seconds"));
						} else {
							// Show in Microseconds
							return new String(exitDelay + " microseconds");
						}
					}
				}.toString();

		addWindowListener(new WindowAdapter() {
				public void windowClosing(final WindowEvent event) {
					try {
						System.out.println("Waiting for " + delayDisplay);
						Thread.sleep(exitDelay);
					} catch (final InterruptedException ex) {
						throw new RuntimeException(ex);
					}
				}
			});

		JLabel logoLabel = new JLabel(LOGO);
		contentPane.add(BorderLayout.NORTH, logoLabel);

		JButton btn =
			new JButton("Beep") {
				public void fireActionPerformed(final ActionEvent event) {
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug(event);
						LOGGER.debug("This class is: " + this.getClass().getName());
					}
					super.fireActionPerformed(event);
				}
			};

		btn.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent event) {
					doBeep();
				}
			});
		contentPane.add(BorderLayout.SOUTH, btn);

		pack();
	}

	/** 
	 * Setter for the property demo.
	 *
	 * @param demo The new value for demo.
	 */
	public void setDemo(final String demo) {
		this.demo = demo;
	}

	/** 
	 * Getter for the property demo.
	 *
	 * @return The current value of demo.
	 */
	public String getDemo() {
		return demo;
	}

	/** 
	 * Run the demo
	 *
	 * @param args Command Line Arguments.
	 */
	public static final void main(final String[] args) {
		AnonymousDemo demo = new AnonymousDemo(1450);
		demo.show();
		System.out.println("Done");
		System.exit(0);
	}

	/** 
	 * DOCUMENT ME!
	 */
	private void doBeep() {
		Toolkit.getDefaultToolkit()
		       .beep();
	}
}

/* ########## End of File ########## */
