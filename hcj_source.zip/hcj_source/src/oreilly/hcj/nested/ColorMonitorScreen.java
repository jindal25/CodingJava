/*
 *     file: ColorMonitorScreen.java
 *  package: oreilly.hcj.nested
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.nested;

import java.awt.Color;
import java.awt.Dimension;

/**  
 * A color monitor screen.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class ColorMonitorScreen extends BasicMonitorScreen {
	/** 
	 * Creates a new ColorMonitorScreen object.
	 *
	 * @param resolution The monitor's resolution.
	 */
	public ColorMonitorScreen(final Dimension resolution) {
		super(resolution);
	}

	/**  
	 * Holds a pixel point on our screen.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.3 $
	 */
	protected class ColorPixelPoint extends PixelPoint {
		/** Holds the value of the property value. */
		private Color color;

		/** 
		 * Creates a new SomeClass object.
		 *
		 * @param x The x coordinate.
		 * @param y The y coordinate.
		 * @param color The color at this pixel.
		 */
		public ColorPixelPoint(final int x, final int y, final Color color) {
			super(x, y);
			this.color = color;
		}

		/** 
		 * Gets the value of the property color.
		 *
		 * @return The current value of color.
		 */
		public Color getColor() {
			return this.color;
		}

		/** 
		 * Demo method.
		 */
		public void someMethod() {
			// System.out.println(resoultion); // <= compiler error
		}
	}
}

/* ########## End of File ########## */
