/*
 *     file: BasicMonitorScreen.java
 *  package: oreilly.hcj.nested
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.nested;

import java.awt.Dimension;

/**  
 * A color monitor screen.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public abstract class BasicMonitorScreen {
	/** Holds the value of the property resolution. */
	private Dimension resolution;

	/** 
	 * Creates a new BasicMonitorScreen object.
	 *
	 * @param resolution The monitor's resolution.
	 */
	public BasicMonitorScreen(final Dimension resolution) {
		this.resolution = resolution;
	}

	/** 
	 * Gets the value of the property resolution.
	 *
	 * @return The current value of resolution.
	 */
	public Dimension getResolution() {
		return this.resolution;
	}

	/**  
	 * Holds a pixel point on our screen.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.3 $
	 */
	protected abstract class PixelPoint {
		/** Holds the value of the property x. */
		private int x;

		/** Holds the value of the property y. */
		private int y;

		/** 
		 * Creates a new SomeClass object.
		 *
		 * @param x The x coordinate.
		 * @param y The y coordinate.
		 */
		public PixelPoint(final int x, final int y) {
			this.x = x;
			this.y = y;
		}

		/** 
		 * Gets the value of the property x.
		 *
		 * @return The current value of x.
		 */
		public int getX() {
			return x;
		}

		/** 
		 * Gets the value of the property y.
		 *
		 * @return The current value of y.
		 */
		public int getY() {
			return y;
		}
	}
}

/* ########## End of File ########## */
