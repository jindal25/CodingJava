/*
 *     file: MethodInnerClassDemo.java
 *  package: oreilly.hcj.nested
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.nested;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**  
 * Demonstrates method-scoped inner classes.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.6 $
 */
public class MethodInnerClassDemo extends JDialog {
	/** Holds the logo image */
	private static final ImageIcon LOGO;

	/** Holds the location of the logo image. */
	private static final String LOGO_LOCATION = "oreilly/hcj/nested/oreilly_header3.gif";

	static {
		LOGO =
			new ImageIcon(ClassLoader.getSystemClassLoader().getResource(LOGO_LOCATION));
	}

	/** Holds a reference to the content pane. */
	private final Container contentPane;

	/** holds a demo variable. */
	private String demo;

	/** 
	 * Creates a new MethodInnerClassDemo object.
	 *
	 * @param value Some value to be used.
	 */
	public MethodInnerClassDemo(final int value) {
		super();
		String title = "Inner Class Demo";
		setTitle(title);
		setModal(true);
		contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		JLabel logoLabel = new JLabel(LOGO);
		contentPane.add(BorderLayout.NORTH, logoLabel);

		JButton btn = new JButton("Beep");

		/**  
		 * An action listener class.
		 *
		 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
		 * @version $Revision: 1.6 $
		 */
		class MyActionListener implements ActionListener {
			/** 
			 * {@inheritDoc}
			 */
			public void actionPerformed(final ActionEvent event) {
				Toolkit.getDefaultToolkit()
				       .beep();
				System.out.println(value);
				System.out.println(MethodInnerClassDemo.LOGO_LOCATION);
				System.out.println(MethodInnerClassDemo.this.demo);
				// System.out.println(title); // <= compiler error
			}
		}
		btn.addActionListener(new MyActionListener());

		contentPane.add(BorderLayout.SOUTH, btn);
		pack();
	}

	/** 
	 * Creates a new MethodInnerClassDemo object.
	 */
	public MethodInnerClassDemo() {
		super();
		setTitle("Inner Class Demo");
		setModal(true);
		contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		JLabel logoLabel = new JLabel(LOGO);
		contentPane.add(BorderLayout.NORTH, logoLabel);

		JButton btn1 = new JButton("Beep");
		JButton btn2 = new JButton("Bell");

		/**  
		 * An action listener class.
		 *
		 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
		 * @version $Revision: 1.6 $
		 */
		class MyActionListener implements ActionListener {
			/** 
			 * {@inheritDoc}
			 */
			public void actionPerformed(final ActionEvent event) {
				Toolkit.getDefaultToolkit()
				       .beep();
			}
		}
		btn1.addActionListener(new MyActionListener());
		btn2.addActionListener(new MyActionListener());

		JPanel pnl = new JPanel(new GridLayout(1, 2));
		pnl.add(btn1);
		pnl.add(btn2);

		contentPane.add(BorderLayout.SOUTH, pnl);
		pack();
	}

	/** 
	 * Run the demo
	 *
	 * @param args Command Line Arguments.
	 */
	public static final void main(final String[] args) {
		MethodInnerClassDemo demo = new MethodInnerClassDemo();
		demo.show();
		System.out.println("Done");
	}

	/** 
	 * Setter for the property demo.
	 *
	 * @param demo The new value for demo.
	 */
	public void setDemo(final String demo) {
		this.demo = demo;
	}

	/** 
	 * Getter for the property demo.
	 *
	 * @return The current value of demo.
	 */
	public String getDemo() {
		return demo;
	}

	/** 
	 * Some demo method.
	 */
	public void someMethod() {
		// ActionListener listener = new MyActionListener(); // <= compiler error.
	}
}

/* ########## End of File ########## */
