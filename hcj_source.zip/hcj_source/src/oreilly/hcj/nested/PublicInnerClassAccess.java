/*
 *     file: PublicInnerClassAccess.java
 *  package: oreilly.hcj.nested
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.nested;

/**  
 * Demonstrates External Access to Inner Classes.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class PublicInnerClassAccess {
	/** 
	 * Main method.
	 *
	 * @param args The arguments.
	 */
	public static final void main(final String[] args) {
		// MonitorScreen.PixelPoint obj = new MonitorScreen.PixelPoint(); // <= Compiler error.
		MonitorScreen screen = new MonitorScreen();
		MonitorScreen.PixelPoint pixel = screen.new PixelPoint(25, 40);
		System.out.println(pixel.getX());
		System.out.println(pixel.getY());
	}
}

/* ########## End of File ########## */
