/*
 *     file: SuperfluousExceptions.java
 *  package: oreilly.hcj.exceptions
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.exceptions;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import oreilly.hcj.bankdata.Gender;

/**  
 * Demonstration of having to catch superfluous exceptions.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public class SuperfluousExceptions {
	/** 
	 * Method to prepare a JDBC Driver.
	 *
	 * @throws ClassNotFoundException If the JDBS driver name given isn't found.
	 */
	public void prepareJDBCDriver() throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
	}

	/** 
	 * A Sample Reflection method.
	 *
	 * @throws NoSuchMethodException If a method cant be located.
	 * @throws IllegalAccessException If the security manager rejects access.
	 * @throws InvocationTargetException If the invoked method throws an exception.
	 * @throws ClassNotFoundException If a class cant be found.
	 * @throws MyCustomException If there is a business logic error.
	 */
	public void reflectionMethod()
	    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, 
	               ClassNotFoundException, MyCustomException {
		Class.forName("oreilly.hcj.bankdata.Gender");
		// .. some code
		Method meth = Gender.class.getDeclaredMethod("getName", null);
		meth.invoke(Gender.MALE, null);
		// .. other code working with result that might 
		// throw a program exception
	}

	/** 
	 * A Sample Reflection method.
	 *
	 * @throws MyCustomException If there is a business logic error.
	 * @throws RuntimeException If there is an reflection-based exception.
	 */
	public void reflectionMethod2() throws MyCustomException {
		try {
			Class.forName("oreilly.hcj.bankdata.Gender");
			// .. some code
			Method meth = Gender.class.getDeclaredMethod("getName", null);
			meth.invoke(Gender.MALE, null);
			// .. other code working with result that might 
			// throw a program exception
		} catch (final NoSuchMethodException ex) {
			throw new RuntimeException(ex);
		} catch (final IllegalAccessException ex) {
			throw new RuntimeException(ex);
		} catch (final InvocationTargetException ex) {
			throw new RuntimeException(ex);
		} catch (final ClassNotFoundException ex) {
			throw new RuntimeException(ex);
		}
	}

	/** 
	 * A Sample Reflection method.
	 *
	 * @throws MyCustomException If there is a business logic error.
	 * @throws RuntimeException If there is an reflection-based exception.
	 */
	public void reflectionMethod3() throws MyCustomException {
		try {
			Class.forName("oreilly.hcj.bankdata.Gender");
			// .. some code
			Method meth = Gender.class.getDeclaredMethod("getName", null);
			meth.invoke(Gender.MALE, null);
			// .. other code working with result that might 
			// throw a program exception
		} catch (final Exception ex) {
			if (ex instanceof MyCustomException) {
				throw (MyCustomException)ex;
			}
			throw new RuntimeException(ex);
		}
	}

	/** 
	 * A Sample Reflection method.
	 *
	 * @throws MyCustomException If there is a business logic error.
	 */
	public void reflectionMethod4() throws MyCustomException {
		try {
			Class.forName("oreilly.hcj.bankdata.Gender");
			// .. some code
			Method meth = Gender.class.getDeclaredMethod("getName", null);
			meth.invoke(Gender.MALE, null);
			// .. other code working with result that might 
			// throw a program exception
		} catch (final Exception ex) {
			if (ex instanceof MyCustomException) {
				throw (MyCustomException)ex;
			}
		}
	}

	/** 
	 * A Sample Reflection method.
	 *
	 * @param packageList The list of packages to find a class in.
	 *
	 * @throws MyCustomException If there is a business logic error.
	 * @throws RuntimeException If there is an reflection-based exception.
	 */
	public void reflectionMethod5(final String[] packageList)
	    throws MyCustomException {
		try {
			Class.forName("oreilly.hcj.bankdata.Gender");
			// .. some code
			Method meth = Gender.class.getDeclaredMethod("getName", null);
			meth.invoke(Gender.MALE, null);

			// .. other code working with result that might 
			// throw a program exception
			// try to load a class by searching through some packages.
			for (int idx = 0; idx < packageList.length; idx++) {
				try {
					Class.forName(packageList[idx] + "MyClass");
				} catch (final ClassNotFoundException ex) {
					// not an error. 
				}
			}
		} catch (final NoSuchMethodException ex) {
			throw new RuntimeException(ex);
		} catch (final IllegalAccessException ex) {
			throw new RuntimeException(ex);
		} catch (final InvocationTargetException ex) {
			throw new RuntimeException(ex);
		} catch (final ClassNotFoundException ex) {
			throw new RuntimeException(ex);
		}
	}

	/** 
	 * Demonstrates hazards fo using Exception in a throws clause.
	 *
	 * @throws Exception If there is a problem.
	 * @throws MyCustomException If there is a business logic problem.
	 */
	public void someMethod() throws Exception {
		try {
			// .. some code that starts a purchase transaction..
			reflectionMethod();
		} catch (final Exception ex) {
			if (ex instanceof MyCustomException) {
				if (((MyCustomException)ex).getType() == MyCustomException.CREDIT_CARD_DECLINED) {
					// check if customer has other cards, 
					// if not throw a billing error. 
					throw new MyCustomException(MyCustomException.BILLING_ERROR);
				}
			} else {
				throw ex;
			}
		}
	}
}

/* ########## End of File ########## */
