/*
 *     file: MyCustomException.java
 *  package: oreilly.hcj.exceptions
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.exceptions;

/**  
 * A custom exception class used for demonstration purposes.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public class MyCustomException extends Exception {
	/** Constant for a transaction error. */
	public static final int GUI_ERROR = 0;

	/** Constant for a transaction error. */
	public static final int NO_RESERVATION = 1;

	/** Constant for a transaction error. */
	public static final int TRANSACTION_ERROR = 2;

	/** Constant for a billing error. */
	public static final int BILLING_ERROR = 3;

	/** Constant for credit card declined. */
	public static final int CREDIT_CARD_DECLINED = 4;

	/** The type of exception. */
	final int type;

	/** 
	 * Creates a new MyCustomException object.
	 *
	 * @param type The type of error.
	 *
	 * @throws IllegalArgumentException If the type given is invalid.
	 */
	public MyCustomException(final int type) {
		if ((type != GUI_ERROR) && (type != NO_RESERVATION)
		    && (type != TRANSACTION_ERROR) && (type != BILLING_ERROR)
		    && (type != CREDIT_CARD_DECLINED)) {
			throw new IllegalArgumentException();
		}
		this.type = type;
	}

	/** 
	 * Get the exception type.
	 *
	 * @return type The exception type.
	 */
	public int getType() {
		return this.type;
	}
}

/* ########## End of File ########## */
