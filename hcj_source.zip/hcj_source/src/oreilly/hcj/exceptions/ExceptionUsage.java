/*
 *     file: ExceptionUsage.java
 *  package: oreilly.hcj.exceptions
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.exceptions;

/**  
 * Demonstrates exception usage, both proper and improper.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class ExceptionUsage {
	/** Storage for a customer name (Required). */
	private String customerName;

	/** 
	 * Setter for the customerName property.
	 *
	 * @param customerName The current value for the customerName property.
	 *
	 * @throws NullPointerException If the given string is null.
	 * @throws IllegalArgumentException if the given string is of size 0.
	 */
	public void setCustomerName(final String customerName) {
		if (customerName == null) {
			throw new NullPointerException();
		}
		if (customerName.length() == 0) {
			throw new IllegalArgumentException();
		}
		this.customerName = customerName;
	}

	/** 
	 * Getter for the customerName property.
	 *
	 * @return The current value of the customerName property.
	 */
	public String getCustomerName() {
		return this.customerName;
	}
}

/* ########## End of File ########## */
