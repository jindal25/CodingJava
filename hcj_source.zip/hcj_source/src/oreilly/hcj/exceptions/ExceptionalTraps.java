/*
 *     file: ExceptionalTraps.java
 *  package: oreilly.hcj.exceptions
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.exceptions;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import oreilly.hcj.bankdata.Customer;
import oreilly.hcj.references.PropertyChangeSupport;
import org.apache.log4j.Logger;

/**  
 * A demonstration of traps associated with exceptions.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.5 $
 */
public class ExceptionalTraps implements TableModel {
	/** logging object. */
	private static final Logger LOGGER = Logger.getLogger(ExceptionalTraps.class);

	/** Cache of the data fetched. */
	private ArrayList data;

	/** an instance variable used for demo purposes. */
	private ArrayList processedOrders;

	/** Provides support for property change events. */
	private final PropertyChangeSupport propertyChangeSupport =
		new PropertyChangeSupport(this);

	/** Holds a demo property. */
	private String someProperty;

	/** Holds the sql used to fetch the data. */
	private String sql;

	/** 
	 * @see javax.swing.table.TableModel
	 */
	public boolean isCellEditable(final int row, final int column) {
		return false;
	}

	/** 
	 * @see javax.swing.table.TableModel
	 */
	public Class getColumnClass(final int column) {
		return null;
	}

	/** 
	 * @see javax.swing.table.TableModel
	 */
	public int getColumnCount() {
		return 0;
	}

	/** 
	 * @see javax.swing.table.TableModel
	 */
	public String getColumnName(final int column) {
		return null;
	}

	/** 
	 * @see javax.swing.table.TableModel
	 */
	public int getRowCount() {
		return 0;
	}

	/** 
	 * Setter for the property someProperty.
	 *
	 * @param someProperty The new value for someProperty.
	 */
	public void setSomeProperty(final String someProperty) {
		final String oldSomeProperty = this.someProperty;
		this.someProperty = someProperty;
		propertyChangeSupport.firePropertyChange("someProperty", oldSomeProperty,
		                                         someProperty);
	}

	/** 
	 * Getter for the property someProperty.
	 *
	 * @return The current value of someProperty.
	 */
	public String getSomeProperty() {
		return someProperty;
	}

	/** 
	 * Setter for the property someProperty.
	 *
	 * @param someProperty The new value for someProperty.
	 */
	public void setSomeProperty2(final String someProperty) {
		final String oldSomeProperty = this.someProperty;
		this.someProperty = someProperty;
		try {
			propertyChangeSupport.firePropertyChange("someProperty", oldSomeProperty,
			                                         someProperty);
		} catch (final Exception ex) {
			LOGGER.error("Exception in Listener", ex);
		}
	}

	/** 
	 * @see javax.swing.table.TableModel
	 */
	public void setValueAt(final Object value, final int row, final int column) {
	}

	/** 
	 * @see javax.swing.table.TableModel
	 */
	public Object getValueAt(final int row, final int column) {
		return null;
	}

	/** 
	 * @see javax.swing.table.TableModel
	 */
	public void addTableModelListener(final TableModelListener listener) {
	}

	/** 
	 * demo method.
	 *
	 * @param customer The customer to operate on.
	 *
	 * @throws NullPointerException If the customer is null.
	 */
	public void billCreditCard(final Customer customer) {
		if (customer == null) {
			throw new NullPointerException();
		}
		System.err.println(customer);
	}

	/** 
	 * demo method.
	 */
	public void doOrderProcessing() {
	}

	/** 
	 * Gets data from the the database and caches it for the table model.
	 *
	 * @param conn The database connection to use.
	 * @param sql The SQL to use.
	 *
	 * @return The result value.
	 *
	 * @throws SQLException If there is a SQL error.
	 */
	public int loadData(final Connection conn, final String sql)
	    throws SQLException {
		int result = 0;
		Statement stmt = null;
		ResultSet rs = null;
		Object[] record = null;
		this.data = new ArrayList();
		try {
			this.sql = sql;
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			int idx = 0;
			int columnCount = rs.getMetaData()
				                .getColumnCount();
			while (rs.next()) {
				record = new Object[columnCount];
				for (idx = 0; idx < columnCount; idx++) {
					record[idx] = rs.getObject(idx);
				}
				data.add(record);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		return result;
	}

	/** 
	 * Gets data from the the database and caches it for the table model.
	 *
	 * @param conn The database connection to use.
	 * @param sql The SQL to use.
	 *
	 * @return The result value.
	 *
	 * @throws SQLException If there is a SQL error.
	 */
	public int loadData2(final Connection conn, final String sql)
	    throws SQLException {
		int result = 0;
		Statement stmt = null;
		ResultSet rs = null;
		Object[] record = null;
		ArrayList temp = new ArrayList();
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			int idx = 0;
			int columnCount = rs.getMetaData()
				                .getColumnCount();
			while (rs.next()) {
				record = new Object[columnCount];
				for (idx = 0; idx < columnCount; idx++) {
					record[idx] = rs.getObject(idx);
				}
				temp.add(record);
			}
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
		this.data = temp;
		this.sql = sql;
		return result;
	}

	/** 
	 * Processes an order.
	 *
	 * @param order The order to process.
	 * @param customer The customer to operate on.
	 */
	public void processOrder(final Object order, final Customer customer) {
		this.processedOrders.add(order);
		doOrderProcessing();
		billCreditCard(customer);
	}

	/** 
	 * Refreshes the data in the model using the existing SQL.
	 *
	 * @param conn The connection to the database to use.
	 *
	 * @throws SQLException If there is a database problem in the refresh.
	 */
	public void refresh(final Connection conn) throws SQLException {
		loadData(conn, this.sql);
	}

	/** 
	 * @see javax.swing.table.TableModel
	 */
	public void removeTableModelListener(TableModelListener arg0) {
	}
}

/* ########## End of File ########## */
