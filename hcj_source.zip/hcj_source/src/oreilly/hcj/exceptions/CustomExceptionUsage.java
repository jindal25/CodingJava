/*
 *     file: CustomExceptionUsage.java
 *  package: oreilly.hcj.exceptions
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.exceptions;

import java.util.Date;

/**  
 * Just demo code to check syntax of in book examples.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public class CustomExceptionUsage {
	/** Holds whether transaction is approved or not. */
	private boolean approved = true;

	/** Holds whether the card is valid or not. */
	private boolean validCard = true;

	/** 
	 * The poor practice of using multiple empty exception classes.
	 *
	 * @param cardNumber Cutomer's card number.
	 * @param expiration Expiration date of the card.
	 * @param amount Amount to bill.
	 *
	 * @throws BillingException If an error in the billing occurs.
	 * @throws CreditCardDeclinedException If the card is declined.
	 */
	public void billCard(String cardNumber, Date expiration, Float amount)
	    throws BillingException, CreditCardDeclinedException {
		// verify card type and expiration ...
		if (!validCard) {
			throw new BillingException();
		}

		// checking code ... 
		if (!approved) {
			System.err.println(cardNumber + "\t" + expiration + "\t" + amount);
			throw new CreditCardDeclinedException();
		}
	}

	/** 
	 * Using custom exceptions with error codes.
	 *
	 * @param cardNumber Cutomer's card number.
	 * @param expiration Expiration date of the card.
	 * @param amount Amount to bill.
	 *
	 * @throws MyCustomException If there is some problem billing the card.
	 */
	public void billCard2(String cardNumber, Date expiration, Float amount)
	    throws MyCustomException {
		// verify card type and expiration ...
		if (!validCard) {
			throw new MyCustomException(MyCustomException.BILLING_ERROR);
		}

		// checking code ... 
		if (!approved) {
			System.err.println(cardNumber + "\t" + expiration + "\t" + amount);
			throw new MyCustomException(MyCustomException.CREDIT_CARD_DECLINED);
		}
	}

	/** 
	 * Checks for card approval.
	 *
	 * @return True if approved, false otherwise.
	 */
	public boolean checkForApproval() {
		return true;
	}

	/**  
	 * An exception for billing.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.4 $
	 */
	private static class BillingException extends Exception {
	}

	/**  
	 * An exception for a declined card.
	 *
	 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
	 * @version $Revision: 1.4 $
	 */
	private static class CreditCardDeclinedException extends Exception {
	}
}

/* ########## End of File ########## */
