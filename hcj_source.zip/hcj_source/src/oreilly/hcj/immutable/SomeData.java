/*
 *     file: SomeData.java
 *  package: oreilly.hcj.immutable
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.immutable;

import java.awt.Point;

/**  
 * A demo of a false immutable type.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class SomeData {
	/** Holds the value */
	private final Point value;

	/** 
	 * Creates a new Monitor object.
	 *
	 * @param value The value.
	 */
	public SomeData(final Point value) {
		this.value = value;
	}

	/** 
	 * Getter for value.
	 *
	 * @return Returns the value.
	 */
	public Point getValue() {
		return value;
	}
}

/* ########## End of File ########## */
