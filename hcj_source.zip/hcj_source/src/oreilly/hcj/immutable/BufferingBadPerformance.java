/*
 *     file: BufferingBadPerformance.java
 *  package: oreilly.hcj.immutable
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.immutable;

/**  
 * Demo Program for the "BufferingBadPerformance" Section.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.6 $
 */
public class BufferingBadPerformance {
	/** Size of test array. */
	private static final int ARRAY_SIZE = 10000;

	/** 
	 * Creates a new instance of BufferingBadPerformance
	 */
	public BufferingBadPerformance() {
	}

	/** 
	 * Dumps an array to a string using concatenations in append calls.
	 *
	 * @param array The array to dump.
	 */
	public static final void dumpArray(int[] array) {
		final StringBuffer buf = new StringBuffer(500);
		buf.append("{");
		for (int idx = 0; idx < array.length; idx++) {
			buf.append("[" + idx + "] " + array[idx]);
		}
		buf.append("}");
	}

	/** 
	 * Dumps an array to a string <b>without</b> concatenations in append calls.
	 *
	 * @param array The array to dump.
	 */
	public static final void dumpArrayBetter(int[] array) {
		final StringBuffer buf = new StringBuffer(500);
		buf.append("{");
		for (int idx = 0; idx < array.length; idx++) {
			buf.append("[");
			buf.append(idx);
			buf.append("] ");
			buf.append(array[idx]);
		}
		buf.append("}");
	}

	/** 
	 * Dumps an array to a string using allocation to perform concatenation.
	 *
	 * @param array The array to dump.
	 */
	public static final void dumpArrayReallyBad(int[] array) {
		String result = new String("{");
		for (int idx = 0; idx < (array.length); idx++) {
			result += ("[" + idx + "] " + array[idx]);
		}
		result += "}";
	}

	/** 
	 * Main demonstration method.
	 *
	 * @param args command line arguments.
	 */
	public static void main(String[] args) {
		final int[] array = new int[ARRAY_SIZE];
		int idx = 0;
		int total = 0;

		long millis = System.currentTimeMillis();

		for (idx = 0; idx < array.length; idx++) {
			total += (idx + 1);
			array[idx] = total;
		}

		System.out.println("Building " + array.length
		                   + " element Fibbonacci Number array took "
		                   + (System.currentTimeMillis() - millis) + " millis");

		dumpArray(array);
		System.out.println("Using dumpArray took "
		                   + (System.currentTimeMillis() - millis) + " millis");

		// *** Use the optimal dump method.
		millis = System.currentTimeMillis();
		dumpArrayBetter(array);
		System.out.println("Using dumpArrayBetter took "
		                   + (System.currentTimeMillis() - millis) + " millis");

		// *** Use dump method that does string allocations
		millis = System.currentTimeMillis();
		dumpArrayReallyBad(array);
		System.out.println("Using dumpArrayReallyBad took "
		                   + (System.currentTimeMillis() - millis) + " millis");

		millis = System.currentTimeMillis();
	}
}

/* ########## End of File ########## */
