/*
 *     file: SomeDataObject.java
 *  package: oreilly.hcj.immutable
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.immutable;

import java.awt.Point;

/**  
 * A safe and encapsulated data object.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class SomeDataObject {
	/** Holds a coordinate to something. */
	private Point coordinate = new Point();

	/** 
	 * Set the coordinate.
	 *
	 * @param coordinate The new coordinate.
	 *
	 * @throws NullPointerException __UNDOCUMENTED__
	 * @throws IllegalArgumentException __UNDOCUMENTED__
	 */
	public void setCoordinate(final Point coordinate) {
		if (coordinate == null) {
			throw new NullPointerException("coordinate");  //$NON-NLS-1$
		}
		if ((coordinate.x < 0) || (coordinate.y < 0)) {
			throw new IllegalArgumentException();
		}
		this.coordinate = new Point(coordinate);
	}

	/** 
	 * Get the coordinate.
	 *
	 * @return The current coordinate object.
	 */
	public Point getCoordinate() {
		return new Point(coordinate);
	}
}

/* ########## End of File ########## */
