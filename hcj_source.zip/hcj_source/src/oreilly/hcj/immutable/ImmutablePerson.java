/*
 *     file: ImmutablePerson.java
 *  package: oreilly.hcj.immutable
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.immutable;

/**  
 * Some Data Class.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class ImmutablePerson {
	/** Holds the first name. */
	private String firstName;

	/** Holds the last name. */
	private String lastName;

	/** Holds the age. */
	private int age;

	/** 
	 * Creates a new ImmutablePerson object.
	 *
	 * @param firstName The first name for the person.
	 * @param lastName The last name for the person.
	 * @param age The age of the person.
	 *
	 * @throws NullPointerException __UNDOCUMENTED__
	 */
	public ImmutablePerson(final String firstName, final String lastName, final int age) {
		if (firstName == null) {
			throw new NullPointerException("firstName");  //$NON-NLS-1$
		}
		if (lastName == null) {
			throw new NullPointerException("lastName");  //$NON-NLS-1$
		}
		this.age = age;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	/** 
	 * Getter for age.
	 *
	 * @return Returns the age.
	 */
	public int getAge() {
		return age;
	}

	/** 
	 * Getter for firstName.
	 *
	 * @return Returns the firstName.
	 */
	public String getFirstName() {
		return firstName;
	}

	/** 
	 * Getter for lastName.
	 *
	 * @return Returns the lastName.
	 */
	public String getLastName() {
		return lastName;
	}
}

/* ########## End of File ########## */
