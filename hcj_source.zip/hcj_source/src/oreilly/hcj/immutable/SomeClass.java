/*
 *     file: SomeClass.java
 *  package: oreilly.hcj.immutable
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.immutable;

import java.awt.Point;

/**  
 * Class used to check syntax for HCJ chapter on immutable objects.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class SomeClass {
	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param args __UNDOCUMENTED__
	 */
	public static final void main(final String[] args) {
		Point position = new Point(25, 3);
		SomeData data = new SomeData(position);
		position.x = 22;
		System.out.println(data.getValue());
	}
}

/* ########## End of File ########## */
