/*
 *     file: TestWeakHashSet.java
 *  package: oreilly.hcj.references._test
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.references._test;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import oreilly.hcj.references.WeakHashSet;
import org.apache.log4j.Logger;

/**  
 * Test case for the WeakHashSet class.
 *
 * @author <a href="mailto:worderisor@yahoo.com">Robert Simmons jr.</a>
 * @version $Revision: 1.1 $
 *
 * @see mirror.utilities
 */
public class TestWeakHashSet extends TestCase {
	/** Holds the logger instance for the class. */
	private static final Logger LOGGER = Logger.getLogger(TestWeakHashSet.class);

	/** Assert string constant. */
	private static final String CONTAINS_ALL = "Testing containsAll(Collection): ";  //$NON-NLS-1$

	/** Assert string constant. */
	private static final String SIZE = "Testing size(): ";  //$NON-NLS-1$

	/** Assert string constant. */
	private static final String CONTAINS = "Testing contains(Object): ";  //$NON-NLS-1$

	/** Assert string constant. */
	private static final String IS_EMPTY = "Testing isEmpty(): ";  //$NON-NLS-1$

	/** Assert string constant. */
	private static final String ADD_ALL = "Testing addAll(Collection): ";  //$NON-NLS-1$

	/** Assert string constant. */
	private static final String RETAIN_ALL = "Testing retainAll(Collection): ";  //$NON-NLS-1$

	/** Assert string constant. */
	private static final String REMOVE_ALL = "Testing removeAll(Collection): ";  //$NON-NLS-1$

	/** Testing instance. */
	private static final String A = new String("Object A");  //$NON-NLS-1$

	/** Testing instance. */
	private static final String B = new String("Object B");  //$NON-NLS-1$

	/** Testing instance. */
	private static final String C = new String("Object C");  //$NON-NLS-1$

	/** Testing instance. */
	private static final String D = new String("Object D");  //$NON-NLS-1$

	/** Testing instance. */
	private static final String E = new String("Object E");  //$NON-NLS-1$

	/** Testing instance. */
	private static final String F = new String("Object F");  //$NON-NLS-1$

	/** Testing instance. */
	private static final String G = new String("Object G");  //$NON-NLS-1$

	/** Testing instance. */
	private static final Set TEST_SET;

	static {
		TEST_SET = new HashSet();
		TEST_SET.add(A);
		TEST_SET.add(B);
		TEST_SET.add(C);
		TEST_SET.add(D);
		TEST_SET.add(E);
		TEST_SET.add(F);
		TEST_SET.add(G);
	}

	/** 
	 * Creates a new instance of this test case.
	 *
	 * @param name The name of the test case.
	 */
	public TestWeakHashSet(final String name) {
		super(name);
	}

	/** 
	 * Run all the test using a text based Test runner..
	 *
	 * @param args Arguments (ignored).
	 */
	public static void main(final String[] args) {
		TestRunner.run(suite());
	}

	/** 
	 * Gets the suite for this test case.  {@inheritDoc}
	 *
	 * @return The test suite.
	 */
	public static Test suite() {
		TestSuite suite = new TestSuite();
		suite.setName("WeakHashSet");  //$NON-NLS-1$
		suite.addTest(new TestWeakHashSet("testGeneralFunctionality"));  //$NON-NLS-1$
		suite.addTest(new TestWeakHashSet("testSetOperations"));  //$NON-NLS-1$
		suite.addTest(new TestWeakHashSet("testToArray"));  //$NON-NLS-1$
		suite.addTest(new TestWeakHashSet("testWeakRefCleanup"));  //$NON-NLS-1$
		suite.addTest(new TestWeakHashSet("testIterators"));  //$NON-NLS-1$
		suite.addTest(new TestWeakHashSet("testStrongConversion"));  //$NON-NLS-1$
		return suite;
	}

	/** 
	 * Tests general WeakHashSet functionality.  <br>Validates:
	 * 
	 * <ul>
	 * <li>
	 * The method <tt>isEmpty()</tt> returns the correct result.
	 * </li>
	 * <li>
	 * The method <tt>contains(Object)</tt> returns the correct result.
	 * </li>
	 * <li>
	 * Objects can be inserted into the set.
	 * </li>
	 * <li>
	 * The method <tt>size()</tt> returns the correct size after insertion.
	 * </li>
	 * <li>
	 * Objects can be removed from the set.
	 * </li>
	 * <li>
	 * The set can be cleared.
	 * </li>
	 * </ul>
	 */
	public void testGeneralFunctionality() {
		WeakHashSet whs = new WeakHashSet();

		// *** isEmpty()
		assertEquals(IS_EMPTY, true, whs.isEmpty());

		// *** add(Object);
		whs.add(A);

		// *** isEmpty()
		assertEquals(IS_EMPTY, false, whs.isEmpty());

		// *** size()
		assertEquals(SIZE, 1, whs.size());

		// *** contains(Object)
		assertEquals(CONTAINS, true, whs.contains(A));
		whs.add(B);
		whs.add(C);
		assertEquals(SIZE, 3, whs.size());
		assertEquals(CONTAINS, true, whs.contains(C));
		whs.remove(C);
		assertEquals(CONTAINS, false, whs.contains(C));
		assertEquals(SIZE, 2, whs.size());

		// *** clear()
		whs.clear();
		assertEquals(IS_EMPTY, true, whs.isEmpty());
		assertEquals(CONTAINS, false, whs.contains(B));
		assertEquals(SIZE, 0, whs.size());

		// *** add(null) Which should exception.
		boolean exed = false;
		try {
			whs.add(null);
		} catch (NullPointerException ex) {
			exed = true;
		}
		assertEquals("Exception Wanted Test: ", true, exed);  //$NON-NLS-1$
		exed = false;
	}

	/** 
	 * Tests WeakHashSet iterator.  <br>Validates:
	 * 
	 * <ul>
	 * <li>
	 * Iterators can iterate through the set.
	 * </li>
	 * <li>
	 * Iterators correctly handle removed references.
	 * </li>
	 * </ul>
	 */
	public void testIterators() {
		try {
			String x = new String("Object x");  //$NON-NLS-1$
			String y = new String("Object y");  //$NON-NLS-1$
			String z = new String("Object z");  //$NON-NLS-1$
			ReferenceQueue queue = new ReferenceQueue();
			new WeakReference(x, queue);
			new WeakReference(y, queue);
			new WeakReference(z, queue);
			// *** add everything to the WeakHashSet
			WeakHashSet whs = new WeakHashSet();
			whs.addAll(TEST_SET);
			whs.add(x);
			whs.add(y);
			whs.add(z);

			// *** y should still be in the set as p.
			assertEquals(CONTAINS_ALL, true, whs.containsAll(TEST_SET));
			assertEquals(CONTAINS, true, whs.contains(x));
			assertEquals(CONTAINS, true, whs.contains(y));
			assertEquals(CONTAINS, true, whs.contains(z));
			assertEquals(SIZE, (TEST_SET.size() + 3), whs.size());
			// *** get an iterator
			Iterator iter = whs.iterator();

			// *** nuke the three weak objects.
			x = null;
			y = null;
			z = null;
			System.gc();
			while (queue.remove(1000) != null) {
			}

			// *** Iterate and make sure all memeber are in TEST_SET. (x, y, z skipped)
			Object obj = null;
			while (iter.hasNext()) {
				obj = iter.next();
				assertEquals(CONTAINS_ALL, true, TEST_SET.contains(obj));
			}
		} catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			fail(ex.getMessage());
		}
	}

	/** 
	 * Tests WeakHashSet set operations functionality.  <br>Validates:
	 * 
	 * <ul>
	 * <li>
	 * The method <tt>addAll(Collection)</tt> works properly.
	 * </li>
	 * <li>
	 * The method <tt>containsAll(Collection)</tt> works properly.
	 * </li>
	 * <li>
	 * The method <tt>retainAll(Collection)</tt> works properly.
	 * </li>
	 * <li>
	 * The method <tt>removeAll(Collection)</tt> works properly.
	 * </li>
	 * </ul>
	 */
	public void testSetOperations() {
		WeakHashSet whs = new WeakHashSet();
		HashSet hs = new HashSet();
		Set st = new TreeSet();
		List lst = new LinkedList();

		// *** containsAll(Collection)
		whs.add(A);
		whs.add(B);
		whs.add(C);
		whs.add(D);
		st.add(A);
		st.add(B);
		assertEquals(CONTAINS_ALL, true, whs.containsAll(st));
		st.add(C);
		assertEquals(CONTAINS_ALL, true, whs.containsAll(st));
		st.add(D);
		st.add(E);
		assertEquals(CONTAINS_ALL, false, whs.containsAll(st));
		assertEquals(SIZE, 4, whs.size());

		// *** addAll(Collection)
		hs.add(C);
		assertEquals(ADD_ALL, false, whs.addAll(hs));
		hs.add(E);
		hs.add(F);
		assertEquals(ADD_ALL, true, whs.addAll(hs));
		assertEquals(ADD_ALL, false, whs.addAll(hs));
		hs.add(G);
		assertEquals(ADD_ALL, true, whs.addAll(hs));
		assertEquals(SIZE, 7, whs.size());
		assertEquals(CONTAINS_ALL, true, whs.containsAll(st));
		assertEquals(CONTAINS_ALL, true, whs.containsAll(hs));

		// *** removeAll(Collection)    
		assertEquals(REMOVE_ALL, true, whs.removeAll(hs));
		assertEquals(REMOVE_ALL, false, whs.removeAll(hs));
		assertEquals(CONTAINS_ALL, false, whs.containsAll(hs));

		// *** retainAll(Collection)        
		lst.add(A);
		lst.add(B);
		assertEquals(RETAIN_ALL, true, whs.retainAll(lst));
		assertEquals(RETAIN_ALL, false, whs.retainAll(lst));
		assertEquals(CONTAINS_ALL, true, whs.containsAll(lst));
		assertEquals(CONTAINS_ALL, false, whs.containsAll(st));
		assertEquals(SIZE, lst.size(), whs.size());
	}

	/** 
	 * Test conversion from weak hash set to normal hash set.
	 */
	public void testStrongConversion() {
		WeakHashSet weak = new WeakHashSet(TEST_SET);
		Set set = new HashSet(weak);
		Set lset = new LinkedHashSet(weak);
		assertTrue("Testing conversion to HashSet: ", set.equals(weak));  //$NON-NLS-1$
		assertTrue("Testing conversion to HashSet: ", lset.equals(weak));  //$NON-NLS-1$
	}

	/** 
	 * Tests WeakHashSet array conversion functionality.  <br>Validates:
	 * 
	 * <ul>
	 * <li>
	 * The method <tt>toArray()</tt> works properly.
	 * </li>
	 * <li>
	 * The method <tt>toArray(Object[])</tt> works properly.
	 * </li>
	 * </ul>
	 */
	public void testToArray() {
		WeakHashSet whs = new WeakHashSet();
		whs.addAll(TEST_SET);
		// *** toArray()    
		Object[] strArrayOne = whs.toArray();
		assertEquals("Testing toArray(): ", true,  //$NON-NLS-1$
		             Arrays.asList(strArrayOne).containsAll(TEST_SET));
		// *** toArray(Object[])    
		String[] strArrayTwo = new String[1];
		strArrayTwo = (String[])whs.toArray(strArrayTwo);
		assertEquals("Testing toArray(): ", true,  //$NON-NLS-1$
		             Arrays.asList(strArrayTwo).containsAll(TEST_SET));
	}

	/** 
	 * Tests Removal of references when object is garbage collected.  <br>Validates:
	 * 
	 * <ul>
	 * <li>
	 * The method <tt>size()</tt> returns the correct size after insertion.
	 * </li>
	 * <li>
	 * Objects can be inserted into the set.
	 * </li>
	 * <li>
	 * The weak referenced object should vanish from the set.
	 * </li>
	 * <li>
	 * The objects that have strong references should still be in the set.
	 * </li>
	 * </ul>
	 */
	public void testWeakRefCleanup() {
		try {
			String x = new String("Object x");  //$NON-NLS-1$
			String y = new String("Object y");  //$NON-NLS-1$
			String z = new String("Object z");  //$NON-NLS-1$
			ReferenceQueue queue = new ReferenceQueue();
			new WeakReference(x, queue);
			new WeakReference(y, queue);
			new WeakReference(z, queue);
			// *** add everything to the WeakHashSet
			WeakHashSet whs = new WeakHashSet();
			whs.addAll(TEST_SET);
			whs.add(x);
			whs.add(y);
			whs.add(z);

			// *** validate everything in the WeakHashSet    
			assertEquals(CONTAINS_ALL, true, whs.containsAll(TEST_SET));
			assertEquals(CONTAINS, true, whs.contains(x));
			assertEquals(CONTAINS, true, whs.contains(y));
			assertEquals(CONTAINS, true, whs.contains(z));

			// *** nuke x from the vm. 
			x = null;
			System.gc();
			while (queue.remove(1000) != null) {
			}

			// *** make sure x isnt in the set anymore but all others are.
			assertEquals(CONTAINS_ALL, true, whs.containsAll(TEST_SET));
			assertEquals(CONTAINS, true, whs.contains(y));
			assertEquals(CONTAINS, true, whs.contains(z));
			assertEquals(SIZE, (TEST_SET.size() + 2), whs.size());
			// *** build a double link, p, to y and nuke z.
			String p = y;
			z = null;
			System.gc();
			while (queue.remove(1000) != null) {
			}

			// *** make sure x, and z isnt in the set anymore but all others are.
			assertEquals(CONTAINS_ALL, true, whs.containsAll(TEST_SET));
			assertEquals(CONTAINS, true, whs.contains(y));
			assertEquals(SIZE, (TEST_SET.size() + 1), whs.size());

			// *** nuke y but leave p intact.
			y = null;
			System.gc();
			while (queue.remove(1000) != null) {
			}

			// *** y should still be in the set as p.
			assertEquals(CONTAINS_ALL, true, whs.containsAll(TEST_SET));
			assertEquals(CONTAINS, true, whs.contains(p));
			assertEquals(SIZE, (TEST_SET.size() + 1), whs.size());

			// *** finally nuke p.
			p = null;
			System.gc();
			while (queue.remove(1000) != null) {
			}

			// *** y should still be in the set as p.
			assertEquals(CONTAINS_ALL, true, whs.containsAll(TEST_SET));
			assertEquals(SIZE, (TEST_SET.size()), whs.size());
		} catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			fail(ex.getMessage());
		}
	}
}

/* ########## End of File ########## */
