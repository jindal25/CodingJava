/*
 *     file: SomeGUIPanel.java
 *  package: oreilly.hcj.references
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.references;

import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**  
 * A demo gui panel with a memory leak.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class SomeGUIPanel extends JPanel implements ActionListener,
                                                    PropertyChangeListener {
	/** The object being managed. */
	public SomeDataClass dataObject = null;

	/** Holds the field used for value input. */
	JTextField valueField;

	/** 
	 * Creates a new SomeGUIPanel object.
	 *
	 * @param obj The object to manage.
	 */
	public SomeGUIPanel(final SomeDataClass obj) {
		this.setLayout(new GridLayout(1, 2));
		JLabel label = new JLabel("Age: ", SwingConstants.RIGHT);
		this.add(label);
		this.valueField = new JTextField();
		this.valueField.addActionListener(this);
		this.add(this.valueField);
		changeObject(obj);
	}

	/** 
	 * @see java.awt.event.ActionListener
	 */
	public void actionPerformed(final ActionEvent event) {
		if (event.getSource() == this.valueField) {
			try {
				int temp = Integer.parseInt(this.valueField.getText());
				this.dataObject.setAge(temp);
			} catch (final NumberFormatException ex) {
				Toolkit.getDefaultToolkit()
				       .beep();
			}
		}
	}

	/** 
	 * Change the managed object to another one.
	 *
	 * @param obj The object to manage.
	 */
	public void changeObject(final SomeDataClass obj) {
		this.dataObject = obj;
		this.dataObject.addPropertyChangeListener(this);
		this.valueField.setText(Integer.toString(obj.getAge()));
	}

	/** 
	 * @see java.beans.PropertyChangeListener
	 */
	public void propertyChange(final PropertyChangeEvent event) {
		if (event.getSource() == this.dataObject) {
			this.valueField.setText(Integer.toString(this.dataObject.getAge()));
		}
	}
}

/* ########## End of File ########## */
