/*
 *     file: SomeDataClass.java
 *  package: oreilly.hcj.references
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.references;

import java.beans.PropertyChangeListener;

/**  
 * A demo data class with property change listeners.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class SomeDataClass {
	/** Utility field used by bound properties. */
	protected PropertyChangeSupport propertyChangeSupport =
		new PropertyChangeSupport(this);

	/** A demo property */
	private int age = 0;

	/** 
	 * Setter for property value.
	 *
	 * @param value The new age.
	 */
	public void setAge(final int value) {
		final int oldAge = this.age;
		this.age = value;
		this.propertyChangeSupport.firePropertyChange("value", oldAge, this.age);
	}

	/** 
	 * Getter for property age.
	 *
	 * @return The current value of the property age.
	 */
	public int getAge() {
		return this.age;
	}

	/** 
	 * Add a property change listener.
	 *
	 * @param lst The listener to add.
	 */
	public void addPropertyChangeListener(final PropertyChangeListener lst) {
		propertyChangeSupport.addPropertyChangeListener(lst);
	}

	/** 
	 * Remove a property change listener.
	 *
	 * @param lst The listener to add.
	 */
	public void removePropertyChangeListener(final PropertyChangeListener lst) {
		propertyChangeSupport.removePropertyChangeListener(lst);
	}
}

/* ########## End of File ########## */
