/*
 *     file: ExternalTransaction.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.datamodeling.constraints.StringConstraint;

/**  
 * A transaction desined for an account outside the bank.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class ExternalTransaction extends Transaction {
	/** Constraint for the property account. */
	public static final StringConstraint ACCOUNT_CONSTRAINT =
		new StringConstraint("account", false, 20);

	/** Constraint for the property institution. */
	public static final StringConstraint INSTITUTION_CONSTRAINT =
		new StringConstraint("institution", false, 20);

	/** Constraint for the property routing. */
	public static final StringConstraint ROUTING_CONSTRAINT =
		new StringConstraint("routing", false, 20);

	/** The account name or number destination. */
	private String account;

	/** The institution name where the account is located. */
	private String institution;

	/** The routing code for the institution. */
	private String routing;

	/** 
	 * Setter for property account.
	 *
	 * @param account New value of property account.
	 */
	public void setAccount(final String account) {
		ACCOUNT_CONSTRAINT.validate(account);
		final String oldAccount = this.account;
		this.account = account;
		propertyChangeSupport.firePropertyChange("account", oldAccount, this.account);
	}

	/** 
	 * Getter for property account.
	 *
	 * @return Value of property account.
	 */
	public String getAccount() {
		return account;
	}

	/** 
	 * Setter for property institution.
	 *
	 * @param institution New value of property institution.
	 */
	public void setInstitution(final String institution) {
		INSTITUTION_CONSTRAINT.validate(institution);
		final String oldInstitution = this.institution;
		this.institution = institution;
		propertyChangeSupport.firePropertyChange("institution", oldInstitution,
		                                         this.institution);
	}

	/** 
	 * Getter for property institution.
	 *
	 * @return Value of property institution.
	 */
	public String getInstitution() {
		return institution;
	}

	/** 
	 * Setter for property routing.
	 *
	 * @param routing New value of property routing.
	 */
	public void setRouting(final String routing) {
		ROUTING_CONSTRAINT.validate(routing);
		final String oldRouting = this.routing;
		this.routing = routing;
		propertyChangeSupport.firePropertyChange("routing", oldRouting, this.routing);
	}

	/** 
	 * Getter for property routing.
	 *
	 * @return Value of property routing.
	 */
	public java.lang.String getRouting() {
		return routing;
	}
}

/* ########## End of File ########## */
