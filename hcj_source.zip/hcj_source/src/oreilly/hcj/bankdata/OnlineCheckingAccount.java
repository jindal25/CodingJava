/*
 *     file: OnlineCheckingAccount.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.datamodeling.constraints.NumericConstraint;

/**  
 * An account used for online checking including transactions.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class OnlineCheckingAccount extends AssetAccount {
	/** Constraint for the property creditLimit. */
	public static final NumericConstraint CREDIT_LIMIT_CONSTRAINT =
		new NumericConstraint("creditLimit", false, Float.class, new Float(0.0),
		                      new Float(Float.MAX_VALUE));

	/**
	 * The amount below zero that this account can be before transactions start beign
	 * rejected.
	 */
	private Float creditLimit;

	/** 
	 * Setter for property creditLimit.
	 *
	 * @param creditLimit New value of property creditLimit.
	 */
	public void setCreditLimit(final Float creditLimit) {
		CREDIT_LIMIT_CONSTRAINT.validate(creditLimit);
		final Float oldCreditLimit = this.creditLimit;
		this.creditLimit = creditLimit;
		propertyChangeSupport.firePropertyChange("creditLimit", oldCreditLimit,
		                                         this.creditLimit);
	}

	/** 
	 * Getter for property creditLimit.
	 *
	 * @return Value of property creditLimit.
	 */
	public Float getCreditLimit() {
		return creditLimit;
	}
}

/* ########## End of File ########## */
