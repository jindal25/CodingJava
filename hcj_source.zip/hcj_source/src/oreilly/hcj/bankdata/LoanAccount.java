/*
 *     file: LoanAccount.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.datamodeling.constraints.NumericConstraint;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;

/**  
 * An account representing a principal loan to a customer.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class LoanAccount extends LiabilityAccount {
	/** Constraint for the property payment. */
	public static final ObjectConstraint PAYMENT_CONSTRAINT =
		new ObjectConstraint("payment", false, AutomaticPayment.class);

	/** Constraint for the property interestPaid. */
	public static final NumericConstraint INTEREST_PAID_CONSTRAINT =
		new NumericConstraint("interestPaid", false, Float.class, new Float(0.0),
		                      new Float(Float.MAX_VALUE));

	/** Constraint for the property originalPrincipal. */
	public static final NumericConstraint ORIGINAL_PRINCIPAL_CONSTRAINT =
		new NumericConstraint("originalPrincipal", false, Float.class, new Float(0.0),
		                      new Float(Float.MAX_VALUE));

	/** Constraint for the property amount. */
	public static final NumericConstraint AMOUNT_CONSTRAINT =
		new NumericConstraint("amount", false, Float.class, new Float(0.0),
		                      new Float(Float.MAX_VALUE));

	/** Constraint for the property duration. */
	public static final NumericConstraint DURATION_CONSTRAINT =
		new NumericConstraint("duration", false, Integer.class, new Integer(0),
		                      new Integer(999));

	/** Constraint for the property application. */
	public static final ObjectConstraint APPLICATION_CONSTRAINT =
		new ObjectConstraint("application", false, LoanApplication.class);

	/** The monthly payment instance for this loan. */
	private AutomaticPayment payment;

	/** The interest that the customer has paid on this loan for the life of the loan. */
	private Float interestPaid;

	/** The original principal borrowed on the loan. */
	private Float originalPrincipal;

	/** The duration of the loan in months. */
	private Integer duration;

	/** The application that resulted in this account. */
	private LoanApplication application;

	/** 
	 * Setter for property application.
	 *
	 * @param application New value of property application.
	 */
	public void setApplication(final LoanApplication application) {
		APPLICATION_CONSTRAINT.validate(application);
		final LoanApplication oldApplication = this.application;
		this.application = application;
		propertyChangeSupport.firePropertyChange("application", oldApplication,
		                                         this.application);
	}

	/** 
	 * Getter for property application.
	 *
	 * @return Value of property application.
	 */
	public LoanApplication getApplication() {
		return application;
	}

	/** 
	 * Setter for property duration.
	 *
	 * @param duration New value of property duration.
	 */
	public void setDuration(final Integer duration) {
		DURATION_CONSTRAINT.validate(duration);
		final Integer oldDuration = this.duration;
		this.duration = duration;
		propertyChangeSupport.firePropertyChange("duration", oldDuration, this.duration);
	}

	/** 
	 * Getter for property duration.
	 *
	 * @return Value of property duration.
	 */
	public Integer getDuration() {
		return duration;
	}

	/** 
	 * Setter for property interestPaid.
	 *
	 * @param interestPaid New value of property interestPaid.
	 */
	public void setInterestPaid(final Float interestPaid) {
		INTEREST_PAID_CONSTRAINT.validate(interestPaid);
		final Float oldInterestPaid = this.interestPaid;
		this.interestPaid = interestPaid;
		propertyChangeSupport.firePropertyChange("interestPaid", oldInterestPaid,
		                                         this.interestPaid);
	}

	/** 
	 * Getter for property interestPaid.
	 *
	 * @return Value of property interestPaid.
	 */
	public Float getInterestPaid() {
		return interestPaid;
	}

	/** 
	 * Setter for property originalPrincipal.
	 *
	 * @param originalPrincipal New value of property originalPrincipal.
	 */
	public void setOriginalPrincipal(final Float originalPrincipal) {
		ORIGINAL_PRINCIPAL_CONSTRAINT.validate(originalPrincipal);
		final Float oldOriginalPrincipal = this.originalPrincipal;
		this.originalPrincipal = originalPrincipal;
		propertyChangeSupport.firePropertyChange("originalPrincipal",
		                                         oldOriginalPrincipal,
		                                         this.originalPrincipal);
	}

	/** 
	 * Getter for property originalPrincipal.
	 *
	 * @return Value of property originalPrincipal.
	 */
	public Float getOriginalPrincipal() {
		return originalPrincipal;
	}

	/** 
	 * Setter for property payment.
	 *
	 * @param payment New value of property payment.
	 */
	public void setPayment(final AutomaticPayment payment) {
		PAYMENT_CONSTRAINT.validate(payment);
		final AutomaticPayment oldPayment = this.payment;
		this.payment = payment;
		propertyChangeSupport.firePropertyChange("payment", oldPayment, this.payment);
	}

	/** 
	 * Getter for property payment.
	 *
	 * @return Value of property payment.
	 */
	public AutomaticPayment getPayment() {
		return payment;
	}
}

/* ########## End of File ########## */
