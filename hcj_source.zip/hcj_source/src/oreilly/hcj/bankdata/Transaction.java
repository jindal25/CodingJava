/*
 *     file: Transaction.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import java.util.Date;
import java.util.Locale;
import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.datamodeling.constraints.DateConstraint;
import oreilly.hcj.datamodeling.constraints.NumericConstraint;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;
import oreilly.hcj.datamodeling.constraints.StringConstraint;

/**  
 * A transaction between two accounts.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.5 $
 */
public class Transaction extends MutableObject {
	/** Constraint for the property code. */
	public static final StringConstraint CODE_CONSTRAINT =
		new StringConstraint("code", false, 15);

	/** Constraint for the property source. */
	public static final ObjectConstraint SOURCE_CONSTRAINT =
		new ObjectConstraint("source", false, Account.class);

	/** Constraint for the property target. */
	public static final ObjectConstraint TARGET_CONSTRAINT =
		new ObjectConstraint("target", false, Account.class);

	/** Constraint for the property successful. */
	public static final ObjectConstraint SUCCESSFUL_CONSTRAINT =
		new ObjectConstraint("successful", false, Boolean.class);

	/** Constraint for the property requester. */
	public static final ObjectConstraint REQUESTER_CONSTRAINT =
		new ObjectConstraint("requester", false, Customer.class);

	/** Constraint for the property timestamp. */
	public static final DateConstraint TIMESTAMP_CONSTRAINT =
		new DateConstraint("timestamp", false, "01/01/1960", "12/31/3000", Locale.US);

	/** Constraint for the property amount. */
	public static final NumericConstraint AMOUNT_CONSTRAINT =
		new NumericConstraint("amount", false, Float.class, new Float(0.0),
		                      new Float(Float.MAX_VALUE));

	/** Constraint for the property fee. */
	public static final NumericConstraint FEE_CONSTRAINT =
		new NumericConstraint("fee", false, Float.class, new Float(0.0),
		                      new Float(Float.MAX_VALUE));

	/** The source of the money being transferred. */
	private Account source;

	/** The target of the money being transferred. */
	private Account target;

	/** Whether or not the transaction was executed successfully. */
	private Boolean successful;

	/** The customer requesting the transaction. */
	private Customer requester;

	/** The time and date of the transaction's attempted execution. */
	private Date timestamp;

	/** The amount to be transferred. */
	private Float amount;

	/** The fee charged for this transaction. */
	private Float fee;

	/** Holds value of property code. */
	private String code;

	/** 
	 * Setter for property amount.
	 *
	 * @param amount New value of property amount.
	 */
	public void setAmount(final Float amount) {
		AMOUNT_CONSTRAINT.validate(amount);
		final Float oldAmount = this.amount;
		this.amount = amount;
		propertyChangeSupport.firePropertyChange("amount", oldAmount, this.amount);
	}

	/** 
	 * Getter for property amount.
	 *
	 * @return Value of property amount.
	 */
	public Float getAmount() {
		return amount;
	}

	/** 
	 * Setter for property code.
	 *
	 * @param code New value of property code.
	 */
	public void setCode(final String code) {
		CODE_CONSTRAINT.validate(code);
		final String oldCode = this.code;
		this.code = code;
		propertyChangeSupport.firePropertyChange("code", oldCode, code);
	}

	/** 
	 * Getter for property code.
	 *
	 * @return Value of property code.
	 */
	public String getCode() {
		return this.code;
	}

	/** 
	 * Setter for property fee.
	 *
	 * @param fee New value of property fee.
	 */
	public void setFee(final Float fee) {
		FEE_CONSTRAINT.validate(fee);
		final Float oldFee = this.fee;
		this.fee = fee;
		propertyChangeSupport.firePropertyChange("fee", oldFee, this.fee);
	}

	/** 
	 * Getter for property fee.
	 *
	 * @return Value of property fee.
	 */
	public Float getFee() {
		return fee;
	}

	/** 
	 * Setter for property requester.
	 *
	 * @param requester New value of property requester.
	 */
	public void setRequester(final Customer requester) {
		REQUESTER_CONSTRAINT.validate(requester);
		final Customer oldRequester = this.requester;
		this.requester = requester;
		propertyChangeSupport.firePropertyChange("requester", oldRequester, this.requester);
	}

	/** 
	 * Getter for property requester.
	 *
	 * @return Value of property requester.
	 */
	public Customer getRequester() {
		return requester;
	}

	/** 
	 * Setter for property source.
	 *
	 * @param source New value of property source.
	 */
	public void setSource(final Account source) {
		SOURCE_CONSTRAINT.validate(source);
		final Account oldSource = this.source;
		this.source = source;
		propertyChangeSupport.firePropertyChange("source", oldSource, this.source);
	}

	/** 
	 * Getter for property source.
	 *
	 * @return Value of property source.
	 */
	public Account getSource() {
		return source;
	}

	/** 
	 * Setter for property successful.
	 *
	 * @param successful New value of property successful.
	 */
	public void setSuccessful(final Boolean successful) {
		SUCCESSFUL_CONSTRAINT.validate(successful);
		final Boolean oldSuccessful = this.successful;
		this.successful = successful;
		propertyChangeSupport.firePropertyChange("successful", oldSuccessful,
		                                         this.successful);
	}

	/** 
	 * Getter for property successful.
	 *
	 * @return Value of property successful.
	 */
	public Boolean getSuccessful() {
		return successful;
	}

	/** 
	 * Setter for property target.
	 *
	 * @param target New value of property target.
	 */
	public void setTarget(final Account target) {
		TARGET_CONSTRAINT.validate(target);
		final Account oldTarget = this.target;
		this.target = target;
		propertyChangeSupport.firePropertyChange("target", oldTarget, this.target);
	}

	/** 
	 * Getter for property target.
	 *
	 * @return Value of property target.
	 */
	public Account getTarget() {
		return target;
	}

	/** 
	 * Setter for property timestamp.
	 *
	 * @param timestamp New value of property timestamp.
	 */
	public void setTimestamp(Date timestamp) {
		TIMESTAMP_CONSTRAINT.validate(timestamp);
		final Date oldTimeStamp = this.timestamp;
		this.timestamp = timestamp;
		propertyChangeSupport.firePropertyChange("timestamp", oldTimeStamp, this.timestamp);
	}

	/** 
	 * Getter for property timestamp.
	 *
	 * @return Value of property timestamp.
	 */
	public Date getTimestamp() {
		return timestamp;
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof Transaction)) {
			return false;
		} else {
			return (((Transaction)obj).getCode().equals(this.code));
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.code.hashCode();
	}
}

/* ########## End of File ########## */
