/*
 *     file: Gender.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.constants.ConstantObject;

/**  
 * A gender for a person.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public final class Gender extends ConstantObject {
	/** The gender for a male. */
	public static final Gender MALE = new Gender("MALE");

	/** The gender for a female. */
	public static final Gender FEMALE = new Gender("FEMALE");

	/** 
	 * Creates a new Gender object.
	 *
	 * @param name Name of the new gender.
	 */
	private Gender(final String name) {
		super(name);
	}
}

/* ########## End of File ########## */
