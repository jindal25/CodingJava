/*
 *     file: Customer.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import java.awt.Color;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.datamodeling.constraints.CollectionConstraint;
import oreilly.hcj.datamodeling.constraints.NumericConstraint;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;
import oreilly.hcj.datamodeling.constraints.StringConstraint;

/**  
 * A customer of the bank.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.7 $
 */
public class Customer extends MutableObject {
	/** Constraint for the property cardColor. */
	public static final ObjectConstraint CARD_COLOR_CONSTRAINT =
		new ObjectConstraint("cardColor", false, Color.class);

	/** Constraint for the property customerID. */
	public static final NumericConstraint CUSTOMER_ID_CONSTRAINT =
		new NumericConstraint("customerID", false, Integer.class, new Integer(0),
		                      new Integer(999999999));

	/** Constraint for the property email. */
	public static final StringConstraint EMAIL_CONSTRAINT =
		new StringConstraint("email", false, 150);

	/** Constraint for the property accounts. */
	public static final CollectionConstraint ACCOUNTS_CONSTRAINT =
		new CollectionConstraint("accounts", false, Set.class, Account.class);

	/** Constraint for the property applications. */
	public static final CollectionConstraint APPLICATIONS_CONSTRAINT =
		new CollectionConstraint("applications", false, Set.class, LoanApplication.class);

	/** Constraint for the property payments. */
	public static final CollectionConstraint PAYMENTS_CONSTRAINT =
		new CollectionConstraint("payments", false, Set.class, AutomaticPayment.class);

	/** Constraint for the property email. */
	public static final StringConstraint PASS_PHRASE_CONSTRAINT =
		new StringConstraint("passPhrase", false, 150);

	/** Constraint for the property person. */
	public static final ObjectConstraint PERSON_CONSTRAINT =
		new ObjectConstraint("person", false, Person.class);

	/** Holds value of property cardColor. */
	private Color cardColor = Color.blue;

	/** The ID of the customer. A 9 digit number. */
	private Integer customerID;

	/** The unique id for this employee */
	private Person person;

	/** The accounts held by the customer. */
	private Set accounts = new HashSet();  // of type Account

	/** Applications for loans filed by the customer. */
	private Set applications = new HashSet();

	/** The monthly automatic payments beign paid by the customer. */
	private Set payments = new HashSet();

	/** The email address of the customer */
	private String email;

	/** The pass phrase of the customer */
	private String passPhrase;

	/** 
	 * Setter for property accounts.
	 *
	 * @param accounts New value of property accounts.
	 */
	public void setAccounts(final Set accounts) {
		ACCOUNTS_CONSTRAINT.validate(accounts);
		final Set oldAccounts = Collections.unmodifiableSet(this.accounts);
		this.accounts = new HashSet(accounts);
		propertyChangeSupport.firePropertyChange("accounts", oldAccounts, getAccounts());
	}

	/** 
	 * Getter for property accounts.
	 *
	 * @return Value of property accounts.
	 */
	public Set getAccounts() {
		return Collections.unmodifiableSet(accounts);
	}

	/** 
	 * Setter for property applications.
	 *
	 * @param applications New value of property applications.
	 */
	public void setApplications(final Set applications) {
		APPLICATIONS_CONSTRAINT.validate(applications);
		final Set oldApplications = Collections.unmodifiableSet(this.applications);
		this.applications = new HashSet(applications);
		propertyChangeSupport.firePropertyChange("applications", oldApplications,
		                                         getApplications());
	}

	/** 
	 * Getter for property applications.
	 *
	 * @return Value of property applications.
	 */
	public Set getApplications() {
		return Collections.unmodifiableSet(applications);
	}

	/** 
	 * Setter for property favoriteColor.
	 *
	 * @param cardColor New value of property favoriteColor.
	 */
	public void setCardColor(final Color cardColor) {
		CARD_COLOR_CONSTRAINT.validate(cardColor);
		final Color oldCardColor = this.cardColor;
		this.cardColor = cardColor;
		propertyChangeSupport.firePropertyChange("cardColor", oldCardColor, cardColor);
	}

	/** 
	 * Getter for property favoriteColor.
	 *
	 * @return Value of property favoriteColor.
	 */
	public Color getCardColor() {
		return this.cardColor;
	}

	/** 
	 * Setter for property customerID.
	 *
	 * @param customerID New value of property customerID.
	 */
	public void setCustomerID(final Integer customerID) {
		CUSTOMER_ID_CONSTRAINT.validate(customerID);
		final Integer oldCustomerID = this.customerID;
		this.customerID = customerID;
		propertyChangeSupport.firePropertyChange("customerID", oldCustomerID,
		                                         this.customerID);
	}

	/** 
	 * Getter for property customerID.
	 *
	 * @return Value of property customerID.
	 */
	public java.lang.Integer getCustomerID() {
		return customerID;
	}

	/** 
	 * Setter for property email.
	 *
	 * @param email New value of property email.
	 */
	public void setEmail(final String email) {
		EMAIL_CONSTRAINT.validate(email);
		final String oldEmail = this.email;
		this.email = email;
		propertyChangeSupport.firePropertyChange("email", oldEmail, this.email);
	}

	/** 
	 * Getter for property email.
	 *
	 * @return Value of property email.
	 */
	public String getEmail() {
		return email;
	}

	/** 
	 * Setter for property passPhrase.
	 *
	 * @param passPhrase New value of property passPhrase.
	 */
	public void setPassPhrase(final String passPhrase) {
		EMAIL_CONSTRAINT.validate(passPhrase);
		final String oldPassPhrase = this.passPhrase;
		this.passPhrase = passPhrase;
		propertyChangeSupport.firePropertyChange("passPhrase", oldPassPhrase,
		                                         this.passPhrase);
	}

	/** 
	 * Getter for property passPhrase.
	 *
	 * @return Value of property passPhrase.
	 */
	public String getPassPhrase() {
		return passPhrase;
	}

	/** 
	 * Setter for property payments.
	 *
	 * @param payments New value of property payments.
	 */
	public void setPayments(final Set payments) {
		PAYMENTS_CONSTRAINT.validate(payments);
		final Set oldPayments = Collections.unmodifiableSet(this.payments);
		this.payments = new HashSet(payments);
		propertyChangeSupport.firePropertyChange("payments", oldPayments, getPayments());
	}

	/** 
	 * Getter for property payments.
	 *
	 * @return Value of property payments.
	 */
	public Set getPayments() {
		return Collections.unmodifiableSet(payments);
	}

	/** 
	 * Setter for property person.
	 *
	 * @param person New value of property person.
	 */
	public void setPerson(final Person person) {
		PERSON_CONSTRAINT.validate(person);
		final Person oldPerson = this.person;
		this.person = person;
		propertyChangeSupport.firePropertyChange("person", oldPerson, this.person);
	}

	/** 
	 * Getter for property person.
	 *
	 * @return Value of property person.
	 */
	public Person getPerson() {
		return person;
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof Customer)) {
			return false;
		} else {
			return (((Customer)obj).getCustomerID().equals(this.customerID));
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.customerID.hashCode();
	}
}

/* ########## End of File ########## */
