/*
 *     file: LoanApplicationStatus.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.constants.ConstantObject;

/**  
 * The status of a loan application.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public final class LoanApplicationStatus extends ConstantObject {
	/** Status for an approved loan. */
	public static final LoanApplicationStatus APPROVED =
		new LoanApplicationStatus("APPROVED");

	/** Status for a denied loan. */
	public static final LoanApplicationStatus DENIED =
		new LoanApplicationStatus("DENIED");

	/** Status for a pending loan. */
	public static final LoanApplicationStatus PENDING =
		new LoanApplicationStatus("PENDING");

	/** Status for a loan waiting for collateral documents prior to approval. */
	public static final LoanApplicationStatus PENDING_COLLATERAL_DOCS =
		new LoanApplicationStatus("PENDING_COLLATERAL_DOCS");

	/** 
	 * Creates a new LoanApplicationStatus object.
	 *
	 * @param name The name of the new status.
	 */
	private LoanApplicationStatus(final String name) {
		super(name);
	}
}

/* ########## End of File ########## */
