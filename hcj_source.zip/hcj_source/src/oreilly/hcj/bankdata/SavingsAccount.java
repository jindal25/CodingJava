/*
 *     file: SavingsAccount.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.datamodeling.constraints.NumericConstraint;

/**  
 * An account that earns interest but cannot be used in transactions without assistance
 * from a bank emplyee.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class SavingsAccount extends AssetAccount {
	/** Constraint for the property interestRate. */
	public static final NumericConstraint INTEREST_RATE_CONSTRAINT =
		new NumericConstraint("interestRate", false, Float.class, new Float(0.0),
		                      new Float(1.0));

	/** The interest rate paid monthly on balances in this account. */
	private Float interestRate;

	/** 
	 * Setter for property interestRate.
	 *
	 * @param interestRate New value of property interestRate.
	 */
	public void setInterestRate(final Float interestRate) {
		INTEREST_RATE_CONSTRAINT.validate(interestRate);
		final Float oldInterestRate = this.interestRate;
		this.interestRate = interestRate;
		propertyChangeSupport.firePropertyChange("interestRate", oldInterestRate,
		                                         this.interestRate);
	}

	/** 
	 * Getter for property interestRate.
	 *
	 * @return Value of property interestRate.
	 */
	public Float getInterestRate() {
		return interestRate;
	}
}

/* ########## End of File ########## */
