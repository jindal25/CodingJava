/*
 *     file: BankOfficer.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.datamodeling.constraints.NumericConstraint;

/**  
 * An officer in the bank.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class BankOfficer extends Employee {
	/** Constraint for the property officerCode. */
	public static final NumericConstraint OFFICER_CODE_CONSTRAINT =
		new NumericConstraint("officerCode", false, Integer.class, new Integer(0),
		                      new Integer(999999));

	/**
	 * The administrative code assigned to each officer. This is a six digit number
	 * corresponding to their seniority code.
	 */
	private Integer officerCode;

	/** 
	 * Setter for property officerCode.
	 *
	 * @param officerCode New value of property officerCode.
	 */
	public void setOfficerCode(final Integer officerCode) {
		OFFICER_CODE_CONSTRAINT.validate(officerCode);
		final Integer oldOfficerCode = this.officerCode;
		this.officerCode = officerCode;
		propertyChangeSupport.firePropertyChange("officerCode", oldOfficerCode,
		                                         this.officerCode);
	}

	/** 
	 * Getter for property officerCode.
	 *
	 * @return Value of property officerCode.
	 */
	public Integer getOfficerCode() {
		return officerCode;
	}
}

/* ########## End of File ########## */
