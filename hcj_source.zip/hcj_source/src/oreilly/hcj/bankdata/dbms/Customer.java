/*
 *     file: Customer.java
 *  package: oreilly.hcj.bankdata.dbms
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata.dbms;

import java.util.List;
import javax.swing.ImageIcon;

/**  
 * __UNDOCUMENTED__
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class Customer {
	/** The customer's photo. */
	private ImageIcon photo;

	/** Purchases made bythe customer. */
	private List purchases;

	/** The ID of the customer. */
	private String customerID;

	/** The first name of the customer. */
	private String firstName;

	/** The last name of the customer. */
	private String lastName;

	/** The phone of the customer. */
	private String phone;

	/** 
	 * Setter for customerID.
	 *
	 * @param customerID The customerID to set.
	 */
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	/** 
	 * Getter for customerID.
	 *
	 * @return Returns the customerID.
	 */
	public String getCustomerID() {
		return customerID;
	}

	/** 
	 * Setter for firstName.
	 *
	 * @param firstName The firstName to set.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/** 
	 * Getter for firstName.
	 *
	 * @return Returns the firstName.
	 */
	public String getFirstName() {
		return firstName;
	}

	/** 
	 * Setter for lastName.
	 *
	 * @param lastName The lastName to set.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/** 
	 * Getter for lastName.
	 *
	 * @return Returns the lastName.
	 */
	public String getLastName() {
		return lastName;
	}

	/** 
	 * Setter for phone.
	 *
	 * @param phone The phone to set.
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/** 
	 * Getter for phone.
	 *
	 * @return Returns the phone.
	 */
	public String getPhone() {
		return phone;
	}

	/** 
	 * Setter for photo.
	 *
	 * @param photo The photo to set.
	 */
	public void setPhoto(ImageIcon photo) {
		this.photo = photo;
	}

	/** 
	 * Getter for photo.
	 *
	 * @return Returns the photo.
	 */
	public ImageIcon getPhoto() {
		return photo;
	}

	/** 
	 * Setter for purchases.
	 *
	 * @param purchases The purchases to set.
	 */
	public void setPurchases(List purchases) {
		this.purchases = purchases;
	}

	/** 
	 * Getter for purchases.
	 *
	 * @return Returns the purchases.
	 */
	public List getPurchases() {
		return purchases;
	}
}

/* ########## End of File ########## */
