/*
 *     file: Purchase.java
 *  package: oreilly.hcj.bankdata.dbms
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata.dbms;

/**  
 * A customer's purchase.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class Purchase {
	/** The customer making the purchase. */
	private Customer customer;

	/** The price paid. */
	private Float pricePaid;

	/** The purchase ID. */
	private Integer purchaseID;

	/** The SKU of the item purchased. */
	private String itemSKU;

	/** 
	 * Setter for customer.
	 *
	 * @param customer The customer to set.
	 */
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/** 
	 * Getter for customer.
	 *
	 * @return Returns the customer.
	 */
	public Customer getCustomer() {
		return customer;
	}

	/** 
	 * Setter for itemSKU.
	 *
	 * @param itemSKU The itemSKU to set.
	 */
	public void setItemSKU(String itemSKU) {
		this.itemSKU = itemSKU;
	}

	/** 
	 * Getter for itemSKU.
	 *
	 * @return Returns the itemSKU.
	 */
	public String getItemSKU() {
		return itemSKU;
	}

	/** 
	 * Setter for pricePaid.
	 *
	 * @param pricePaid The pricePaid to set.
	 */
	public void setPricePaid(Float pricePaid) {
		this.pricePaid = pricePaid;
	}

	/** 
	 * Getter for pricePaid.
	 *
	 * @return Returns the pricePaid.
	 */
	public Float getPricePaid() {
		return pricePaid;
	}

	/** 
	 * Setter for purchaseID.
	 *
	 * @param purchaseID The purchaseID to set.
	 */
	public void setPurchaseID(Integer purchaseID) {
		this.purchaseID = purchaseID;
	}

	/** 
	 * Getter for purchaseID.
	 *
	 * @return Returns the purchaseID.
	 */
	public Integer getPurchaseID() {
		return purchaseID;
	}
}

/* ########## End of File ########## */
