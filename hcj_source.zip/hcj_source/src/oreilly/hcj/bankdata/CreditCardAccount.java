/*
 *     file: CreditCardAccount.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.datamodeling.constraints.NumericConstraint;

/**  
 * An account rpresenting a credit card in the posession of the customer.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public class CreditCardAccount extends LiabilityAccount {
	/** Constraint for the property creditLimit. */
	public static final NumericConstraint CARD_NUMBER_CONSTRAINT =
		new NumericConstraint("cardNumber", false, Long.class,
		                      new Long(1000000000000000L), new Long(9999999999999999L));

	/** Constraint for the property creditLimit. */
	public static final NumericConstraint CREDIT_LIMIT_CONSTRAINT =
		new NumericConstraint("creditLimit", false, Float.class, new Float(0.0),
		                      new Float(Float.MAX_VALUE));

	/** Constraint for the property minPayPercent. */
	public static final NumericConstraint MIN_PAY_PERCENT_CONSTRAINT =
		new NumericConstraint("minPayPercent", false, Float.class, new Float(0.0),
		                      new Float(1.0));

	/** The limit of credit on this card. */
	private Float creditLimit;

	/** The minimum percentage of the balance that the cardholder must pay each month. */
	private Float minPayPercent;

	/** The 16 digit card number on this card. */
	private Long cardNumber;

	/** 
	 * Setter for property cardNumber.
	 *
	 * @param cardNumber New value of property creditLimit.
	 */
	public void setCardNumber(final Long cardNumber) {
		CARD_NUMBER_CONSTRAINT.validate(cardNumber);
		final Long oldCardNumber = this.cardNumber;
		this.cardNumber = cardNumber;
		propertyChangeSupport.firePropertyChange("cardNumber", oldCardNumber,
		                                         this.cardNumber);
	}

	/** 
	 * Getter for property cardNumber.
	 *
	 * @return Value of property cardNumber.
	 */
	public Long getCardNumber() {
		return cardNumber;
	}

	/** 
	 * Setter for property creditLimit.
	 *
	 * @param creditLimit New value of property creditLimit.
	 */
	public void setCreditLimit(final Float creditLimit) {
		CREDIT_LIMIT_CONSTRAINT.validate(creditLimit);
		final Float oldCreditLimit = this.creditLimit;
		this.creditLimit = creditLimit;
		propertyChangeSupport.firePropertyChange("creditLimit", oldCreditLimit,
		                                         this.creditLimit);
	}

	/** 
	 * Getter for property creditLimit.
	 *
	 * @return Value of property creditLimit.
	 */
	public Float getCreditLimit() {
		return creditLimit;
	}

	/** 
	 * Setter for property minPayPercent.
	 *
	 * @param minPayPercent New value of property minPayPercent.
	 */
	public void setMinPayPercent(final Float minPayPercent) {
		MIN_PAY_PERCENT_CONSTRAINT.validate(minPayPercent);
		final Float oldMinPayPercent = this.minPayPercent;
		this.minPayPercent = minPayPercent;
		propertyChangeSupport.firePropertyChange("minPayPercent", oldMinPayPercent,
		                                         this.minPayPercent);
	}

	/** 
	 * Getter for property minPayPercent.
	 *
	 * @return Value of property minPayPercent.
	 */
	public Float getMinPayPercent() {
		return minPayPercent;
	}
}

/* ########## End of File ########## */
