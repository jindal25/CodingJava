/*
 *     file: Person.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.datamodeling.constraints.DateConstraint;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;
import oreilly.hcj.datamodeling.constraints.StringConstraint;

/**  
 * Base encapsulates a person in the system.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.5 $
 */
public class Person extends MutableObject {
	/** Constraint for the property gender. */
	public static final ObjectConstraint GENDER_CONSTRAINT =
		new ObjectConstraint("gender", false, Gender.class);

	/** Constraint for the property firstName. */
	public static final StringConstraint FIRST_NAME_CONSTRAINT =
		new StringConstraint("firstName", false, 20);

	/** Constraint for the property lastName. */
	public static final StringConstraint LAST_NAME_CONSTRAINT =
		new StringConstraint("lastName", false, 40);

	/** Constraint for the property birthDate. */
	public static final DateConstraint BIRTH_DATE_CONSTRAINT =
		new DateConstraint("birthDate", false, "01/01/1900", "12/31/3000", Locale.US);

	/** Constraint for the property taxID. */
	public static final StringConstraint TAX_ID_CONSTRAINT =
		new StringConstraint("taxID", false, 40);

	/** The birth date of the person. */
	private Date birthDate = Calendar.getInstance()
		                             .getTime();

	/** The gender for the person. */
	private Gender gender = Gender.MALE;

	/** The first name of the person. */
	private String firstName = "<<NEW PERSON>>";

	/** The last name of the person. */
	private String lastName = "<<NEW PERSON>>";

	/** The tax ID of the person. */
	private String taxID = new String();

	/** 
	 * Setter for property birthDate.
	 *
	 * @param birthDate New value of property birthDate.
	 */
	public void setBirthDate(final Date birthDate) {
		BIRTH_DATE_CONSTRAINT.validate(birthDate);
		final Date oldBirthDate = this.birthDate;
		this.birthDate = birthDate;
		propertyChangeSupport.firePropertyChange("birthDate", oldBirthDate, this.birthDate);
	}

	/** 
	 * Getter for property birthDate.
	 *
	 * @return Value of property birthDate.
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/** 
	 * Setter for property firstName.
	 *
	 * @param firstName New value of property firstName.
	 */
	public void setFirstName(final String firstName) {
		FIRST_NAME_CONSTRAINT.validate(firstName);
		final String oldFirstName = this.firstName;
		this.firstName = firstName;
		propertyChangeSupport.firePropertyChange("firstName", oldFirstName, this.firstName);
	}

	/** 
	 * Getter for property firstName.
	 *
	 * @return Value of property firstName.
	 */
	public String getFirstName() {
		return firstName;
	}

	/** 
	 * Setter for property gender.
	 *
	 * @param gender New value of property gender.
	 */
	public void setGender(final Gender gender) {
		GENDER_CONSTRAINT.validate(gender);
		final Gender oldGender = this.gender;
		this.gender = gender;
		propertyChangeSupport.firePropertyChange("gender", oldGender, this.gender);
	}

	/** 
	 * Getter for property gender.
	 *
	 * @return Value of property gender.
	 */
	public Gender getGender() {
		return gender;
	}

	/** 
	 * Setter for property lastName.
	 *
	 * @param lastName New value of property lastName.
	 */
	public void setLastName(final String lastName) {
		LAST_NAME_CONSTRAINT.validate(lastName);
		final String oldLastName = this.lastName;
		this.lastName = lastName;
		propertyChangeSupport.firePropertyChange("lastName", oldLastName, this.lastName);
	}

	/** 
	 * Getter for property lastName.
	 *
	 * @return Value of property lastName.
	 */
	public String getLastName() {
		return lastName;
	}

	/** 
	 * Setter for property taxId.
	 *
	 * @param taxID New value of property taxId.
	 */
	public void setTaxID(final String taxID) {
		LAST_NAME_CONSTRAINT.validate(taxID);
		final String oldTaxID = this.taxID;
		this.taxID = taxID;
		propertyChangeSupport.firePropertyChange("taxID", oldTaxID, this.taxID);
	}

	/** 
	 * Getter for property taxId.
	 *
	 * @return Value of property taxId.
	 */
	public String getTaxID() {
		return taxID;
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof Person)) {
			return false;
		} else {
			final Person target = (Person)obj;
			if (!target.lastName.equals(this.lastName)) {
				return false;
			}
			if (!target.firstName.equals(this.firstName)) {
				return false;
			}
			if (!target.birthDate.equals(this.birthDate)) {
				return false;
			}
			if (!target.taxID.equals(this.taxID)) {
				return false;
			}
			return true;
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final String hashString =
			lastName + ", " + firstName + " (" + birthDate + ") [" + taxID + "]";
		return hashString.hashCode();
	}
}

/* ########## End of File ########## */
