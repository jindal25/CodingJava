/*
 *     file: LoanApplication.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import java.util.Date;
import java.util.Locale;
import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.datamodeling.constraints.DateConstraint;
import oreilly.hcj.datamodeling.constraints.NumericConstraint;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;
import oreilly.hcj.datamodeling.constraints.StringConstraint;

/**  
 * An application for a <tt>LoanAccount</tt>.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.5 $
 */
public class LoanApplication extends MutableObject {
	/** Constraint for the property code. */
	public static final StringConstraint CODE_CONSTRAINT =
		new StringConstraint("code", false, 20);

	/** Constraint for the property controller. */
	public static final ObjectConstraint CONTROLLER_CONSTRAINT =
		new ObjectConstraint("controller", false, BankOfficer.class);

	/** Constraint for the property customer. */
	public static final ObjectConstraint CUSTOMER_CONSTRAINT =
		new ObjectConstraint("customer", false, Customer.class);

	/** Constraint for the property approvalDate. */
	public static final DateConstraint APPROVAL_DATE_CONSTRAINT =
		new DateConstraint("approvalDate", false, "01/01/1960", "12/31/3000", Locale.US);

	/** Constraint for the property principal. */
	public static final NumericConstraint PRINCIPAL_CONSTRAINT =
		new NumericConstraint("principal", false, Float.class, new Float(0.0),
		                      new Float(Float.MAX_VALUE));

	/** Constraint for the property status. */
	public static final ObjectConstraint STATUS_CONSTRAINT =
		new ObjectConstraint("status", false, LoanApplicationStatus.class);

	/** Constraint for the property collateral. */
	public static final StringConstraint COLLATERAL_CONSTRAINT =
		new StringConstraint("collateral", false, 9000);

	/** Constraint for the property purpose. */
	public static final StringConstraint PURPOSE_CONSTRAINT =
		new StringConstraint("purpose", false, 9000);

	/** The bank officer controllign the loan. */
	private BankOfficer controller;

	/** The customer makign the application. */
	private Customer customer;

	/**
	 * The date the loan was approved or null if it has yet to be approved or has been
	 * denied.
	 */
	private Date approvalDate;

	/** The requested principal of the loan. */
	private Float principal;

	/** The current status of this application. */
	private LoanApplicationStatus status;

	/** Holds value of property code. */
	private String code;

	/** A description of the collateral offered for the loan. */
	private String collateral;

	/** The purpose of the loan. */
	private String purpose;

	/** 
	 * Setter for property approvalDate.
	 *
	 * @param approvalDate New value of property approvalDate.
	 */
	public void setApprovalDate(Date approvalDate) {
		APPROVAL_DATE_CONSTRAINT.validate(approvalDate);
		final Date oldApprovalDate = this.approvalDate;
		this.approvalDate = approvalDate;
		propertyChangeSupport.firePropertyChange("approvalDate", oldApprovalDate,
		                                         this.approvalDate);
	}

	/** 
	 * Getter for property approvalDate.
	 *
	 * @return Value of property approvalDate.
	 */
	public Date getApprovalDate() {
		return approvalDate;
	}

	/** 
	 * Setter for property code.
	 *
	 * @param code New value of property code.
	 */
	public void setCode(final String code) {
		CODE_CONSTRAINT.validate(code);
		final String oldCode = this.code;
		this.code = code;
		propertyChangeSupport.firePropertyChange("code", oldCode, code);
	}

	/** 
	 * Getter for property code.
	 *
	 * @return Value of property code.
	 */
	public String getCode() {
		return this.code;
	}

	/** 
	 * Setter for property collateral.
	 *
	 * @param collateral New value of property collateral.
	 */
	public void setCollateral(final String collateral) {
		COLLATERAL_CONSTRAINT.validate(collateral);
		final String oldCollateral = this.collateral;
		this.collateral = collateral;
		propertyChangeSupport.firePropertyChange("collateral", oldCollateral,
		                                         this.collateral);
	}

	/** 
	 * Getter for property collateral.
	 *
	 * @return Value of property collateral.
	 */
	public String getCollateral() {
		return collateral;
	}

	/** 
	 * Setter for property controller.
	 *
	 * @param controller New value of property controller.
	 */
	public void setController(final BankOfficer controller) {
		CONTROLLER_CONSTRAINT.validate(controller);
		final BankOfficer oldController = this.controller;
		this.controller = controller;
		propertyChangeSupport.firePropertyChange("controller", oldController,
		                                         this.controller);
	}

	/** 
	 * Getter for property controller.
	 *
	 * @return Value of property controller.
	 */
	public BankOfficer getController() {
		return controller;
	}

	/** 
	 * Setter for property customer.
	 *
	 * @param customer New value of property customer.
	 */
	public void setCustomer(final Customer customer) {
		CUSTOMER_CONSTRAINT.validate(customer);
		final Customer oldCustomer = this.customer;
		this.customer = customer;
		propertyChangeSupport.firePropertyChange("customer", oldCustomer, this.customer);
	}

	/** 
	 * Getter for property customer.
	 *
	 * @return Value of property customer.
	 */
	public oreilly.hcj.bankdata.Customer getCustomer() {
		return customer;
	}

	/** 
	 * Setter for property principal.
	 *
	 * @param principal New value of property principal.
	 */
	public void setPrincipal(final Float principal) {
		PRINCIPAL_CONSTRAINT.validate(principal);
		final Float oldPrincipal = this.principal;
		this.principal = principal;
		propertyChangeSupport.firePropertyChange("principal", oldPrincipal, this.principal);
	}

	/** 
	 * Getter for property principal.
	 *
	 * @return Value of property principal.
	 */
	public java.lang.Float getPrincipal() {
		return principal;
	}

	/** 
	 * Setter for property purpose.
	 *
	 * @param purpose New value of property purpose.
	 */
	public void setPurpose(final String purpose) {
		PURPOSE_CONSTRAINT.validate(purpose);
		final String oldPurpose = this.purpose;
		this.purpose = purpose;
		propertyChangeSupport.firePropertyChange("purpose", oldPurpose, this.purpose);
	}

	/** 
	 * Getter for property purpose.
	 *
	 * @return Value of property purpose.
	 */
	public String getPurpose() {
		return purpose;
	}

	/** 
	 * Setter for property status.
	 *
	 * @param status New value of property status.
	 */
	public void setStatus(final LoanApplicationStatus status) {
		STATUS_CONSTRAINT.validate(status);
		final LoanApplicationStatus oldStatus = this.status;
		this.status = status;
		propertyChangeSupport.firePropertyChange("status", oldStatus, this.status);
	}

	/** 
	 * Getter for property status.
	 *
	 * @return Value of property status.
	 */
	public LoanApplicationStatus getStatus() {
		return status;
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof LoanApplication)) {
			return false;
		} else {
			return (((LoanApplication)obj).getCode().equals(this.code));
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.code.hashCode();
	}
}

/* ########## End of File ########## */
