/*
 *     file: Account.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.datamodeling.constraints.CollectionConstraint;
import oreilly.hcj.datamodeling.constraints.NumericConstraint;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;

/**  
 * Base class for all customer accounts.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public abstract class Account extends MutableObject {
	/** Constraint for the ID property. */
	public static final NumericConstraint ID_CONSTRAINT =
		new NumericConstraint("ID", false, Integer.class, new Integer(1000000),
		                      new Integer(Integer.MAX_VALUE));

	/** Constraint for the customer property. */
	public static final ObjectConstraint CUSTOMER_CONSTRAINT =
		new ObjectConstraint("customer", false, Customer.class);

	/** Constraint for the balance property. */
	public static final NumericConstraint BALANCE_CONSTRAINT =
		new NumericConstraint("balance", false, Float.class, new Float(Float.MIN_VALUE),
		                      new Float(Float.MAX_VALUE));

	/** Constraint for the transactionList property. */
	public static final CollectionConstraint TRANSACTION_LIST_CONSTRAINT =
		new CollectionConstraint("transactionList", false, Set.class, Transaction.class);

	/** The customer that holds this account. */
	private Customer customer;

	/** Balance on the account. */
	private Float balance;

	/** Holds value of property ID. */
	private Integer ID;

	/** The list of transactions executed on thsi account. */
	private Set transactionList = new HashSet();

	// of type Transaction

	/** 
	 * Setter for property balance.
	 *
	 * @param balance New value of property balance.
	 */
	public void setBalance(final Float balance) {
		BALANCE_CONSTRAINT.validate(balance);
		final Float oldBalance = this.balance;
		this.balance = balance;
		propertyChangeSupport.firePropertyChange("balance", oldBalance, this.balance);
	}

	/** 
	 * Getter for property balance.
	 *
	 * @return Value of property balance.
	 */
	public Float getBalance() {
		return balance;
	}

	/** 
	 * Setter for property customer.
	 *
	 * @param customer New value of property customer.
	 */
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/** 
	 * Getter for property customer.
	 *
	 * @return Value of property customer.
	 */
	public Customer getCustomer() {
		return customer;
	}

	/** 
	 * Setter for property ID.
	 *
	 * @param ID New value of property ID.
	 */
	public void setID(final Integer ID) {
		ID_CONSTRAINT.validate(ID);
		final Integer oldID = this.ID;
		this.ID = ID;
		propertyChangeSupport.firePropertyChange("ID", oldID, ID);
	}

	/** 
	 * Getter for property ID.
	 *
	 * @return Value of property ID.
	 */
	public Integer getID() {
		return this.ID;
	}

	/** 
	 * Setter for property transactionList.
	 *
	 * @param transactionList New value of property transactionList.
	 */
	public void setTransactionList(final Set transactionList) {
		TRANSACTION_LIST_CONSTRAINT.validate(transactionList);
		final Set oldTransactionList = Collections.unmodifiableSet(this.transactionList);
		this.transactionList = new HashSet(transactionList);
		propertyChangeSupport.firePropertyChange("transactionList", oldTransactionList,
		                                         getTransactionList());
	}

	/** 
	 * Getter for property transactionList.
	 *
	 * @return Value of property transactionList.
	 */
	public Set getTransactionList() {
		return Collections.unmodifiableSet(transactionList);
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof Account)) {
			return false;
		} else {
			return (((Account)obj).getID().equals(this.ID));
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.ID.hashCode();
	}
}

/* ########## End of File ########## */
