/*
 *     file: Employee.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;
import oreilly.hcj.datamodeling.constraints.StringConstraint;

/**  
 * An employee of the bank.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.6 $
 */
public class Employee extends MutableObject {
	/** Constraint for the property employeeID. */
	public static final StringConstraint EMPLOYEE_ID_CONSTRAINT =
		new StringConstraint("employeeID", false, 10);

	/** Constraint for the property person. */
	public static final ObjectConstraint PERSON_CONSTRAINT =
		new ObjectConstraint("person", false, Person.class);

	/** The unique id for this employee */
	private Person person;

	/** The unique id for this employee */
	private String employeeID;

	/** 
	 * Setter for property employeeID.
	 *
	 * @param employeeID New value of property employeeID.
	 */
	public void setEmployeeID(final String employeeID) {
		EMPLOYEE_ID_CONSTRAINT.validate(employeeID);
		final String oldEmployeeId = this.employeeID;
		this.employeeID = employeeID;
		propertyChangeSupport.firePropertyChange("employeeID", oldEmployeeId,
		                                         this.employeeID);
	}

	/** 
	 * Getter for property employeeID.
	 *
	 * @return Value of property employeeID.
	 */
	public String getEmployeeID() {
		return employeeID;
	}

	/** 
	 * Setter for property person.
	 *
	 * @param person New value of property person.
	 */
	public void setPerson(final Person person) {
		PERSON_CONSTRAINT.validate(person);
		final Person oldPerson = this.person;
		this.person = person;
		propertyChangeSupport.firePropertyChange("person", oldPerson, this.person);
	}

	/** 
	 * Getter for property person.
	 *
	 * @return Value of property person.
	 */
	public Person getPerson() {
		return person;
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof Employee)) {
			return false;
		} else {
			return (((Employee)obj).getEmployeeID().equals(this.employeeID));
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.employeeID.hashCode();
	}
}

/* ########## End of File ########## */
