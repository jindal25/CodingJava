/*
 *     file: AutomaticPayment.java
 *  package: oreilly.hcj.bankdata
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.bankdata;

import oreilly.hcj.datamodeling.MutableObject;
import oreilly.hcj.datamodeling.constraints.NumericConstraint;
import oreilly.hcj.datamodeling.constraints.ObjectConstraint;
import oreilly.hcj.datamodeling.constraints.StringConstraint;

/**  
 * Describes monthly payments that are automatically taken from one customer and credited
 * to another customer.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.4 $
 */
public class AutomaticPayment extends MutableObject {
	/** Constraint for the property code. */
	public static final StringConstraint PAYMENT_CODE_CONSTRAINT =
		new StringConstraint("paymentCode", false, 23);

	/** Constraint for the property payee . */
	public static final ObjectConstraint PAYEE_CONSTRAINT =
		new ObjectConstraint("payee", false, Customer.class);

	/** Constraint for the property payer. */
	public static final ObjectConstraint PAYER_CONSTRAINT =
		new ObjectConstraint("payer", false, Customer.class);

	/** Constraint for the property amount. */
	public static final NumericConstraint AMOUNT_CONSTRAINT =
		new NumericConstraint("amount", false, Float.class, new Float(0.0),
		                      new Float(Float.MAX_VALUE));

	/** The customer to be paid. */
	private Customer payee;

	/** The customer making the payment. */
	private Customer payer;

	/** The amount to be paid */
	private Float amount;

	/** Holds value of property paymentCode. */
	private String paymentCode;

	/** 
	 * Setter for property amount.
	 *
	 * @param amount New value of property amount.
	 */
	public void setAmount(final Float amount) {
		AMOUNT_CONSTRAINT.validate(amount);
		final Float oldAmount = this.amount;
		this.amount = amount;
		propertyChangeSupport.firePropertyChange("amount", oldAmount, this.amount);
	}

	/** 
	 * Getter for property amount.
	 *
	 * @return Value of property amount.
	 */
	public Float getAmount() {
		return amount;
	}

	/** 
	 * Setter for property payee.
	 *
	 * @param payee New value of property payee.
	 */
	public void setPayee(final Customer payee) {
		PAYEE_CONSTRAINT.validate(payee);
		final Customer oldPayee = this.payee;
		this.payee = payee;
		propertyChangeSupport.firePropertyChange("payee", oldPayee, this.payee);
	}

	/** 
	 * Getter for property payee.
	 *
	 * @return Value of property payee.
	 */
	public Customer getPayee() {
		return payee;
	}

	/** 
	 * Setter for property payer.
	 *
	 * @param payer New value of property payer.
	 */
	public void setPayer(final Customer payer) {
		PAYER_CONSTRAINT.validate(payer);
		final Customer oldPayer = this.payer;
		this.payer = payer;
		propertyChangeSupport.firePropertyChange("payer", oldPayer, this.payer);
	}

	/** 
	 * Getter for property payer.
	 *
	 * @return Value of property payer.
	 */
	public Customer getPayer() {
		return payer;
	}

	/** 
	 * Setter for property paymentCode.
	 *
	 * @param paymentCode New value of property paymentCode.
	 */
	public void setPaymentCode(final String paymentCode) {
		PAYMENT_CODE_CONSTRAINT.validate(paymentCode);
		final String oldPaymentCode = this.paymentCode;
		this.paymentCode = paymentCode;
		propertyChangeSupport.firePropertyChange("paymentCode", oldPaymentCode,
		                                         paymentCode);
	}

	/** 
	 * Getter for property paymentCode.
	 *
	 * @return Value of property paymentCode.
	 */
	public String getPaymentCode() {
		return this.paymentCode;
	}

	/** 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(final Object obj) {
		if (!(obj instanceof AutomaticPayment)) {
			return false;
		} else {
			return (((AutomaticPayment)obj).getPaymentCode().equals(this.paymentCode));
		}
	}

	/** 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return this.paymentCode.hashCode();
	}
}

/* ########## End of File ########## */
