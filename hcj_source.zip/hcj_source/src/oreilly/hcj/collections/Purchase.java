/*
 *     file: Purchase.java
 *  package: oreilly.hcj.collections
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.collections;

/**  
 * A demo purchase bean.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Purchase {
	/** Holder for the property itemName. */
	private String itemName;

	/** Holder for the property price. */
	private float price;

	/** 
	 * Creates a new Purchase object.
	 */
	public Purchase() {
	}

	/** 
	 * Creates a new Purchase object.
	 *
	 * @param itemName The name of the item purchased.
	 * @param price The price of the item purchased.
	 */
	public Purchase(final String itemName, final float price) {
		setItemName(itemName);
		setPrice(price);
	}

	/** 
	 * Setter for the property itemName.
	 *
	 * @param itemName The new name.
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	/** 
	 * Getter for the property itemName.
	 *
	 * @return The current name.
	 */
	public String getItemName() {
		return this.itemName;
	}

	/** 
	 * Setter for the property price.
	 *
	 * @param price The new price.
	 */
	public void setPrice(float price) {
		this.price = price;
	}

	/** 
	 * Getter for the property price.
	 *
	 * @return The current price.
	 */
	public float getPrice() {
		return this.price;
	}
}

/* ########## End of File ########## */
