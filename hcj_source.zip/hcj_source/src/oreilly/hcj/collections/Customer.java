/*
 *     file: Customer.java
 *  package: oreilly.hcj.collections
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.collections;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.beans.VetoableChangeSupport;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**  
 * Demonstration of set functionality in beans.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class Customer extends Object implements Serializable {
	/** Use serialVersionUID for interoperability. */
	private static final long serialVersionUID = 7282170508738698519L;

	/** Provides support for property change events. */
	private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

	/** Holds value of property purchases. */
	private Set purchases;

	/** Holds value of property purchases2. */
	private Set purchases2;

	/** Holds value of property purchases3. */
	private Set purchases3 = new HashSet();

	/** Name of the customer. */
	private String name;

	/** Utility field used by constrained properties. */
	private VetoableChangeSupport vetoableChangeSupport = new VetoableChangeSupport(this);

	/** 
	 * Creates new Customer
	 */
	public Customer() {
	}

	/** 
	 * Setter for the property name.
	 *
	 * @param name The new value for the property name.
	 *
	 * @throws PropertyVetoException If the change is vetoed.
	 */
	public void setName(final String name) throws PropertyVetoException {
		final String oldName = this.name;
		vetoableChangeSupport.fireVetoableChange("name", oldName, this.name);
		this.name = name;
		propertyChangeSupport.firePropertyChange("name", oldName, this.name);
	}

	/** 
	 * Getter for the property name.
	 *
	 * @return The current value of the property name.
	 */
	public String getName() {
		return this.name;
	}

	/** 
	 * Setter for property purchases. Note that this doesn't protect the sets as they are
	 * given out to the PropertyChangeListener and PropertyVetoListener objects.
	 *
	 * @param purchases New value of property purchases.
	 *
	 * @throws PropertyVetoException If the change is vetoed.
	 */
	public void setPurchases(Set purchases) throws PropertyVetoException {
		Set oldPurchases = this.purchases;
		vetoableChangeSupport.fireVetoableChange("purchases", oldPurchases, this.purchases);
		this.purchases = purchases;
		propertyChangeSupport.firePropertyChange("purchases", oldPurchases, this.purchases);
	}

	/** 
	 * Getter for property purchases.Note that this doesn't protect the sets as they are
	 * given out to the callers of this method.
	 *
	 * @return Value of property purchases.
	 */
	public Set getPurchases() {
		return this.purchases;
	}

	/** 
	 * Setter for property purchases2.This method fully protects the incomming set so
	 * that the vetoable change listener, and the propertyChangeListener cant change it.
	 *
	 * @param purchases2 New value of property purchases2.
	 *
	 * @throws PropertyVetoException If the change is vetoed.
	 */
	public void setPurchases2(final Set purchases2) throws PropertyVetoException {
		final Set newPurchases2;
		if (purchases2 != null) {
			newPurchases2 = Collections.unmodifiableSet(purchases2);
		} else {
			newPurchases2 = null;
		}

		final Set oldpurchases2 = this.getPurchases2();
		vetoableChangeSupport.fireVetoableChange("purchases2", oldpurchases2,
		                                         newPurchases2);
		this.purchases2 = new HashSet(purchases2);
		propertyChangeSupport.firePropertyChange("purchases2", oldpurchases2,
		                                         getPurchases2());
	}

	/** 
	 * Getter for property purchases2. Note that you will have to check for null in the
	 * return value.
	 *
	 * @return Value of property purchases2.
	 */
	public Set getPurchases2() {
		if (this.purchases2 == null) {
			return null;
		}
		return Collections.unmodifiableSet(this.purchases2);
	}

	/** 
	 * Setter for property purchases3. This method fully protects the incomming set so
	 * that the vetoable change listener, and the propertyChangeListener cant change it.
	 * In addition, since the property can never be null, you dont have to worry about
	 * checking for null.
	 *
	 * @param purchases3 New value of property purchases3.
	 *
	 * @throws PropertyVetoException If the change is vetoed.
	 * @throws NullPointerException If null is passed for purchases3.
	 */
	public void setPurchases3(final Set purchases3) throws PropertyVetoException {
		if (purchases3 == null) {
			throw new NullPointerException();
		}
		final Set oldPurchases3 = this.getPurchases3();
		final Set newPurchases3 = Collections.unmodifiableSet(purchases3);
		vetoableChangeSupport.fireVetoableChange("purchases3", oldPurchases3,
		                                         newPurchases3);
		this.purchases3 = new HashSet(purchases3);
		propertyChangeSupport.firePropertyChange("purchases3", oldPurchases3,
		                                         getPurchases3());
	}

	/** 
	 * Getter for property purchases3.Returns the value of the property. Since the
	 * property can never be null, the user has the ability to use the return value
	 * without checking for null.
	 *
	 * @return Value of property purchases3; Note that this will never be null.
	 */
	public Set getPurchases3() {
		return Collections.unmodifiableSet(this.purchases3);
	}

	/** 
	 * @see java.beans.PropertyChangeListener
	 */
	public void addPropertyChangeListener(final PropertyChangeListener l) {
		propertyChangeSupport.addPropertyChangeListener(l);
	}

	/** 
	 * @see java.beans.VetoableChangeListener
	 */
	public void addVetoableChangeListener(final VetoableChangeListener l) {
		vetoableChangeSupport.addVetoableChangeListener(l);
	}

	/** 
	 * @see java.beans.PropertyChangeListener
	 */
	public void removePropertyChangeListener(final PropertyChangeListener l) {
		propertyChangeSupport.removePropertyChangeListener(l);
	}

	/** 
	 * @see java.beans.VetoableChangeListener
	 */
	public void removeVetoableChangeListener(final VetoableChangeListener l) {
		vetoableChangeSupport.removeVetoableChangeListener(l);
	}
}

/* ########## End of File ########## */
