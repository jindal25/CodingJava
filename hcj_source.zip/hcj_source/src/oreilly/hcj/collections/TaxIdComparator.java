/*
 *     file: TaxIdComparator.java
 *  package: oreilly.hcj.collections
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.collections;

import java.util.Comparator;
import oreilly.hcj.bankdata.Person;

/**  
 * Compares <code>Person</code> objects based upon tax id.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 *
 * @see oreilly.hcj.bankdata.Person
 */
public class TaxIdComparator implements Comparator {
	/** 
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	public int compare(final Object x, final Object y) {
		return ((Person)x).getTaxID()
		        .compareTo(((Person)y).getTaxID());
	}
}

/* ########## End of File ########## */
