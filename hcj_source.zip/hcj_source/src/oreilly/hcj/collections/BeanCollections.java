/*
 *     file: BeanCollections.java
 *  package: oreilly.hcj.collections
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**  
 * Demonstrate the collections issues with beans.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.3 $
 */
public class BeanCollections {
	/** A demo customer set. */
	private static final Set CUSTOMERS;

	static {
		CUSTOMERS = new HashSet();
		try {
			Customer customer = null;
			HashSet purchs = null;

			// -- Joe
			customer = new Customer();
			customer.setName("Joe");
			purchs = new HashSet();
			purchs.add(new Purchase("Cat Food", 22.34f));
			purchs.add(new Purchase("Cat Treats", 5.45f));
			purchs.add(new Purchase("Cat Toy", 12.95f));
			customer.setPurchases(purchs);
			customer.setPurchases2(purchs);
			customer.setPurchases3(purchs);
			CUSTOMERS.add(customer);
			// -- Jon
			customer = new Customer();
			customer.setName("Jon");
			purchs = new HashSet();
			purchs.add(new Purchase("Dog Food", 35.95f));
			purchs.add(new Purchase("Dog Toy", 9.24f));
			customer.setPurchases(purchs);
			customer.setPurchases2(purchs);
			customer.setPurchases3(purchs);
			CUSTOMERS.add(customer);
			// -- Jane
			customer = new Customer();
			customer.setName("Jane");
			purchs = new HashSet();
			customer.setPurchases(purchs);
			customer.setPurchases2(purchs);
			customer.setPurchases3(purchs);
			CUSTOMERS.add(customer);
		} catch (final Exception ex) {
			ex.printStackTrace();
		}
	}

	/** 
	 * Main Method.
	 *
	 * @param args command line arguments.
	 */
	public static void main(String[] args) {
		try {
			Iterator iter = CUSTOMERS.iterator();
			Customer customer = null;
			while (iter.hasNext()) {
				customer = (Customer)iter.next();
				someFunction(customer);
				makeCustomerReport(customer);
			}
		} catch (final ClassCastException ex) {
			System.out.println("--- See? I told you. ---");
			ex.printStackTrace(System.out);
			System.out.flush();
		}
		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println();

		// -- Write out the two types of report to show that they
		// do the same thing. Note that the order might be slightly 
		// different due to the nature of Set iterators.
		makeGroupReport(CUSTOMERS);

		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println();

		makeGroupReportBetter(CUSTOMERS);
	}

	/** 
	 * Make a purchases report for a customer.
	 *
	 * @param customer The customer for which to make a report.
	 *
	 * @throws NullPointerException If customers is null.
	 */
	public static void makeCustomerReport(final Customer customer) {
		if (customer == null) {
			throw new NullPointerException();
		}
		Set purchases = customer.getPurchases();
		if (purchases != null) {
			Iterator iter = purchases.iterator();
			Purchase purch = null;
			System.out.println("Purchases for " + customer.getName());
			while (iter.hasNext()) {
				purch = (Purchase)iter.next();
				System.out.println(purch.getItemName() + "\t" + purch.getPrice());
			}
		}
	}

	/** 
	 * Prepare a report of purchases for the given customers.  Example with potential
	 * null in Set peoperties.
	 *
	 * @param customers The customers for which to prepare a report.
	 *
	 * @throws NullPointerException If customers is null.
	 */
	public static void makeGroupReport(final Set customers) {
		if (customers == null) {
			throw new NullPointerException();
		}
		Iterator purchaseIter = null;
		Iterator customerIter = null;
		Set purchases = null;
		Customer customer = null;
		Purchase purch = null;

		customerIter = customers.iterator();
		while (customerIter.hasNext()) {
			customer = (Customer)customerIter.next();
			System.out.println("Purchases for " + customer.getName());
			purchases = customer.getPurchases3();
			if (purchases != null) {
				purchaseIter = purchases.iterator();
				while (purchaseIter.hasNext()) {
					purch = (Purchase)purchaseIter.next();
					System.out.println(purch.getItemName() + "\t" + purch.getPrice());
				}
			}
			System.out.print("Total Purchases = ");
			if (purchases != null) {
				System.out.println(purchases.size());
			} else {
				System.out.println(0);
			}
			System.out.println();
		}
	}

	/** 
	 * Prepare a report of purchases for the given customers.  Example with potential no
	 * nulls in Set peoperties.
	 *
	 * @param customers The customers for which to prepare a report.
	 *
	 * @throws NullPointerException If customers is null.
	 */
	public static void makeGroupReportBetter(final Set customers) {
		if (customers == null) {
			throw new NullPointerException();
		}
		Iterator purchaseIter = null;
		Iterator customerIter = null;
		Set purchases = null;
		Customer customer = null;
		Purchase purch = null;

		customerIter = customers.iterator();
		while (customerIter.hasNext()) {
			customer = (Customer)customerIter.next();
			System.out.println("Purchases for " + customer.getName());
			purchases = customer.getPurchases3();
			purchaseIter = customer.getPurchases3()
				                   .iterator();
			while (purchaseIter.hasNext()) {
				purch = (Purchase)purchaseIter.next();
				System.out.println(purch.getItemName() + "\t" + purch.getPrice());
			}
			System.out.println("Total Purchases = " + purchases.size());
			System.out.println();
		}
	}

	/** 
	 * Manipulate a customer.
	 *
	 * @param customer The customer to manipulate.
	 *
	 * @throws NullPointerException If customer is null.
	 */
	public static void someFunction(final Customer customer) {
		if (customer == null) {
			throw new NullPointerException();
		}
		Set purchs = customer.getPurchases();
		Set names = new HashSet();  // going to use to store customer names. 
		names.add(new String("Jason"));
		purchs.add(new String("Fred"));  // typo, he meant names, not purchs. 
	}
}

/* ########## End of File ########## */
