/*
 *     file: SomeClass.java
 *  package: oreilly.hcj.collections
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/**  
 * Class used to synax proof demo code from the HCJ Collections chapter.  There is really
 * no re-usable stuff in here. I merely use this class in order to make sure my syntax
 * is correct in snippets.
 *
 * @author <a href="mailto:kraythe@arcor.de">Robert (Kraythe) Simmons jr.</a>
 */
public class SomeClass {
	/** A set. */
	HashSet someSet = new HashSet();

	/** A set. */
	Set someOtherSet = new HashSet();

	/** 
	 * Demonstrate sorting on comparator.
	 */
	protected void demoComparator() {
		SortedSet people = new TreeSet(new TaxIdComparator());

		// .. add people to the set.
		people.size();  // supress eclipse warning.
	}

	/** 
	 * __UNDOCUMENTED__
	 *
	 * @param someCustomer __UNDOCUMENTED__
	 */
	protected void markPreferredCustomer(final String someCustomer) {
		Set set = new HashSet();

		// ... add items to the set. 
		String element = null;
		Iterator iter = set.iterator();
		while (iter.hasNext()) {
			element = (String)iter.next();
			// ... perfomr some logic
			if (element.equals(someCustomer)) {
				set.add(new String("p->" + element));
				set.remove(element);
			}
		}
	}

	/** 
	 * A bad interface usage.
	 *
	 * @return NA
	 */
	protected HashSet someBadMethod() {
		return this.someSet;
	}

	/** 
	 * A good interface usage.
	 *
	 * @return NA
	 */
	protected Set someMethod() {
		return this.someSet;
	}

	/** 
	 * A good interface usage.
	 *
	 * @return NA
	 */
	protected Set someOtherMethod() {
		return this.someOtherSet;
	}
}

/* ########## End of File ########## */
