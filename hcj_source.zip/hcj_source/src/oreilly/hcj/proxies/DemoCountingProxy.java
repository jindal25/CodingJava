/*
 *     file: DemoCountingProxy.java
 *  package: oreilly.hcj.proxies
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.proxies;

/**  
 * Demonstrates the usage of a counting proxy.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.2 $
 */
public class DemoCountingProxy {
	/** 
	 * Run the demonstration.
	 *
	 * @param args Command Line Arguments (ignored).
	 */
	public static final void main(final String[] args) {
		SomeClassCountingProxy proxy = SomeClassFactory.getCountingProxy();
		proxy.someMethod();
		proxy.someOtherMethod("Our Proxy works!");
		System.out.println("Method Invocation Count = " + proxy.getInvocationCount());
	}
}

/* ########## End of File ########## */
