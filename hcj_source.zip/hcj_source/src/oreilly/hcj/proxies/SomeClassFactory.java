/*
 *     file: SomeClassFactory.java
 *  package: oreilly.hcj.proxies
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.proxies;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import org.apache.log4j.Logger;

/**  
 * A demonstration of a proxy factory.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.2 $
 */
public class SomeClassFactory {
	/** Holds the logging object. */
	private static final Logger LOGGER = Logger.getLogger(SomeClassFactory.class);

	/** 
	 * Gets a counting proxy to an object that is constructed with the user name.
	 *
	 * @return The proxy to the implementation.
	 */
	public static final SomeClassCountingProxy getCountingProxy() {
		SomeClassImpl impl = new SomeClassImpl(System.getProperty("user.name"));
		return new SomeClassCountingProxy(impl);
	}

	/** 
	 * Gets proxy to depending upon debug status in Log4J.
	 *
	 * @return The proxy to the implementation.
	 */
	public static final SomeClass getDynamicSomeClassProxy() {
		SomeClassImpl impl = new SomeClassImpl(System.getProperty("user.name"));
		InvocationHandler handler = new MethodCountingHandler(impl);
		Class[] interfaces = new Class[] { SomeClass.class };
		ClassLoader loader = SomeClassFactory.class.getClassLoader();
		SomeClass proxy = (SomeClass)Proxy.newProxyInstance(loader, interfaces, handler);
		return proxy;
	}

	/** 
	 * Gets a proxy to an object that is constructed with the user name.
	 *
	 * @return The proxy to the implementation.
	 */
	public static final SomeClassProxy getProxy() {
		SomeClassImpl impl = new SomeClassImpl(System.getProperty("user.name"));
		return new SomeClassProxy(impl);
	}

	/** 
	 * Gets proxy to depending upon debug status in Log4J.
	 *
	 * @return The proxy to the implementation.
	 */
	public static final SomeClass getSomeClassProxy() {
		SomeClassImpl impl = new SomeClassImpl(System.getProperty("user.name"));
		if (LOGGER.isDebugEnabled()) {
			return new SomeClassCountingProxy(impl);
		} else {
			return new SomeClassProxy(impl);
		}
	}
}

/* ########## End of File ########## */
