/*
 *     file: MethodCountingHandler.java
 *  package: oreilly.hcj.proxies
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.proxies;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**  
 * An invocation handler that counts the number of calls for all methods in the target
 * class.
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.2 $
 *
 * @see java.lang.reflect.InvocationHandler
 */
public class MethodCountingHandler implements InvocationHandler {
	/** The implementation object for this proxy. */
	private final Object impl;

	/** Holds the invocation count. */
	private int invocationCount = 0;

	/** 
	 * Creates a new MethodCOuntingHandler object.
	 *
	 * @param impl
	 */
	public MethodCountingHandler(final Object impl) {
		this.impl = impl;
	}

	/** 
	 * Gets the value of the property invocationCount.
	 *
	 * @return The current value of invocationCount
	 */
	public int getInvocationCount() {
		return invocationCount;
	}

	/** 
	 * @see java.lang.reflect.InvocationHandler#invoke(java.lang.Object,
	 *      java.lang.reflect.Method, java.lang.Object[])
	 */
	public Object invoke(Object proxy, Method meth, Object[] args)
	    throws Throwable {
		try {
			this.invocationCount++;
			Object result = meth.invoke(impl, args);
			return result;
		} catch (final InvocationTargetException ex) {
			throw ex.getTargetException();
		}
	}
}

/* ########## End of File ########## */
