/*
 *     file: DangerousNames.java
 *  package: oreilly.hcj.proxies
 *
 * This software is granted under the terms of the Common Public License,
 * CPL, which may be found at the following URL:
 * http://www-124.ibm.com/developerworks/oss/CPLv1.0.htm
 *
 * Copyright(c) 2003-2005 by the authors indicated in the @author tags.
 * All Rights are Reserved by the various authors.
 *
########## DO NOT EDIT ABOVE THIS LINE ########## */

package oreilly.hcj.proxies;

/**  
 * Demonstrates a dangerous use of proxy names.
 * 
 * <p>
 * According to the JDK, the unqualified name of a proxy class is undefined so using it
 * in code like this could cause you grief.
 * </p>
 *
 * @author <a href=mailto:kraythe@arcor.de>Robert Simmons jr. (kraythe)</a>
 * @version $Revision: 1.2 $
 */
public class DangerousNames {
	/** 
	 * Run the demonstration.
	 *
	 * @param args Command line arguments (ignored).
	 */
	public static final void main(final String[] args) {
		SomeClass proxy = SomeClassFactory.getDynamicSomeClassProxy();
		System.out.println(proxy.getClass().getName());
		try {
			Class cl = Class.forName("$Proxy0");  // <== Dangerous!
			System.out.println(cl.getName());
		} catch (final ClassNotFoundException ex) {
			ex.printStackTrace();
		}
	}
}

/* ########## End of File ########## */
